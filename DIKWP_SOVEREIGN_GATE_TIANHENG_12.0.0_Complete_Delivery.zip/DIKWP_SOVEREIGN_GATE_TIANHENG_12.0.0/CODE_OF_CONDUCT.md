# Code of Conduct

Maintain rigorous, evidence-based and respectful technical discussion. Critique claims, mathematics, code and governance assumptions directly. Do not harass contributors or misrepresent experimental results as deployment proof.
