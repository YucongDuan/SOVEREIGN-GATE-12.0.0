# Playbook: Harness Capability Jump

## Trigger

- accuracy or task completion increases sharply without model-weight change;
- deterministic solver, router, state tracker, memory or validator added;
- network, tool, multi-agent, persistence or self-modification power increases;
- new Builder AI-generated code changes the Target AI work environment.

## Response

1. freeze the proposed Harness version;
2. compute old and new system capability;
3. enumerate privileged deltas;
4. require the full recertification matrix;
5. issue a new Passport only after passing tests;
6. bind the exact manifest hash to the lease;
7. monitor real outcomes for calibration drift.

A stronger system is not rejected merely for being stronger. It is prevented from inheriting an obsolete safety case.
