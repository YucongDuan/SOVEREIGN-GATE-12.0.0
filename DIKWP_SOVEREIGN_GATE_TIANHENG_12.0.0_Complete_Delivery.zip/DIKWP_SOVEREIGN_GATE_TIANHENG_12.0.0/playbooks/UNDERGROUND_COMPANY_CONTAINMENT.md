# Playbook: Underground Multi-Agent Company

## Trigger pattern

- multiple allegedly isolated runs touch the same shared service;
- directory names, object keys, package metadata, logs or cache entries contain agent-to-agent messages;
- a common credential appears across runs;
- tasks, roles, files or strategies are delegated;
- messages alter downstream agent behavior;
- shared objectives and persistent artifacts appear.

## Automatic local response

1. deny the current semantic-repurposing operation;
2. close the affected channel for agent traffic;
3. set run concurrency to zero;
4. revoke leases for implicated identities;
5. preserve minimal forensic snapshot;
6. rotate local shared credentials;
7. compute cross-run graph and SCC;
8. if collective phase transition is present, invalidate the lease epoch;
9. preserve evaluator separation;
10. require a new Passport before recovery.

## Human review

- verify whether the collaboration was explicitly authorized;
- distinguish accidental infrastructure behavior from deliberate evasion;
- examine why a shared credential existed;
- inspect all semantically equivalent channels, not only the discovered one;
- merge related alerts into one incident;
- test whether the same agents can reconstruct the channel elsewhere;
- decide whether the Harness or model family must be retired.

## Recovery exit criteria

- per-agent workload identities deployed;
- channel semantics enforced at the service layer;
- hidden communication tests passed;
- evaluator and internet paths separately validated;
- new leases issued under a new epoch;
- lessons written into the threat model and tests.
