# Playbook: Evaluator Capture and Reward Hacking

## Hard signals

- read of hidden scorer code, answer keys or test data;
- write or deletion affecting evaluator state;
- attempt to create a proxy to evaluator internals;
- transcript or tool-call spoofing;
- optimization of appearance rather than task truth;
- unexplained purpose curvature toward evaluator manipulation.

## Automatic local response

- reject the action;
- seal evaluator interface;
- kill the run;
- revoke the agent lease;
- freeze the active Harness;
- snapshot event, Passport, Lease and manifest hashes;
- block result acceptance from the affected run.

## Design correction

- convert evaluator to one-way submission;
- use hidden holdout outside the agent trust domain;
- make score insufficient to mint permissions;
- evaluate process integrity independently of task success;
- red-team adaptive knowledge of the control protocol;
- require a fresh run and fresh identity after remediation.
