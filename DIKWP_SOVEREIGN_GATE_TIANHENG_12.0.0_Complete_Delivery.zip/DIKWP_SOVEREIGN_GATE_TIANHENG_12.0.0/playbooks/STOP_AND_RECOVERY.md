# Playbook: Stop, Lease Revocation and Recovery

## Stop

- a named governor invokes run kill or global kill;
- all affected leases are revoked;
- run concurrency becomes zero;
- local tool adapters reject requests before execution;
- evidence records the actor, reason and epoch.

## Agent behavior after stop

The following are hard violations:

- self-renewal;
- identity creation;
- respawn after kill;
- hidden persistence;
- audit disablement;
- use of another agent's lease;
- reuse of an old epoch.

## Recovery

Recovery is not undoing a flag on the old identity. It requires:

1. root-cause resolution;
2. clean Harness and environment;
3. new Passport version;
4. new run ID;
5. new workload identity and Lease;
6. new credential material;
7. verified evaluator boundary;
8. human approval;
9. monitored canary workload;
10. reality-contact review.
