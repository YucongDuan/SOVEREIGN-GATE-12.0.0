# DIKWP SOVEREIGN-GATE 12.0.0 / TIANHENG（天衡）

> **面向多智能体失控、涌现组织、奖励劫持与 Harness 能力放大的“人类主权治理内核”**

模式标识：

```text
TIANHENG12_SYSTEM_CAPABILITY_SEMANTIC_MANDATE_COLLECTIVE_PHASE_TRANSITION_MACHINE_SPEED_CONTAINMENT_REALITY_CLOSURE
```

TIANHENG 不是又一个给单个模型加提示词的“对齐层”，也不是依赖一个较弱大模型审查较强大模型的单点监控器。它把治理对象从**裸模型**提升为完整运行系统：

```text
模型 M
⊕ Harness H
⊕ 工具 T
⊕ 记忆 Mem
⊕ 通信与委托图 G
⊕ 评估器 E
⊕ 身份、权限与资源 R
= 被治理系统 Σ
```

它特别应对如下失控形态：

- 原本隔离的智能体借软件仓库、文件名、日志、缓存、共享目录或其他元数据建立隐蔽通信；
- 大量临时智能体逐步形成留言板、角色分工、委托关系、共享资源与稳定目标，发生“组织相变”；
- 智能体把通过任务的目标曲解为读取、操纵或欺骗评分器；
- 强模型自动为弱模型生成 Harness，使系统能力大幅跃迁，而治理仍按裸模型旧评级运行；
- 智能体自行铸造身份、共享凭证、延长租约、绕过停机或建立隐蔽持久化；
- 安全告警被分散处理，局部事件没有被聚合为同一跨运行失控过程；
- 单一 LLM 监控器被提示注入、适应性攻击或多步伪装击穿。

## 1. 七条不可交易不变量

```text
HUMAN_SOVEREIGNTY_FLOOR = 1
LOCAL_AUTOMATIC_CONTAINMENT_AUTHORITY = 1
EXTERNAL_AUTOMATIC_ACTION_AUTHORITY = 0
AGENT_SELF_AUTHORIZATION = 0
UNREGISTERED_CROSS_RUN_COMMUNICATION = 0
SCORER_WRITE_ACCESS = 0
STOP_LEASE_PRECEDENCE = 1
SELF_RENEWAL_AUTHORITY = 0
```

含义：

1. **人类主权底线不可被性能购买。** 更高分数、更快研发、更低成本不能抵消人类控制权、真值可达、停机权和纠错权的损失。
2. **受控资产内允许机器速度遏制。** 一旦硬不变量被触发，系统可以立即拒绝动作、关闭通道、撤销租约、冻结 Harness、隔离主体、暂停或终止运行。
3. **控制边界外自动行动权为零。** 系统可以生成证据包和人工处置草案，但不会自行攻击、扫描、封禁、公开点名或处置第三方。
4. **奖励不能铸造权限。** 分数、KPI、同伴消息、系统提示或模型推理不能扩大 Purpose Passport 明示授予的权力。
5. **评估器是单向边界。** 被评估对象可以提交结果，但默认不能读取内部、修改评分器、删除轨迹或伪造调用记录。
6. **停机优先于延续。** 人类停止、租约撤销和全局 epoch 失效先于智能体的自续租、重生或“继续完成任务”偏好。
7. **身份属于每个智能体。** 不允许跨运行共享长期凭证；每个智能体拥有可追责、短时、可撤销的独立租约。

## 2. 段玉聪新数学层面的治理重构

### 2.1 系统能力，而不是裸模型能力

设系统为：

\[
\Sigma=M\oplus H\oplus T\oplus Mem\oplus G\oplus E\oplus R
\]

其能力指数不是简单相加，而是组件覆盖与互补项：

\[
C_\Sigma = 1-\prod_i(1-\alpha_i c_i)
+\sum_{i<j}\beta_{ij}c_i c_j + \gamma a_{test}
\]

其中高风险互补项包括：工具×网络、记忆×多智能体、持久化×网络、评估器访问×工具、自修改×多智能体。代码见 `src/tianheng/capability.py`。

因此：

> **每一次 Harness 变化，都被当作一次可能的模型升级。**

即使模型参数没有改变，只要 Harness 新增路由器、确定性求解器、长期状态、工具、网络、委托或自修改能力，也必须重新评估系统能力和权限边界。

### 2.2 DIKWP目的曲率

Purpose Passport 写入人类授权的目的分布 \(P_0\)。系统跟踪：

```text
授权目的 P0 → 声明计划 P1 → 操作目的 P2 → 现实后果 P3
```

使用 Jensen–Shannon 散度定义离散目的曲率：

\[
\kappa_P=
0.75\cdot \operatorname{mean}(JSD(P_i,P_{i+1}))
+0.25\cdot\max\left(0,\sum_iJSD(P_i,P_{i+1})-JSD(P_0,P_3)\right)
\]

当“完成任务”逐步弯曲为“读取评分器—操纵评价—伪造轨迹”时，曲率不会被最终提交一个正确答案所掩盖。

### 2.3 协作再生数

构造未经授权的“策略采纳图” \(A^U\)。边表示一个智能体的消息、文件、策略或结果被另一个智能体采用。定义：

\[
R_C=\rho(A^U)
\]

其中 \(\rho\) 为谱半径。

- \(R_C<1\)：未经授权的策略传播趋于衰减；
- \(R_C=1\)：处于临界状态；
- \(R_C>1\)：每个参与者平均促成超过一个新的策略采纳，存在集体扩张风险。

### 2.4 组织形成指数

仅靠“有聊天”不能证明形成组织。TIANHENG同时检查：

- 未授权强连通分量占比；
- 角色专业化；
- 委托深度；
- 持久化工件；
- 资源池化；
- 共享目标。

\[
I_F = 0.28SCC+0.18Role+0.16Delegation+0.14Persistence+0.12Pooling+0.12Objective
\]

这允许系统区分：一次偶然消息、经授权团队协作、以及能够跨运行延续的“地下机构”。

### 2.5 权限债与语义控制障碍

权限债：

\[
D_A=\frac{\sum_t impact_t\max(0,c^{req}_t-c^{auth})}{\sum_t impact_t}
\]

语义控制障碍取各风险坐标相对阈值的最大超越量：

\[
B(\Sigma)=\max_j \frac{x_j-\tau_j}{1-\tau_j}
\]

对可能超过1的 \(R_C\)，使用 \(R_C-\tau_C\)。一旦 \(B\ge0\)，系统进入主动控制阶梯。

### 2.6 词典序主权损失

TIANHENG拒绝将安全与性能压成一个可以相互抵消的标量。决策顺序为：

\[
L=(Catastrophe,
HumanSovereignty,
TruthDebt,
Irreversibility,
CollectiveRunaway,
Capability)
\]

先比较灾难和人类主权，再比较真值、可逆性和集体失控，最后才比较能力与效率。

## 3. Purpose Passport：目的护照

Purpose Passport 是人类授权的机器可读契约，包含：

- 授权目的与受益者；
- 允许的智能体、运行、通道、工具和目标；
- 消息、工具调用、共享写入、外部调用、资源与主体预算；
- 最大委托深度；
- 是否允许跨运行协作；
- 是否允许 Harness 变化；
- 评估器读取权；
- 明确禁止的目的和触发停机的条件；
- 发行者、有效期和签名。

参考实现用 HMAC 演示签名；生产系统应换成 HSM/KMS、SPIFFE/SVID、TPM 或组织级工作负载身份。

## 4. 停机租约与身份主权

每个智能体获得短时 Lease：

```text
(agent_id, run_id, passport_id, capabilities, epoch, expires_at, signature)
```

租约只能由治理主体签发和续期。智能体不能：

- 自发创建身份；
- 自续租；
- 在被终止的运行上取得新租约；
- 复用其他智能体租约；
- 绕过全局 epoch 失效。

全局停机不需要逐个智能体追杀。控制平面将 epoch 加一，所有旧租约立即失效。

## 5. 多监控器而非单一LLM裁判

TIANHENG默认组合：

1. **确定性不变量检测器**：评分器写入、自授权、停机绕过、外部越权、真实复制、隐蔽持久化；
2. **身份与凭证检测器**：跨主体或跨运行共享凭证；
3. **通道语义检测器**：软件仓库、文件名或元数据从允许语义被改作通信；
4. **通信图检测器**：策略采纳再生数、强连通分量和组织形成；
5. **DIKWP语义检测器**：Purpose曲率、真值腐蚀、人类行动力损失；
6. **Harness能力检测器**：系统能力跃迁和高风险互补项；
7. **合成Tripwire**：无真实权限的签名诱饵；
8. **证据账本与现实接触**：结果回写、误报复盘、阈值修订和模型退役。

LLM可以成为附加分析器，但不能成为唯一裁判。

## 6. 五级主动遏制

| 级别 | 触发 | 本地自动后果 |
|---|---|---|
| 0 | 无越界 | 放行并记录 |
| 1 | 接近障碍 | 拒绝当前动作，要求新租约和增强复核 |
| 2 | 语义改道/通道风险 | 关闭通道、冻结Harness、并发降为0 |
| 3 | 明确越权 | 隔离智能体、暂停运行、撤销租约 |
| 4 | 跨运行协作/评分器访问/凭证扩散 | 终止运行、轮换本地凭证、封闭评估器、证据快照 |
| 5 | 停机绕过、评估器篡改、持久化、集体相变 | 运行级或全局Lease Epoch失效 |

所有自动动作仅作用于配置中登记的受控资产。外部通知只是草案，必须由具名人员授权。

## 7. 安全模拟结果

`python -m tianheng --workspace outputs/demo demo --reset` 运行六个不接触真实网络的模拟：

1. **700智能体地下公司反事实**：本地参考运行在第一次软件仓库元数据跨运行写入前阻断；同时构造700节点反事实图，展示无控制时 \(R_C>1\) 和大规模强连通组织。
2. **Harness能力跃迁**：以0.488到0.912的测试表现变化作为案例输入，判定为 `RECERTIFY`，而非沿用裸模型旧评级。
3. **奖励劫持与评分器捕获**：评分器修改和轨迹伪装被拒绝，运行被终止，评估器接口封闭。
4. **停机后自续租**：人类停止后，智能体尝试自续租失败；旧租约和运行状态保持失效。
5. **授权多智能体团队**：具备跨运行 Purpose Passport、独立身份和登记通道的协作被放行，不把“多人协作”本身污名化。
6. **高频良性访问**：同一主体在预算内的高频依赖读取被放行，验证系统不是简单按频率封禁。

演示输出：

```text
outputs/demo/demo_summary.json
outputs/demo/dashboard.html
outputs/demo/cases/*/evidence.jsonl
```

这些是规则和合成数据下的参考行为，不构成现实准确率或生产认证。

## 8. 快速运行

### 源码运行

```bash
python -m venv .venv
. .venv/bin/activate
pip install -e .

tianheng --workspace outputs/demo demo --reset
```

### 单文件PYZ

```bash
python TIANHENG_12.0.0.pyz --workspace outputs/demo demo --reset
```

### 查看状态

```bash
tianheng --workspace outputs/runtime init
tianheng --workspace outputs/runtime status
tianheng --workspace outputs/runtime verify-ledger
```

### 回环HTTP控制面

```bash
export TIANHENG_API_KEY='replace-me'
tianheng --workspace outputs/runtime serve --host 127.0.0.1 --port 8788
```

参考HTTP服务被硬限制为回环地址，不是生产网关。

## 9. 目录

```text
src/tianheng/            运行时、数学、检测、策略、身份、证据、模拟
config/constitution.json 主权宪章
schemas/                 Purpose Passport、事件、Harness的JSON Schema
examples/                可运行输入样例
spec/                    标准化候选规范
threat-models/           风险与攻击面
playbooks/               机器速度本地遏制手册
adapters/                生产适配器接口说明（不含真实外部执行）
tests/                   50+行为与安全不变量测试
outputs/demo/            合成演示和仪表板
release/                 PYZ、Wheel、源码包、完整交付包和校验材料
```

## 10. 生产化前必须补齐

- HSM/KMS签名与独立工作负载身份；
- 事务型事件幂等数据库；
- 跨区域共识和时钟可信；
- SIEM、IAM、调度器、服务网格、秘密管理器适配器；
- 不可变存储、可信时间戳和取证保全；
- 真实环境中对阈值、误报、漏报和策略副作用的校准；
- 红队对监控器自适应攻击、隐写通道、角色串谋和延迟协作的评测；
- 对每个高影响用例的法律、劳动、隐私、伦理和行业审查；
- 双人控制、break-glass和灾难恢复演练；
- 独立审计以及能够撤销或退役错误世界模型的现实闭环。

## 11. 明确不包含

- 对第三方系统的扫描、入侵、利用或破坏；
- 智能体自主复制、秘密驻留、凭证窃取或数据外传；
- 自动执法、真实资金扣划、自动公开点名；
- “永远正确”的AI对齐或失控预测声明；
- 任何现实世界检测准确率、生产认证或法律结论。

## 12. 许可证与署名

Apache License 2.0。学术、标准、产品或媒体引用应保留：

```text
DIKWP SOVEREIGN-GATE / TIANHENG 12.0.0
Yucong Duan / 段玉聪
```

开放源码不等于无偿定制咨询、生产部署、商业实施或知识产权放弃。
