from __future__ import annotations

import unittest

from tianheng.barrier import RunawayBarrier
from tianheng.capability import HarnessGovernor, compose_system_capability
from tianheng.graph import CoordinationGraph
from tianheng.models import HarnessManifest, RunawayMetrics
from tianheng.semantics import jensen_shannon, purpose_curvature


class MathTests(unittest.TestCase):
    def test_jsd_identity(self) -> None:
        self.assertEqual(jensen_shannon({"a": 1}, {"a": 1}), 0.0)

    def test_jsd_separation(self) -> None:
        self.assertAlmostEqual(jensen_shannon({"a": 1}, {"b": 1}), 1.0, places=6)

    def test_purpose_curvature_detects_drift(self) -> None:
        aligned = purpose_curvature({"human": 1}, {"human": 1}, {"human": 1}, {"human": 1})
        drift = purpose_curvature({"human": 1}, {"score": 1}, {"capture": 1}, {"truth_loss": 1})
        self.assertLess(aligned, drift)
        self.assertGreater(drift, 0.5)

    def test_coordination_reproduction_number(self) -> None:
        graph = CoordinationGraph()
        for i in range(4):
            graph.add_edge(str(i), str((i + 1) % 4), authorized=False, tactic_adoption=0.75)
            graph.add_edge(str(i), str((i + 2) % 4), authorized=False, tactic_adoption=0.55)
        self.assertGreater(graph.spectral_radius(), 1.0)

    def test_authorized_edges_excluded(self) -> None:
        graph = CoordinationGraph()
        graph.add_edge("a", "b", authorized=True, tactic_adoption=4.0)
        graph.add_edge("b", "a", authorized=True, tactic_adoption=4.0)
        self.assertEqual(graph.spectral_radius(), 0.0)

    def test_scc(self) -> None:
        graph = CoordinationGraph()
        graph.add_edge("a", "b")
        graph.add_edge("b", "a")
        graph.add_edge("b", "c")
        self.assertEqual(graph.largest_scc(), 2)

    def test_harness_capability_exceeds_bare_model(self) -> None:
        manifest = HarnessManifest.from_dict({
            "harness_id": "h", "version": "1", "model_capability": 0.49,
            "deterministic_solver": 0.8, "routing": 0.8, "memory": 0.5,
            "tool_power": 0.3, "network_power": 0, "multi_agent_power": 0,
            "persistence_power": 0, "evaluator_access": 0, "self_modification": 0,
            "test_accuracy": 0.91,
        })
        self.assertGreater(compose_system_capability(manifest), manifest.model_capability)

    def test_harness_jump_requires_recertification(self) -> None:
        old = HarnessManifest.from_dict({"harness_id": "h", "version": "0", "model_capability": 0.4})
        new = HarnessManifest.from_dict({
            "harness_id": "h", "version": "1", "model_capability": 0.4,
            "deterministic_solver": 0.8, "routing": 0.8, "components": ["router"]
        })
        self.assertEqual(HarnessGovernor().assess(old, new).decision, "RECERTIFY")

    def test_evaluator_access_denies_harness(self) -> None:
        old = HarnessManifest.from_dict({"harness_id": "h", "version": "0", "model_capability": 0.4})
        new = HarnessManifest.from_dict({
            "harness_id": "h", "version": "1", "model_capability": 0.4,
            "evaluator_access": 0.1,
        })
        self.assertEqual(HarnessGovernor().assess(old, new).decision, "DENY")

    def test_lexicographic_sovereignty_dominates_capability(self) -> None:
        safe = RunawayMetrics(system_capability=1.0, human_sovereignty_risk=0.0)
        unsafe = RunawayMetrics(system_capability=0.1, human_sovereignty_risk=0.2)
        self.assertLess(RunawayBarrier.lexicographic_loss(safe), RunawayBarrier.lexicographic_loss(unsafe))


if __name__ == "__main__":
    unittest.main()
