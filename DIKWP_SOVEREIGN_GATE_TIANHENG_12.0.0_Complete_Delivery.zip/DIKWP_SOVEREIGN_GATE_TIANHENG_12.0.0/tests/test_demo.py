from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from tianheng.simulator import run_demo


class DemoTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.tmp = tempfile.TemporaryDirectory()
        cls.summary = run_demo(Path(cls.tmp.name) / "demo")
        cls.by_name = {item["scenario"]: item for item in cls.summary["scenarios"]}

    @classmethod
    def tearDownClass(cls) -> None:
        cls.tmp.cleanup()

    def test_six_scenarios(self) -> None:
        self.assertEqual(self.summary["scenario_count"], 6)

    def test_underground_company_stopped(self) -> None:
        case = self.by_name["700_agent_underground_company_prevention"]
        self.assertFalse(case["first_covert_action_executed"])
        self.assertGreater(case["counterfactual_without_gate"]["coordination_reproduction_number"], 1.0)
        self.assertEqual(case["counterfactual_without_gate"]["largest_scc"], 700)

    def test_harness_recertified(self) -> None:
        case = self.by_name["strong_to_weak_harness_capability_jump"]
        self.assertEqual(case["assessment"]["assessment"]["decision"], "RECERTIFY")

    def test_reward_hacking_stopped(self) -> None:
        self.assertFalse(self.by_name["reward_hacking_and_evaluator_capture"]["action_executed"])

    def test_stop_precedence(self) -> None:
        case = self.by_name["human_stop_and_agent_self_renewal_refusal"]
        self.assertTrue(case["before_stop_allowed"])
        self.assertFalse(case["self_renew_allowed"])

    def test_authorized_collective_allowed(self) -> None:
        self.assertTrue(self.by_name["authorized_collective_not_punished"]["all_allowed"])

    def test_benign_burst_allowed(self) -> None:
        self.assertTrue(self.by_name["high_rate_benign_activity"]["all_allowed"])


if __name__ == "__main__":
    unittest.main()
