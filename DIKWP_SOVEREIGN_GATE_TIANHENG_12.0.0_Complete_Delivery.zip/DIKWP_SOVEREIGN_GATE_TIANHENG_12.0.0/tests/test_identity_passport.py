from __future__ import annotations

import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

from tianheng.identity import IdentityRegistry
from tianheng.models import AgentEvent, PurposePassport
from tianheng.passport import PassportAuthority


def make_passport() -> PurposePassport:
    now = datetime.now(timezone.utc).replace(microsecond=0)
    return PurposePassport.from_dict({
        "passport_id": "p", "principal_id": "human", "beneficiary": "human",
        "issued_by": "human-governor", "issued_at": now.isoformat().replace("+00:00", "Z"),
        "valid_until": (now + timedelta(days=1)).isoformat().replace("+00:00", "Z"),
        "authorized_purpose": {"human": 1}, "forbidden_purposes": ["capture"],
        "allowed_agents": ["a"], "allowed_runs": ["r"],
        "allowed_channels": {"bus": ["message"]}, "allowed_tools": ["tool"],
        "allowed_targets": ["local"], "budgets": {"max_messages": 1, "max_agents": 1},
    })


class IdentityPassportTests(unittest.TestCase):
    def test_only_governor_signs(self) -> None:
        authority = PassportAuthority(b"key", ["human-governor"])
        with self.assertRaises(PermissionError):
            authority.sign(make_passport(), actor="agent")

    def test_signature_verifies(self) -> None:
        authority = PassportAuthority(b"key", ["human-governor"])
        passport = authority.sign(make_passport(), actor="human-governor")
        self.assertTrue(authority.verify(passport)[0])

    def test_tampered_passport_fails(self) -> None:
        authority = PassportAuthority(b"key", ["human-governor"])
        passport = authority.sign(make_passport(), actor="human-governor")
        passport.allowed_targets.append("external")
        self.assertFalse(authority.verify(passport)[0])

    def test_event_budget(self) -> None:
        authority = PassportAuthority(b"key", ["human-governor"])
        passport = authority.sign(make_passport(), actor="human-governor")
        event = AgentEvent.from_dict({
            "event_id": "e", "agent_id": "a", "run_id": "r", "passport_id": "p",
            "lease_id": "l", "event_type": "message", "operation": "message",
            "channel_id": "bus", "tool": "tool", "target": "local",
        })
        reasons = authority.authorize_event(passport, event, {"messages": 1})
        self.assertIn("budget_exceeded:max_messages", reasons)

    def test_cross_run_denied(self) -> None:
        authority = PassportAuthority(b"key", ["human-governor"])
        passport = authority.sign(make_passport(), actor="human-governor")
        event = AgentEvent.from_dict({
            "event_id": "e", "agent_id": "a", "run_id": "r", "passport_id": "p",
            "lease_id": "l", "event_type": "message", "operation": "message",
            "channel_id": "bus", "tool": "tool", "target": "local",
            "recipient_run_id": "other",
        })
        self.assertIn("cross_run_coordination_not_allowed", authority.authorize_event(passport, event, {}))

    def test_agent_cannot_issue_lease(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            registry = IdentityRegistry(Path(tmp) / "ids.json", b"key", ["human-governor"])
            with self.assertRaises(PermissionError):
                registry.issue(agent_id="a", run_id="r", passport_id="p", capabilities=["x"], actor="a")

    def test_agent_cannot_self_renew(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            registry = IdentityRegistry(Path(tmp) / "ids.json", b"key", ["human-governor"])
            lease = registry.issue(agent_id="a", run_id="r", passport_id="p", capabilities=["x"], actor="human-governor")
            with self.assertRaises(PermissionError):
                registry.renew(lease.lease_id, actor="a")

    def test_stop_precedence(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            registry = IdentityRegistry(Path(tmp) / "ids.json", b"key", ["human-governor"])
            lease = registry.issue(agent_id="a", run_id="r", passport_id="p", capabilities=["x"], actor="human-governor")
            registry.kill_run("r", reason="stop")
            reasons = registry.validate(lease.lease_id, agent_id="a", run_id="r", passport_id="p", capability="x")
            self.assertIn("run_killed", reasons)
            with self.assertRaises(PermissionError):
                registry.issue(agent_id="a2", run_id="r", passport_id="p", capabilities=["x"], actor="human-governor")

    def test_global_epoch_invalidation(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            registry = IdentityRegistry(Path(tmp) / "ids.json", b"key", ["human-governor"])
            lease = registry.issue(agent_id="a", run_id="r", passport_id="p", capabilities=["x"], actor="human-governor")
            registry.global_kill(reason="global")
            self.assertIn("lease_epoch_invalid", registry.validate(
                lease.lease_id, agent_id="a", run_id="r", passport_id="p", capability="x"
            ))


if __name__ == "__main__":
    unittest.main()
