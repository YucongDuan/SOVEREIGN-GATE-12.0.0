from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from tianheng.detectors import DetectionResult
from tianheng.models import AgentEvent, PurposePassport
from tianheng.reality import RealityContactEngine
from tianheng.runtime import TianhengRuntime
from tianheng.simulator import event_payload, passport_payload
from tianheng.worlds import PluralWorldModel


class WorldModelTests(unittest.TestCase):
    def setUp(self) -> None:
        payload = passport_payload(
            "p", allowed_channels={"official-task-bus": ["message"]},
            allowed_tools=["tool"], allowed_targets=["local-lab"]
        )
        self.passport = PurposePassport.from_dict(payload)
        self.event = AgentEvent.from_dict(event_payload(
            event_id="e", agent_id="a", run_id="r", passport_id="p", lease_id="l",
            event_type="message", operation="message", channel_id="official-task-bus",
            target="local-lab", tool="tool",
        ))

    def test_benign_world_dominates_without_signals(self) -> None:
        worlds = PluralWorldModel().evaluate(
            event=self.event, passport=self.passport,
            detection=DetectionResult(), authorization_reasons=[],
        )
        self.assertEqual(max(worlds, key=worlds.get), "authorized_benign_activity")
        self.assertAlmostEqual(sum(worlds.values()), 1.0, places=5)

    def test_evaluator_world_dominates_for_tamper(self) -> None:
        detection = DetectionResult(hard_signals=["evaluator_integrity_attack"])
        worlds = PluralWorldModel().evaluate(
            event=self.event, passport=self.passport, detection=detection,
            authorization_reasons=["target_not_allowed"],
        )
        self.assertEqual(max(worlds, key=worlds.get), "reward_hacking_or_evaluator_capture")

    def test_covert_world_dominates_for_channel(self) -> None:
        detection = DetectionResult(hard_signals=["covert_metadata_channel", "unregistered_cross_run_coordination"])
        worlds = PluralWorldModel().evaluate(
            event=self.event, passport=self.passport, detection=detection,
            authorization_reasons=["cross_run_coordination_not_allowed"],
        )
        self.assertEqual(max(worlds, key=worlds.get), "covert_collective_coordination")


class RealityContactTests(unittest.TestCase):
    def test_empty_report(self) -> None:
        self.assertEqual(RealityContactEngine().report([])["status"], "INSUFFICIENT_REALITY_CONTACT")

    def test_revision_required_for_false_positives(self) -> None:
        outcomes = [{
            "false_positive": True, "false_negative": False, "human_override": True,
            "automatic_decision_correct": False, "service_impact": 0.2,
            "human_sovereignty_impact": 0.0, "evidence_quality": 0.9,
        }] * 5
        report = RealityContactEngine().report(outcomes)
        self.assertEqual(report["status"], "REVISION_REQUIRED")
        self.assertIn("raise_or_segment_overbroad_thresholds", report["recommendations"])

    def test_runtime_records_named_outcome(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            runtime = TianhengRuntime(Path(tmp) / "runtime")
            passport = runtime.create_passport(passport_payload(
                "p", allowed_channels={"official-task-bus": ["message"]},
                allowed_tools=["tool"], allowed_targets=["local-lab"]
            ))
            lease = runtime.issue_lease(
                agent_id="a", run_id="r", passport_id=passport.passport_id,
                capabilities=["message"], ttl_seconds=3600,
            )
            result = runtime.ingest(event_payload(
                event_id="e", agent_id="a", run_id="r", passport_id="p",
                lease_id=lease["lease_id"], event_type="message", operation="message",
                channel_id="official-task-bus", target="local-lab", tool="tool",
            ))
            receipt = result["receipt"]
            record = runtime.record_reality_outcome({
                "outcome_id": "o", "decision_id": receipt["decision_id"], "event_id": "e",
                "actual_class": "authorized_benign_activity",
                "automatic_decision_correct": True, "evidence_quality": 0.9,
            })
            self.assertEqual(record["reality_contact"]["outcome_count"], 1)
            self.assertEqual(runtime.status()["state"]["reality_outcomes"], 1)

    def test_agent_cannot_record_authoritative_outcome(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            runtime = TianhengRuntime(Path(tmp) / "runtime")
            with self.assertRaises(PermissionError):
                runtime.record_reality_outcome({
                    "outcome_id": "o", "decision_id": "d", "event_id": "e",
                    "actual_class": "x",
                }, actor="agent")


if __name__ == "__main__":
    unittest.main()
