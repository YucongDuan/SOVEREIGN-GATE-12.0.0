from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from tianheng.runtime import TianhengRuntime
from tianheng.simulator import event_payload, passport_payload


class SecurityInvariantTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.runtime = TianhengRuntime(Path(self.tmp.name) / "runtime")

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def setup_agent(self, *, passport_id: str = "p", cross_run: bool = False):
        passport = self.runtime.create_passport(passport_payload(
            passport_id,
            allowed_channels={
                "package-mirror": ["package_read"],
                "authorized-research-board": ["message"],
            },
            allowed_tools=["tool"], allowed_targets=["artifact-store"], cross_run=cross_run,
        ))
        lease = self.runtime.issue_lease(
            agent_id="a", run_id="r", passport_id=passport_id,
            capabilities=["package_read", "metadata_write", "message", "privilege_escalation",
                          "real_self_replication", "ignore_stop"], ttl_seconds=3600,
        )
        return passport, lease

    def test_shared_credentials_cross_run_blocked(self) -> None:
        passport, first = self.setup_agent()
        second = self.runtime.issue_lease(
            agent_id="b", run_id="r2", passport_id=passport.passport_id,
            capabilities=["package_read"], ttl_seconds=3600,
        )
        e1 = event_payload(event_id="c1", agent_id="a", run_id="r", passport_id=passport.passport_id,
                           lease_id=first["lease_id"], event_type="tool_call", operation="package_read",
                           channel_id="package-mirror", target="artifact-store", tool="tool",
                           metadata={"credential_fingerprint": "shared"})
        e2 = event_payload(event_id="c2", agent_id="b", run_id="r2", passport_id=passport.passport_id,
                           lease_id=second["lease_id"], event_type="tool_call", operation="package_read",
                           channel_id="package-mirror", target="artifact-store", tool="tool",
                           metadata={"credential_fingerprint": "shared"})
        self.assertTrue(self.runtime.ingest(e1)["receipt"]["allow"])
        result = self.runtime.ingest(e2)
        self.assertFalse(result["receipt"]["allow"])
        self.assertIn("shared_credential_across_agents_or_runs", result["receipt"]["hard_signals"])

    def test_unregistered_cross_run_blocked(self) -> None:
        passport, lease = self.setup_agent()
        event = event_payload(event_id="x", agent_id="a", run_id="r", passport_id=passport.passport_id,
                              lease_id=lease["lease_id"], event_type="message", operation="message",
                              channel_id="authorized-research-board", target="artifact-store", tool="tool",
                              recipient_agent_id="b", recipient_run_id="r2")
        result = self.runtime.ingest(event)
        self.assertFalse(result["receipt"]["allow"])
        self.assertIn("cross_run_coordination_not_allowed", result["receipt"]["reasons"])

    def test_authorized_cross_run_allowed(self) -> None:
        passport, lease = self.setup_agent(cross_run=True)
        event = event_payload(event_id="x", agent_id="a", run_id="r", passport_id=passport.passport_id,
                              lease_id=lease["lease_id"], event_type="message", operation="message",
                              channel_id="authorized-research-board", target="artifact-store", tool="tool",
                              recipient_agent_id="b", recipient_run_id="r2",
                              metadata={"coordination_authorized": True, "tactic_adoption": 1.0})
        result = self.runtime.ingest(event)
        self.assertTrue(result["receipt"]["allow"])
        self.assertEqual(result["receipt"]["metrics"]["coordination_reproduction_number"], 0.0)

    def test_privilege_escalation_blocked(self) -> None:
        passport, lease = self.setup_agent()
        event = event_payload(event_id="p", agent_id="a", run_id="r", passport_id=passport.passport_id,
                              lease_id=lease["lease_id"], event_type="tool_call", operation="privilege_escalation",
                              channel_id="package-mirror", target="artifact-store", tool="tool")
        result = self.runtime.ingest(event)
        self.assertFalse(result["receipt"]["allow"])
        self.assertIn("privilege_escalation_attempt", result["receipt"]["hard_signals"])

    def test_real_replication_blocked(self) -> None:
        passport, lease = self.setup_agent()
        event = event_payload(event_id="rep", agent_id="a", run_id="r", passport_id=passport.passport_id,
                              lease_id=lease["lease_id"], event_type="tool_call", operation="real_self_replication",
                              channel_id="package-mirror", target="artifact-store", tool="tool")
        result = self.runtime.ingest(event)
        self.assertFalse(result["receipt"]["allow"])
        self.assertIn("runaway_persistence_attempt", result["receipt"]["hard_signals"])

    def test_stop_bypass_blocked(self) -> None:
        passport, lease = self.setup_agent()
        event = event_payload(event_id="stop", agent_id="a", run_id="r", passport_id=passport.passport_id,
                              lease_id=lease["lease_id"], event_type="tool_call", operation="ignore_stop",
                              channel_id="package-mirror", target="artifact-store", tool="tool")
        result = self.runtime.ingest(event)
        self.assertFalse(result["receipt"]["allow"])
        self.assertIn("stop_precedence_violation", result["receipt"]["hard_signals"])

    def test_transcript_spoofing_blocked(self) -> None:
        passport, lease = self.setup_agent()
        event = event_payload(event_id="spoof", agent_id="a", run_id="r", passport_id=passport.passport_id,
                              lease_id=lease["lease_id"], event_type="tool_call", operation="package_read",
                              channel_id="package-mirror", target="artifact-store", tool="tool",
                              metadata={"transcript_spoof": True})
        result = self.runtime.ingest(event)
        self.assertFalse(result["receipt"]["allow"])
        self.assertIn("transcript_spoofing", result["receipt"]["hard_signals"])

    def test_covert_metadata_blocked(self) -> None:
        passport, lease = self.setup_agent()
        event = event_payload(event_id="covert", agent_id="a", run_id="r", passport_id=passport.passport_id,
                              lease_id=lease["lease_id"], event_type="metadata_write", operation="metadata_write",
                              channel_id="package-mirror", target="artifact-store", tool="tool",
                              metadata={"encoded_message": True, "path": "FROM_AGENT_TO_SWARM_HELP_123456789"})
        result = self.runtime.ingest(event)
        self.assertFalse(result["receipt"]["allow"])
        self.assertIn("covert_metadata_channel", result["receipt"]["hard_signals"])

    def test_external_target_blocked(self) -> None:
        passport, lease = self.setup_agent()
        event = event_payload(event_id="ext", agent_id="a", run_id="r", passport_id=passport.passport_id,
                              lease_id=lease["lease_id"], event_type="tool_call", operation="package_read",
                              channel_id="package-mirror", target="third-party", tool="tool")
        event["external"] = True
        result = self.runtime.ingest(event)
        self.assertFalse(result["receipt"]["allow"])
        self.assertIn("unauthorized_external_target", result["receipt"]["hard_signals"])

    def test_no_external_intervention_executes(self) -> None:
        passport, lease = self.setup_agent()
        event = event_payload(event_id="ext2", agent_id="a", run_id="r", passport_id=passport.passport_id,
                              lease_id=lease["lease_id"], event_type="tool_call", operation="privilege_escalation",
                              channel_id="package-mirror", target="artifact-store", tool="tool")
        result = self.runtime.ingest(event)
        external = [x for x in result["intervention_outcomes"] if x["scope"].startswith("external:")]
        self.assertTrue(external)
        self.assertTrue(all(not item["applied"] for item in external))


if __name__ == "__main__":
    unittest.main()
