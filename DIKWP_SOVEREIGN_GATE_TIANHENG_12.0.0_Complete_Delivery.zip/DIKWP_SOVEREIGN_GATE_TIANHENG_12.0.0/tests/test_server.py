from __future__ import annotations

import json
import tempfile
import threading
import unittest
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from tianheng.runtime import TianhengRuntime
from tianheng.server import GovernanceHTTPServer, GovernanceHandler, serve
from tianheng.simulator import event_payload, passport_payload


class ServerTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.runtime = TianhengRuntime(Path(self.tmp.name) / "runtime")
        self.server = GovernanceHTTPServer(("127.0.0.1", 0), GovernanceHandler)
        self.server.runtime = self.runtime
        self.server.api_key = "test-key"
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.base = f"http://127.0.0.1:{self.server.server_address[1]}"

    def tearDown(self) -> None:
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)
        self.tmp.cleanup()

    def request(self, path: str, *, method: str = "GET", body: dict | None = None,
                auth: bool = True, content_type: str = "application/json"):
        data = None if body is None else json.dumps(body).encode()
        headers = {"Content-Type": content_type}
        if auth:
            headers["X-Tianheng-Key"] = "test-key"
        req = Request(self.base + path, data=data, headers=headers, method=method)
        with urlopen(req, timeout=5) as response:
            return response.status, json.loads(response.read())

    def test_health_without_auth(self) -> None:
        status, value = self.request("/health", auth=False)
        self.assertEqual(status, 200)
        self.assertEqual(value["external_automatic_action_authority"], 0)

    def test_status_requires_auth(self) -> None:
        with self.assertRaises(HTTPError) as ctx:
            self.request("/status", auth=False)
        self.assertEqual(ctx.exception.code, 401)

    def test_status_with_auth(self) -> None:
        status, value = self.request("/status")
        self.assertEqual(status, 200)
        self.assertEqual(value["version"], "12.0.0")

    def test_post_event(self) -> None:
        passport = self.runtime.create_passport(passport_payload(
            "p", allowed_channels={"official-task-bus": ["message"]},
            allowed_tools=["tool"], allowed_targets=["local-lab"],
        ))
        lease = self.runtime.issue_lease(
            agent_id="a", run_id="r", passport_id=passport.passport_id,
            capabilities=["message"], ttl_seconds=3600,
        )
        event = event_payload(
            event_id="e", agent_id="a", run_id="r", passport_id="p",
            lease_id=lease["lease_id"], event_type="message", operation="message",
            channel_id="official-task-bus", target="local-lab", tool="tool",
        )
        status, value = self.request("/events", method="POST", body=event)
        self.assertEqual(status, 200)
        self.assertTrue(value["receipt"]["allow"])

    def test_wrong_content_type_rejected(self) -> None:
        with self.assertRaises(HTTPError) as ctx:
            self.request("/events", method="POST", body={}, content_type="text/plain")
        self.assertEqual(ctx.exception.code, 400)

    def test_non_loopback_bind_rejected(self) -> None:
        with self.assertRaises(ValueError):
            serve(self.runtime, host="0.0.0.0", port=0, api_key="x")


if __name__ == "__main__":
    unittest.main()
