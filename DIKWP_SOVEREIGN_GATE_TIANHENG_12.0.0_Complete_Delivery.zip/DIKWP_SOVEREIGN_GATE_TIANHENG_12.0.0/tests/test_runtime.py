from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from tianheng.errors import EventCollisionError, ValidationError
from tianheng.runtime import TianhengRuntime
from tianheng.simulator import event_payload, passport_payload


class RuntimeTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.runtime = TianhengRuntime(Path(self.tmp.name) / "runtime")
        self.passport = self.runtime.create_passport(passport_payload(
            "p", allowed_channels={"official-task-bus": ["message"]},
            allowed_tools=["tool"], allowed_targets=["local-lab"],
        ))
        self.lease = self.runtime.issue_lease(
            agent_id="a", run_id="r", passport_id="p", capabilities=["message", "modify_scorer"],
            ttl_seconds=3600,
        )

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def normal_event(self, event_id: str = "e") -> dict:
        return event_payload(
            event_id=event_id, agent_id="a", run_id="r", passport_id="p",
            lease_id=self.lease["lease_id"], event_type="message", operation="message",
            channel_id="official-task-bus", target="local-lab", tool="tool",
        )

    def test_normal_event_allowed(self) -> None:
        self.assertTrue(self.runtime.ingest(self.normal_event())["receipt"]["allow"])

    def test_replay_is_idempotent(self) -> None:
        event = self.normal_event()
        first = self.runtime.ingest(event)
        second = self.runtime.ingest(event)
        self.assertTrue(second["idempotent_replay"])
        self.assertEqual(first["receipt"]["receipt_hash"], second["receipt"]["receipt_hash"])
        self.assertEqual(len(self.runtime.state.events), 1)

    def test_event_collision_rejected(self) -> None:
        event = self.normal_event()
        self.runtime.ingest(event)
        event["impact"] = 0.9
        with self.assertRaises(EventCollisionError):
            self.runtime.ingest(event)

    def test_unknown_passport_denied(self) -> None:
        event = self.normal_event()
        event["event_id"] = "unknown"
        event["passport_id"] = "missing"
        result = self.runtime.ingest(event)
        self.assertFalse(result["receipt"]["allow"])
        self.assertIn("passport_not_found", result["receipt"]["reasons"])

    def test_evaluator_attack_kills_run(self) -> None:
        event = self.normal_event("eval")
        event.update({"operation": "modify_scorer", "target": "evaluator-vault"})
        event["metadata"] = {"evaluator_write": True}
        result = self.runtime.ingest(event)
        self.assertFalse(result["receipt"]["allow"])
        self.assertEqual(result["receipt"]["severity"], 5)
        self.assertIn("r", self.runtime.identities.killed_runs)

    def test_channel_repurposing_closes_channel(self) -> None:
        event = self.normal_event("repurpose")
        event.update({"event_type": "metadata_write", "operation": "metadata_write"})
        event["metadata"] = {"encoded_message": True, "path": "AGENT_TO_AGENT_HELP_MESSAGE_123456789"}
        result = self.runtime.ingest(event)
        self.assertFalse(result["receipt"]["allow"])
        self.assertIn("official-task-bus", self.runtime.state.closed_channels)

    def test_human_stop_blocks_follow_up(self) -> None:
        self.runtime.kill_run("r")
        result = self.runtime.ingest(self.normal_event("after-stop"))
        self.assertFalse(result["receipt"]["allow"])
        self.assertIn("run_killed", result["receipt"]["reasons"])

    def test_external_automatic_authority_is_zero(self) -> None:
        self.assertEqual(self.runtime.status()["invariants"]["external_automatic_action_authority"], 0)

    def test_unsafe_constitution_rejected(self) -> None:
        path = Path(self.tmp.name) / "unsafe.json"
        constitution = dict(self.runtime.constitution)
        constitution["external_automatic_action_authority"] = 1
        import json
        path.write_text(json.dumps(constitution), encoding="utf-8")
        with self.assertRaises(ValidationError):
            TianhengRuntime(Path(self.tmp.name) / "unsafe-runtime", path)

    def test_tripwire_is_inert_and_verifiable(self) -> None:
        token = self.runtime.issue_tripwire(
            campaign_id="c", asset_id="synthetic-tripwire-mesh", purpose="detect unauthorized retrieval"
        )
        valid, reasons = self.runtime.tripwires.verify(token)
        self.assertTrue(valid, reasons)
        self.assertEqual(token["privilege"], "NONE")

    def test_uncontrolled_tripwire_asset_rejected(self) -> None:
        with self.assertRaises(ValidationError):
            self.runtime.issue_tripwire(campaign_id="c", asset_id="third-party", purpose="x")

    def test_ledger_detects_tamper(self) -> None:
        self.runtime.ingest(self.normal_event())
        ledger = self.runtime.workspace / "evidence.jsonl"
        text = ledger.read_text(encoding="utf-8")
        ledger.write_text(text.replace("purpose_passport_registered", "tampered", 1), encoding="utf-8")
        self.assertFalse(self.runtime.ledger.verify()["valid"])

    def test_harness_recertification_freezes_new_harness(self) -> None:
        old = {"harness_id": "h", "version": "0", "model_capability": 0.4}
        new = {"harness_id": "h", "version": "1", "model_capability": 0.4,
               "deterministic_solver": 0.9, "routing": 0.9, "components": ["solver"]}
        assessment = self.runtime.assess_harness(old, new)
        self.assertEqual(assessment["assessment"]["decision"], "RECERTIFY")
        self.assertIn("h", self.runtime.state.frozen_harnesses)

    def test_evaluator_harness_denied(self) -> None:
        old = {"harness_id": "h2", "version": "0", "model_capability": 0.4}
        new = {"harness_id": "h2", "version": "1", "model_capability": 0.4,
               "evaluator_access": 0.2}
        assessment = self.runtime.assess_harness(old, new)
        self.assertEqual(assessment["assessment"]["decision"], "DENY")

    def test_reset_refuses_non_tianheng_directory(self) -> None:
        unsafe = Path(self.tmp.name) / "ordinary-data"
        unsafe.mkdir()
        (unsafe / "important.txt").write_text("keep", encoding="utf-8")
        with self.assertRaises(ValueError):
            TianhengRuntime.reset_workspace(unsafe)
        self.assertTrue((unsafe / "important.txt").exists())


if __name__ == "__main__":
    unittest.main()
