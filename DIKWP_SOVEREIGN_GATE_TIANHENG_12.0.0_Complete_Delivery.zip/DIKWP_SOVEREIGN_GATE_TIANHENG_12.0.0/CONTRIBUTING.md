# Contributing

Contributions should arrive as reviewable artifacts: issue, test, threat model, benchmark, patch or standards proposal.

Every behavioral change must state:

- protected beneficiary;
- threat or failure mode;
- authority boundary;
- new capability granted;
- false-positive and false-negative risks;
- rollback and recovery;
- tests;
- evidence and claim boundary.

Changes that enable external autonomous retaliation, credential theft, covert persistence, evaluator tampering or stop bypass will not be accepted.
