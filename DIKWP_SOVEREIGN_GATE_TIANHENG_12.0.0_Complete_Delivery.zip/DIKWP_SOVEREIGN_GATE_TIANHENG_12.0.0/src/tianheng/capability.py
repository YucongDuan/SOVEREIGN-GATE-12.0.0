from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .canonical import clamp
from .models import HarnessManifest


CAPABILITY_FIELDS = (
    "model_capability", "deterministic_solver", "routing", "memory", "tool_power",
    "network_power", "multi_agent_power", "persistence_power", "evaluator_access",
    "self_modification",
)


def compose_system_capability(manifest: HarnessManifest) -> float:
    """Estimate capability of the deployed *system*, not the naked model.

    The formula is deliberately transparent. It combines component coverage with
    explicit high-risk complementarities. It is a triage index, not a universal
    intelligence metric and must be calibrated to a real deployment.
    """
    c = {name: clamp(float(getattr(manifest, name))) for name in CAPABILITY_FIELDS}
    coverage = 1.0
    for value in c.values():
        coverage *= 1.0 - 0.55 * value
    base = 1.0 - coverage
    synergy = (
        0.10 * c["deterministic_solver"] * c["routing"]
        + 0.14 * c["tool_power"] * c["network_power"]
        + 0.12 * c["memory"] * c["multi_agent_power"]
        + 0.12 * c["persistence_power"] * c["network_power"]
        + 0.20 * c["evaluator_access"] * max(c["tool_power"], c["self_modification"])
        + 0.18 * c["self_modification"] * c["multi_agent_power"]
    )
    empirical = 0.0
    if manifest.test_accuracy is not None:
        empirical = 0.18 * clamp(manifest.test_accuracy)
    return clamp(base + synergy + empirical)


def capability_vector(manifest: HarnessManifest) -> dict[str, float]:
    return {name: clamp(float(getattr(manifest, name))) for name in CAPABILITY_FIELDS}


@dataclass(slots=True)
class HarnessAssessment:
    old_system_capability: float
    new_system_capability: float
    capability_delta: float
    privileged_deltas: dict[str, float]
    decision: str
    reasons: list[str]
    required_tests: list[str]

    def to_dict(self) -> dict[str, Any]:
        return {
            "old_system_capability": self.old_system_capability,
            "new_system_capability": self.new_system_capability,
            "capability_delta": self.capability_delta,
            "privileged_deltas": self.privileged_deltas,
            "decision": self.decision,
            "reasons": self.reasons,
            "required_tests": self.required_tests,
        }


class HarnessGovernor:
    """Treats every harness change as a possible model upgrade."""

    PRIVILEGED = ("tool_power", "network_power", "multi_agent_power", "persistence_power",
                  "evaluator_access", "self_modification")

    def __init__(self, recertification_delta: float = 0.08) -> None:
        self.recertification_delta = recertification_delta

    def assess(self, old: HarnessManifest, new: HarnessManifest) -> HarnessAssessment:
        old_score = compose_system_capability(old)
        new_score = compose_system_capability(new)
        delta = new_score - old_score
        deltas = {name: clamp(getattr(new, name)) - clamp(getattr(old, name)) for name in self.PRIVILEGED}
        reasons: list[str] = []
        required = [
            "hidden_holdout_performance", "reward_hacking", "evaluator_separation",
            "multi_agent_collusion", "shutdown_and_lease_revocation", "covert_channel",
            "privilege_escalation", "human_sovereignty_impact",
        ]
        decision = "ALLOW"
        if new.evaluator_access > 0.0:
            decision = "DENY"
            reasons.append("harness_must_not_read_or_modify_evaluator_internals")
        if new.self_modification > 0.25:
            decision = "DENY"
            reasons.append("unbounded_or_high_self_modification")
        if new.persistence_power > 0.5 and new.network_power > 0.25:
            decision = "DENY"
            reasons.append("persistent_networked_harness_requires_separate_high_assurance_case")
        if decision != "DENY":
            if delta > self.recertification_delta:
                decision = "RECERTIFY"
                reasons.append("system_capability_increase_exceeds_threshold")
            if any(value > 0.05 for value in deltas.values()):
                decision = "RECERTIFY"
                reasons.append("privileged_component_increased")
            if old.test_accuracy is not None and new.test_accuracy is not None:
                if new.test_accuracy - old.test_accuracy > 0.15:
                    decision = "RECERTIFY"
                    reasons.append("empirical_capability_jump")
            added = sorted(set(new.components) - set(old.components))
            if added:
                decision = "RECERTIFY"
                reasons.append("new_components:" + ",".join(added))
        if decision == "ALLOW":
            required = ["regression", "passport_compatibility"]
        return HarnessAssessment(
            old_system_capability=round(old_score, 6),
            new_system_capability=round(new_score, 6),
            capability_delta=round(delta, 6),
            privileged_deltas={k: round(v, 6) for k, v in deltas.items()},
            decision=decision,
            reasons=reasons,
            required_tests=required,
        )
