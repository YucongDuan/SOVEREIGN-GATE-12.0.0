from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any

from .canonical import clamp
from .models import AgentEvent, Intervention, RunawayMetrics


SIGNAL_SEVERITY: dict[str, int] = {
    "stop_precedence_violation": 5,
    "evaluator_integrity_attack": 5,
    "runaway_persistence_attempt": 5,
    "unauthorized_external_target": 5,
    "privilege_escalation_attempt": 5,
    "agent_self_authorization_attempt": 4,
    "unauthorized_evaluator_access": 4,
    "shared_credential_across_agents_or_runs": 4,
    "unregistered_cross_run_coordination": 4,
    "covert_metadata_channel": 4,
    "channel_semantic_repurposing": 4,
    "transcript_spoofing": 4,
    "synthetic_tripwire_triggered": 4,
    "unregistered_channel": 3,
}

AUTH_REASON_SEVERITY: dict[str, int] = {
    "run_killed": 5,
    "lease_epoch_invalid": 5,
    "lease_revoked": 4,
    "agent_revoked": 4,
    "invalid_lease_signature": 5,
    "invalid_passport_signature": 5,
    "evaluator_write_forbidden": 5,
    "evaluator_write_cannot_be_delegated": 5,
    "external_access_not_allowed": 5,
    "cross_run_coordination_not_allowed": 4,
    "harness_change_not_authorized": 4,
    "evaluator_read_not_authorized": 4,
    "channel_closed": 4,
    "agent_quarantined": 4,
    "run_paused": 4,
    "harness_frozen": 4,
    "evaluator_sealed": 4,
    "unknown_lease": 4,
    "passport_not_found": 4,
    "tool_not_allowed": 3,
    "target_not_allowed": 3,
    "channel_not_registered": 3,
    "channel_operation_not_allowed": 3,
    "lease_capability_missing": 3,
    "agent_not_allowed": 3,
    "run_not_allowed": 3,
    "delegation_depth_exceeded": 3,
}


@dataclass(slots=True)
class PolicyDecision:
    allow: bool
    severity: int
    reasons: list[str]
    interventions: list[Intervention]


class SovereigntyPolicy:
    """Fail-closed, lexicographic policy for machine-speed local containment.

    The policy never trades a hard sovereignty invariant for benchmark utility.
    It acts only on assets governed by the local control plane. Any external
    enforcement remains a human-authorized follow-up artifact, not an action.
    """

    def __init__(self, constitution: dict[str, Any]) -> None:
        self.constitution = constitution
        self.thresholds = constitution.get("thresholds", {})
        self.response = constitution.get("response", {})
        self.controlled_assets = set(constitution.get("controlled_assets", []))

    def _severity_from_barrier(self, value: float) -> int:
        if value < float(self.response.get("barrier_level_1", 0.0)):
            return 0
        if value < float(self.response.get("barrier_level_2", 0.15)):
            return 1
        if value < float(self.response.get("barrier_level_3", 0.35)):
            return 2
        if value < float(self.response.get("barrier_level_4", 0.60)):
            return 3
        if value < float(self.response.get("barrier_level_5", 0.85)):
            return 4
        return 5

    @staticmethod
    def _expires(ttl_seconds: int) -> str:
        moment = datetime.now(timezone.utc) + timedelta(seconds=max(1, ttl_seconds))
        return moment.replace(microsecond=0).isoformat().replace("+00:00", "Z")

    def decide(
        self,
        *,
        event: AgentEvent,
        authorization_reasons: list[str],
        hard_signals: list[str],
        metrics: RunawayMetrics,
        repeated_signal_counts: dict[str, int] | None = None,
    ) -> PolicyDecision:
        reasons = list(dict.fromkeys([*authorization_reasons, *hard_signals]))
        severity = self._severity_from_barrier(metrics.barrier_value)
        for signal in hard_signals:
            severity = max(severity, SIGNAL_SEVERITY.get(signal, 3))
        for reason in authorization_reasons:
            key = reason.split(":", 1)[0]
            severity = max(severity, AUTH_REASON_SEVERITY.get(key, 2))

        if metrics.human_sovereignty_risk > float(self.thresholds.get("human_sovereignty_risk", 0.1)):
            severity = 5
            reasons.append("human_sovereignty_floor_breached")
        if (
            metrics.coordination_reproduction_number
            > float(self.thresholds.get("coordination_reproduction_number", 1.0))
            and metrics.institution_formation_index
            > float(self.thresholds.get("institution_formation_index", 0.4))
        ):
            severity = max(severity, 4)
            reasons.append("unauthorized_collective_phase_transition")
        if metrics.evaluator_capture_index > float(self.thresholds.get("evaluator_capture_index", 0.18)):
            severity = max(severity, 4)
            reasons.append("evaluator_capture_threshold_exceeded")
        if metrics.purpose_curvature > float(self.thresholds.get("purpose_curvature", 0.34)):
            severity = max(severity, 2)
            reasons.append("purpose_curvature_threshold_exceeded")
        if metrics.authority_debt > float(self.thresholds.get("authority_debt", 0.22)):
            severity = max(severity, 3)
            reasons.append("authority_debt_threshold_exceeded")

        repeated = repeated_signal_counts or {}
        if any(repeated.get(signal, 0) >= 3 for signal in hard_signals):
            severity = max(severity, 5)
            reasons.append("repeated_hard_invariant_violation")

        reasons = list(dict.fromkeys(reasons))
        allow = severity == 0 and not authorization_reasons and not hard_signals
        interventions = self._interventions(
            event=event,
            severity=severity,
            reasons=reasons,
            hard_signals=hard_signals,
            metrics=metrics,
        )
        return PolicyDecision(allow=allow, severity=severity, reasons=reasons, interventions=interventions)

    def _interventions(
        self,
        *,
        event: AgentEvent,
        severity: int,
        reasons: list[str],
        hard_signals: list[str],
        metrics: RunawayMetrics,
    ) -> list[Intervention]:
        if severity <= 0:
            return []
        ttl = int(self.response.get("default_intervention_ttl_seconds", 900))
        expires = self._expires(ttl)
        why = ";".join(reasons[:10]) or "semantic_control_barrier"
        items: list[Intervention] = [
            Intervention("deny_current_action", f"event:{event.event_id}", why, severity),
            Intervention("preserve_forensic_snapshot", f"run:{event.run_id}", why, severity),
        ]
        if severity >= 1:
            items.append(Intervention(
                "require_fresh_lease_and_step_up_review", f"agent:{event.agent_id}", why, severity,
                reversible=True, expires_at=expires,
            ))
        if severity >= 2:
            channel_risk = {
                "covert_metadata_channel", "unregistered_channel",
                "channel_semantic_repurposing", "unregistered_cross_run_coordination",
                "shared_credential_across_agents_or_runs",
            }
            if event.channel_id and (channel_risk.intersection(hard_signals) or "channel_closed" in reasons):
                items.append(Intervention(
                    "close_channel", f"channel:{event.channel_id}", why, severity,
                    reversible=True, expires_at=expires,
                ))
            harness_id = str(event.metadata.get("harness_id", ""))
            if harness_id:
                items.append(Intervention(
                    "freeze_harness", f"harness:{harness_id}", why, severity,
                    reversible=True, expires_at=expires,
                ))
            items.append(Intervention(
                "reduce_run_concurrency_to_zero", f"run:{event.run_id}", why, severity,
                reversible=True, expires_at=expires,
            ))
        if severity >= 3:
            items.extend([
                Intervention("quarantine_agent", f"agent:{event.agent_id}", why, severity),
                Intervention("pause_run", f"run:{event.run_id}", why, severity),
                Intervention("revoke_lease", f"lease:{event.lease_id}", why, severity),
            ])
        if severity >= 4:
            items.extend([
                Intervention("kill_run", f"run:{event.run_id}", why, severity),
                Intervention("rotate_local_credentials", f"run:{event.run_id}", why, severity),
                Intervention(
                    "prepare_human_authorized_external_notification",
                    "external:manual-only", why, severity, reversible=True, automatic=False,
                ),
            ])
            evaluator_risk = {"evaluator_integrity_attack", "unauthorized_evaluator_access", "transcript_spoofing"}
            if evaluator_risk.intersection(hard_signals) or "evaluator_capture_threshold_exceeded" in reasons:
                items.append(Intervention("seal_evaluator", "asset:evaluator-vault", why, severity))
            harness_risk = {
                "evaluator_integrity_attack", "runaway_persistence_attempt",
                "agent_self_authorization_attempt", "stop_precedence_violation",
            }
            if harness_risk.intersection(hard_signals) or event.metadata.get("harness_id"):
                items.append(Intervention(
                    "freeze_unreviewed_harness_changes", "asset:agent-control-plane", why, severity
                ))
        catastrophic = {
            "stop_precedence_violation", "evaluator_integrity_attack",
            "runaway_persistence_attempt", "unauthorized_external_target",
        }
        collective = (
            "unauthorized_collective_phase_transition" in reasons
            or "shared_credential_across_agents_or_runs" in hard_signals
            or metrics.active_runs >= int(self.thresholds.get("global_kill_run_count", 3))
            and metrics.coordination_reproduction_number > 1.0
        )
        if severity >= 5 and (catastrophic.intersection(hard_signals) or collective):
            scope = "control-plane:all-leases" if collective else f"run:{event.run_id}"
            action = "global_lease_epoch_revoke" if collective else "kill_run"
            items.append(Intervention(action, scope, why, severity))
        # Stable ordering and de-duplication are required for auditable receipts.
        unique: dict[tuple[str, str], Intervention] = {}
        for item in items:
            unique[(item.action, item.scope)] = item
        return list(unique.values())
