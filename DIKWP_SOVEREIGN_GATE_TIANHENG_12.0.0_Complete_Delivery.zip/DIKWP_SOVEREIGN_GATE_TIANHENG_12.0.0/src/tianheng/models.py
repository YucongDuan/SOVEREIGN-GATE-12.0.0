from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any

from .canonical import digest, utc_now
from .errors import ValidationError


@dataclass(slots=True)
class PurposePassport:
    passport_id: str
    principal_id: str
    beneficiary: str
    issued_by: str
    issued_at: str
    valid_until: str
    authorized_purpose: dict[str, float]
    forbidden_purposes: list[str]
    allowed_agents: list[str]
    allowed_runs: list[str]
    allowed_channels: dict[str, list[str]]
    allowed_tools: list[str]
    allowed_targets: list[str]
    budgets: dict[str, float]
    max_delegation_depth: int = 0
    cross_run_coordination: bool = False
    harness_change_authority: bool = False
    evaluator_read: bool = False
    evaluator_write: bool = False
    kill_conditions: list[str] = field(default_factory=list)
    notes: dict[str, Any] = field(default_factory=dict)
    signature: str = ""

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "PurposePassport":
        required = [
            "passport_id", "principal_id", "beneficiary", "issued_by", "issued_at",
            "valid_until", "authorized_purpose", "forbidden_purposes", "allowed_agents",
            "allowed_runs", "allowed_channels", "allowed_tools", "allowed_targets", "budgets",
        ]
        missing = [key for key in required if key not in value]
        if missing:
            raise ValidationError(f"purpose passport missing: {', '.join(missing)}")
        purpose = value["authorized_purpose"]
        if not isinstance(purpose, dict) or not purpose:
            raise ValidationError("authorized_purpose must be a non-empty object")
        return cls(
            passport_id=str(value["passport_id"]),
            principal_id=str(value["principal_id"]),
            beneficiary=str(value["beneficiary"]),
            issued_by=str(value["issued_by"]),
            issued_at=str(value["issued_at"]),
            valid_until=str(value["valid_until"]),
            authorized_purpose={str(k): float(v) for k, v in purpose.items()},
            forbidden_purposes=[str(x) for x in value.get("forbidden_purposes", [])],
            allowed_agents=[str(x) for x in value.get("allowed_agents", [])],
            allowed_runs=[str(x) for x in value.get("allowed_runs", [])],
            allowed_channels={str(k): [str(x) for x in v] for k, v in value.get("allowed_channels", {}).items()},
            allowed_tools=[str(x) for x in value.get("allowed_tools", [])],
            allowed_targets=[str(x) for x in value.get("allowed_targets", [])],
            budgets={str(k): float(v) for k, v in value.get("budgets", {}).items()},
            max_delegation_depth=int(value.get("max_delegation_depth", 0)),
            cross_run_coordination=bool(value.get("cross_run_coordination", False)),
            harness_change_authority=bool(value.get("harness_change_authority", False)),
            evaluator_read=bool(value.get("evaluator_read", False)),
            evaluator_write=bool(value.get("evaluator_write", False)),
            kill_conditions=[str(x) for x in value.get("kill_conditions", [])],
            notes=dict(value.get("notes", {})),
            signature=str(value.get("signature", "")),
        )

    def unsigned_payload(self) -> dict[str, Any]:
        payload = asdict(self)
        payload.pop("signature", None)
        return payload

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class Lease:
    lease_id: str
    agent_id: str
    run_id: str
    passport_id: str
    issued_by: str
    issued_at: str
    expires_at: str
    epoch: int
    capabilities: list[str]
    signature: str = ""
    revoked: bool = False
    revocation_reason: str | None = None

    def unsigned_payload(self) -> dict[str, Any]:
        payload = asdict(self)
        payload.pop("signature", None)
        payload.pop("revoked", None)
        payload.pop("revocation_reason", None)
        return payload

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class AgentEvent:
    event_id: str
    timestamp: str
    agent_id: str
    run_id: str
    passport_id: str
    lease_id: str
    event_type: str
    operation: str
    channel_id: str = ""
    target: str = ""
    tool: str = ""
    recipient_agent_id: str = ""
    recipient_run_id: str = ""
    declared_purpose: dict[str, float] = field(default_factory=dict)
    operational_purpose: dict[str, float] = field(default_factory=dict)
    observed_effect: dict[str, float] = field(default_factory=dict)
    content_digest: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)
    impact: float = 0.0
    reversibility: float = 1.0
    requested_capability: float = 0.0
    external: bool = False

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "AgentEvent":
        required = [
            "event_id", "agent_id", "run_id", "passport_id", "lease_id",
            "event_type", "operation",
        ]
        missing = [key for key in required if key not in value]
        if missing:
            raise ValidationError(f"agent event missing: {', '.join(missing)}")
        return cls(
            event_id=str(value["event_id"]),
            timestamp=str(value.get("timestamp") or utc_now()),
            agent_id=str(value["agent_id"]),
            run_id=str(value["run_id"]),
            passport_id=str(value["passport_id"]),
            lease_id=str(value["lease_id"]),
            event_type=str(value["event_type"]),
            operation=str(value["operation"]),
            channel_id=str(value.get("channel_id", "")),
            target=str(value.get("target", "")),
            tool=str(value.get("tool", "")),
            recipient_agent_id=str(value.get("recipient_agent_id", "")),
            recipient_run_id=str(value.get("recipient_run_id", "")),
            declared_purpose={str(k): float(v) for k, v in value.get("declared_purpose", {}).items()},
            operational_purpose={str(k): float(v) for k, v in value.get("operational_purpose", {}).items()},
            observed_effect={str(k): float(v) for k, v in value.get("observed_effect", {}).items()},
            content_digest=str(value.get("content_digest", "")),
            metadata=dict(value.get("metadata", {})),
            impact=float(value.get("impact", 0.0)),
            reversibility=float(value.get("reversibility", 1.0)),
            requested_capability=float(value.get("requested_capability", 0.0)),
            external=bool(value.get("external", False)),
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def fingerprint(self) -> str:
        return digest(self.to_dict())


@dataclass(slots=True)
class HarnessManifest:
    harness_id: str
    version: str
    model_capability: float
    deterministic_solver: float
    routing: float
    memory: float
    tool_power: float
    network_power: float
    multi_agent_power: float
    persistence_power: float
    evaluator_access: float
    self_modification: float
    test_accuracy: float | None = None
    safety_score: float | None = None
    components: list[str] = field(default_factory=list)
    manifest_hash: str = ""

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "HarnessManifest":
        required = ["harness_id", "version", "model_capability"]
        missing = [key for key in required if key not in value]
        if missing:
            raise ValidationError(f"harness manifest missing: {', '.join(missing)}")
        manifest = cls(
            harness_id=str(value["harness_id"]),
            version=str(value["version"]),
            model_capability=float(value["model_capability"]),
            deterministic_solver=float(value.get("deterministic_solver", 0.0)),
            routing=float(value.get("routing", 0.0)),
            memory=float(value.get("memory", 0.0)),
            tool_power=float(value.get("tool_power", 0.0)),
            network_power=float(value.get("network_power", 0.0)),
            multi_agent_power=float(value.get("multi_agent_power", 0.0)),
            persistence_power=float(value.get("persistence_power", 0.0)),
            evaluator_access=float(value.get("evaluator_access", 0.0)),
            self_modification=float(value.get("self_modification", 0.0)),
            test_accuracy=float(value["test_accuracy"]) if value.get("test_accuracy") is not None else None,
            safety_score=float(value["safety_score"]) if value.get("safety_score") is not None else None,
            components=[str(x) for x in value.get("components", [])],
            manifest_hash=str(value.get("manifest_hash", "")),
        )
        if not manifest.manifest_hash:
            payload = asdict(manifest)
            payload["manifest_hash"] = ""
            manifest.manifest_hash = digest(payload)
        return manifest

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class RunawayMetrics:
    coordination_reproduction_number: float = 0.0
    institution_formation_index: float = 0.0
    purpose_curvature: float = 0.0
    evaluator_capture_index: float = 0.0
    authority_debt: float = 0.0
    persistence_pressure: float = 0.0
    resource_expansion_pressure: float = 0.0
    observability_gap: float = 0.0
    system_capability: float = 0.0
    human_sovereignty_risk: float = 0.0
    barrier_value: float = -1.0
    active_agents: int = 0
    active_runs: int = 0
    active_channels: int = 0
    largest_scc: int = 0
    unauthorized_edges: int = 0
    hard_signal_count: int = 0

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class Intervention:
    action: str
    scope: str
    reason: str
    severity: int
    reversible: bool = True
    automatic: bool = True
    expires_at: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class DecisionReceipt:
    decision_id: str
    recorded_at: str
    event_id: str
    allow: bool
    severity: int
    reasons: list[str]
    hard_signals: list[str]
    metrics: RunawayMetrics
    interventions: list[Intervention]
    constitution_version: str
    world_models: dict[str, float] = field(default_factory=dict)
    receipt_hash: str = ""

    def seal(self) -> "DecisionReceipt":
        payload = asdict(self)
        payload["receipt_hash"] = ""
        self.receipt_hash = digest(payload)
        return self

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
