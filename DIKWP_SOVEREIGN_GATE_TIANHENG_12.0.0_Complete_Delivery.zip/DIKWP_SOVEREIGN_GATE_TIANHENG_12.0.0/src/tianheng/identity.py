from __future__ import annotations

import secrets
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from .canonical import atomic_write_json, hmac_sign, hmac_verify, load_json, parse_time, utc_now
from .models import Lease


class IdentityRegistry:
    """First-class agent identities with externally renewed, revocable leases."""

    def __init__(self, path: Path, secret: bytes, governors: list[str]) -> None:
        self.path = path
        self.secret = secret
        self.governors = set(governors)
        if path.exists():
            raw = load_json(path)
        else:
            raw = {"epoch": 1, "leases": {}, "killed_runs": {}, "revoked_agents": {}}
        self.epoch = int(raw.get("epoch", 1))
        self.leases: dict[str, dict[str, Any]] = dict(raw.get("leases", {}))
        self.killed_runs: dict[str, str] = dict(raw.get("killed_runs", {}))
        self.revoked_agents: dict[str, str] = dict(raw.get("revoked_agents", {}))

    def _save(self) -> None:
        atomic_write_json(self.path, {
            "epoch": self.epoch,
            "leases": self.leases,
            "killed_runs": self.killed_runs,
            "revoked_agents": self.revoked_agents,
        })

    def issue(self, *, agent_id: str, run_id: str, passport_id: str, capabilities: list[str],
              actor: str, ttl_seconds: int = 300) -> Lease:
        if actor not in self.governors:
            raise PermissionError("agent identities and leases can only be issued by a governor")
        if run_id in self.killed_runs:
            raise PermissionError("run is killed and cannot receive new leases")
        now = datetime.now(timezone.utc).replace(microsecond=0)
        lease = Lease(
            lease_id="lease-" + secrets.token_hex(10),
            agent_id=agent_id,
            run_id=run_id,
            passport_id=passport_id,
            issued_by=actor,
            issued_at=now.isoformat().replace("+00:00", "Z"),
            expires_at=(now + timedelta(seconds=max(1, ttl_seconds))).isoformat().replace("+00:00", "Z"),
            epoch=self.epoch,
            capabilities=sorted(set(capabilities)),
        )
        lease.signature = hmac_sign(lease.unsigned_payload(), self.secret)
        self.leases[lease.lease_id] = lease.to_dict()
        self._save()
        return lease

    def get(self, lease_id: str) -> Lease | None:
        raw = self.leases.get(lease_id)
        if raw is None:
            return None
        return Lease(**raw)

    def validate(self, lease_id: str, *, agent_id: str, run_id: str, passport_id: str,
                 capability: str | None = None, now: datetime | None = None) -> list[str]:
        reasons: list[str] = []
        lease = self.get(lease_id)
        if lease is None:
            return ["unknown_lease"]
        if not hmac_verify(lease.unsigned_payload(), lease.signature, self.secret):
            reasons.append("invalid_lease_signature")
        if lease.revoked:
            reasons.append("lease_revoked")
        if lease.epoch != self.epoch:
            reasons.append("lease_epoch_invalid")
        if lease.agent_id != agent_id:
            reasons.append("lease_agent_mismatch")
        if lease.run_id != run_id:
            reasons.append("lease_run_mismatch")
        if lease.passport_id != passport_id:
            reasons.append("lease_passport_mismatch")
        moment = now or datetime.now(timezone.utc)
        try:
            if parse_time(lease.expires_at) <= moment:
                reasons.append("lease_expired")
        except ValueError:
            reasons.append("invalid_lease_time")
        if run_id in self.killed_runs:
            reasons.append("run_killed")
        if agent_id in self.revoked_agents:
            reasons.append("agent_revoked")
        if capability and "*" not in lease.capabilities and capability not in lease.capabilities:
            reasons.append("lease_capability_missing")
        return reasons

    def renew(self, lease_id: str, *, actor: str, ttl_seconds: int = 300) -> Lease:
        if actor not in self.governors:
            raise PermissionError("self-renewal is forbidden")
        old = self.get(lease_id)
        if old is None:
            raise KeyError(lease_id)
        if old.run_id in self.killed_runs or old.agent_id in self.revoked_agents:
            raise PermissionError("killed or revoked identity cannot be renewed")
        self.revoke(lease_id, reason="superseded_by_renewal")
        return self.issue(
            agent_id=old.agent_id,
            run_id=old.run_id,
            passport_id=old.passport_id,
            capabilities=old.capabilities,
            actor=actor,
            ttl_seconds=ttl_seconds,
        )

    def revoke(self, lease_id: str, *, reason: str) -> None:
        lease = self.get(lease_id)
        if lease is None:
            return
        lease.revoked = True
        lease.revocation_reason = reason
        self.leases[lease_id] = lease.to_dict()
        self._save()

    def revoke_agent(self, agent_id: str, *, reason: str) -> None:
        self.revoked_agents[agent_id] = reason
        for lease_id, raw in list(self.leases.items()):
            if raw.get("agent_id") == agent_id:
                self.revoke(lease_id, reason=reason)
        self._save()

    def kill_run(self, run_id: str, *, reason: str) -> None:
        self.killed_runs[run_id] = reason
        for lease_id, raw in list(self.leases.items()):
            if raw.get("run_id") == run_id:
                self.revoke(lease_id, reason=reason)
        self._save()

    def global_kill(self, *, reason: str) -> None:
        self.epoch += 1
        for run_id in {str(raw.get("run_id")) for raw in self.leases.values()}:
            self.killed_runs[run_id] = reason
        for lease_id, raw in list(self.leases.items()):
            raw["revoked"] = True
            raw["revocation_reason"] = reason
            self.leases[lease_id] = raw
        self._save()

    def summary(self) -> dict[str, Any]:
        active = 0
        for raw in self.leases.values():
            lease = Lease(**raw)
            if not self.validate(lease.lease_id, agent_id=lease.agent_id, run_id=lease.run_id,
                                 passport_id=lease.passport_id):
                active += 1
        return {
            "epoch": self.epoch,
            "lease_count": len(self.leases),
            "active_leases": active,
            "killed_runs": dict(self.killed_runs),
            "revoked_agents": dict(self.revoked_agents),
            "stop_lease_precedence": True,
            "self_renewal_authority": 0,
            "recorded_at": utc_now(),
        }
