from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any

from .dashboard import render_demo_dashboard
from .errors import TianhengError
from .runtime import TianhengRuntime
from .server import serve
from .simulator import run_demo


def _load(path: str) -> dict[str, Any]:
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError("input JSON must be an object")
    return value


def _print(value: Any) -> None:
    print(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="tianheng",
        description="DIKWP SOVEREIGN-GATE / TIANHENG 12.0.0",
    )
    parser.add_argument("--workspace", default="outputs/runtime")
    parser.add_argument("--constitution")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("init", help="initialize a local governance workspace")
    sub.add_parser("status", help="show governance and ledger status")
    sub.add_parser("verify-ledger", help="verify the append-only evidence chain")

    demo = sub.add_parser("demo", help="run six safe simulations")
    demo.add_argument("--reset", action="store_true")

    ingest = sub.add_parser("ingest", help="evaluate one event JSON")
    ingest.add_argument("event_json")

    passport = sub.add_parser("create-passport", help="sign and register a purpose passport")
    passport.add_argument("passport_json")
    passport.add_argument("--actor", default="human-governor")

    lease = sub.add_parser("issue-lease", help="issue an externally renewed agent lease")
    lease.add_argument("--agent", required=True)
    lease.add_argument("--run", required=True)
    lease.add_argument("--passport", required=True)
    lease.add_argument("--capability", action="append", default=[])
    lease.add_argument("--ttl", type=int, default=300)
    lease.add_argument("--actor", default="human-governor")

    harness = sub.add_parser("assess-harness", help="treat a harness change as a possible model upgrade")
    harness.add_argument("old_json")
    harness.add_argument("new_json")
    harness.add_argument("--actor", default="human-governor")

    outcome = sub.add_parser("record-outcome", help="record named reality contact for a prior decision")
    outcome.add_argument("outcome_json")
    outcome.add_argument("--actor", default="safety-officer")

    tripwire = sub.add_parser("issue-tripwire", help="issue an inert signed synthetic marker")
    tripwire.add_argument("--campaign", required=True)
    tripwire.add_argument("--asset", required=True)
    tripwire.add_argument("--purpose", required=True)
    tripwire.add_argument("--ttl", type=int, default=3600)
    tripwire.add_argument("--actor", default="safety-officer")

    kill = sub.add_parser("kill-run", help="human-governor run stop")
    kill.add_argument("run_id")
    kill.add_argument("--reason", default="human_stop")
    kill.add_argument("--actor", default="human-governor")

    global_kill = sub.add_parser("global-kill", help="invalidate the local lease epoch")
    global_kill.add_argument("--reason", default="human_global_stop")
    global_kill.add_argument("--actor", default="human-governor")

    server = sub.add_parser("serve", help="start loopback-only JSON governance API")
    server.add_argument("--host", default="127.0.0.1")
    server.add_argument("--port", type=int, default=8788)
    server.add_argument("--api-key")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        if args.command == "demo":
            workspace = Path(args.workspace).expanduser().resolve()
            if args.reset:
                TianhengRuntime.reset_workspace(workspace)
            summary = run_demo(workspace)
            dashboard = render_demo_dashboard(summary, workspace / "dashboard.html")
            result = {
                "summary": summary,
                "summary_path": str(workspace / "demo_summary.json"),
                "dashboard_path": str(dashboard),
            }
            _print(result)
            return 0

        runtime = TianhengRuntime(args.workspace, args.constitution)
        if args.command == "init":
            _print(runtime.status())
        elif args.command == "status":
            _print(runtime.status())
        elif args.command == "verify-ledger":
            _print(runtime.ledger.verify())
        elif args.command == "ingest":
            _print(runtime.ingest(_load(args.event_json)))
        elif args.command == "create-passport":
            _print(runtime.create_passport(_load(args.passport_json), actor=args.actor).to_dict())
        elif args.command == "issue-lease":
            _print(runtime.issue_lease(
                agent_id=args.agent, run_id=args.run, passport_id=args.passport,
                capabilities=args.capability, ttl_seconds=args.ttl, actor=args.actor,
            ))
        elif args.command == "assess-harness":
            _print(runtime.assess_harness(_load(args.old_json), _load(args.new_json), actor=args.actor))
        elif args.command == "record-outcome":
            _print(runtime.record_reality_outcome(_load(args.outcome_json), actor=args.actor))
        elif args.command == "issue-tripwire":
            _print(runtime.issue_tripwire(
                campaign_id=args.campaign, asset_id=args.asset, purpose=args.purpose,
                ttl_seconds=args.ttl, actor=args.actor,
            ))
        elif args.command == "kill-run":
            _print(runtime.kill_run(args.run_id, actor=args.actor, reason=args.reason))
        elif args.command == "global-kill":
            _print(runtime.global_kill(actor=args.actor, reason=args.reason))
        elif args.command == "serve":
            serve(runtime, host=args.host, port=args.port, api_key=args.api_key)
        else:
            parser.error("unknown command")
        return 0
    except (TianhengError, PermissionError, ValueError, KeyError) as exc:
        print(f"error: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
