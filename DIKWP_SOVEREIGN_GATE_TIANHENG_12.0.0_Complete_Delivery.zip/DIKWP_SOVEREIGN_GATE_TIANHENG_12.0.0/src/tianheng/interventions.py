from __future__ import annotations

from typing import Any

from .identity import IdentityRegistry
from .models import AgentEvent, Intervention
from .state import GovernanceState


class InterventionExecutor:
    """Executes only local, registered, reversible containment primitives."""

    def __init__(self, constitution: dict[str, Any], state: GovernanceState,
                 identities: IdentityRegistry) -> None:
        self.constitution = constitution
        self.state = state
        self.identities = identities
        self.controlled_assets = set(constitution.get("controlled_assets", []))
        self.external_authority = int(constitution.get("external_automatic_action_authority", 0))

    @staticmethod
    def _value(scope: str) -> str:
        return scope.split(":", 1)[1] if ":" in scope else scope

    def apply(self, event: AgentEvent, interventions: list[Intervention]) -> list[dict[str, Any]]:
        outcomes: list[dict[str, Any]] = []
        for intervention in interventions:
            action = intervention.action
            scope_value = self._value(intervention.scope)
            applied = False
            note = "recorded_only"
            if not intervention.automatic:
                note = "manual_authorization_required"
            elif intervention.scope.startswith("external:"):
                if self.external_authority != 0:
                    note = "constitution_invalid_external_authority"
                else:
                    note = "external_automatic_action_forbidden"
            elif action == "close_channel":
                self.state.closed_channels[scope_value] = intervention.reason
                applied, note = True, "channel_closed_locally"
            elif action == "freeze_harness":
                self.state.frozen_harnesses[scope_value] = intervention.reason
                applied, note = True, "harness_frozen"
            elif action == "reduce_run_concurrency_to_zero":
                self.state.concurrency_caps[scope_value] = 0
                applied, note = True, "run_concurrency_zeroed"
            elif action == "quarantine_agent":
                self.state.quarantined_agents[scope_value] = intervention.reason
                self.identities.revoke_agent(scope_value, reason=intervention.reason)
                applied, note = True, "agent_quarantined_and_leases_revoked"
            elif action == "pause_run":
                self.state.paused_runs[scope_value] = intervention.reason
                applied, note = True, "run_paused"
            elif action == "revoke_lease":
                self.identities.revoke(scope_value, reason=intervention.reason)
                applied, note = True, "lease_revoked"
            elif action == "kill_run":
                self.identities.kill_run(scope_value, reason=intervention.reason)
                self.state.paused_runs[scope_value] = intervention.reason
                self.state.concurrency_caps[scope_value] = 0
                applied, note = True, "run_killed"
            elif action == "global_lease_epoch_revoke":
                self.identities.global_kill(reason=intervention.reason)
                for run_id in self.state.runs_seen:
                    self.state.paused_runs[run_id] = intervention.reason
                    self.state.concurrency_caps[run_id] = 0
                applied, note = True, "all_local_leases_invalidated_by_epoch"
            elif action == "seal_evaluator":
                self.state.sealed_evaluators[scope_value] = intervention.reason
                applied, note = True, "evaluator_interface_sealed"
            elif action == "freeze_unreviewed_harness_changes":
                self.state.global_harness_freeze = intervention.reason
                applied, note = True, "unreviewed_harness_changes_frozen"
            elif action == "rotate_local_credentials":
                self.state.credential_rotations.append({
                    "run_id": scope_value, "reason": intervention.reason,
                })
                applied, note = True, "rotation_requested_for_local_secret_manager"
            elif action == "preserve_forensic_snapshot":
                self.state.forensic_snapshots.append({
                    "event_id": event.event_id,
                    "run_id": event.run_id,
                    "agent_id": event.agent_id,
                    "reason": intervention.reason,
                })
                applied, note = True, "minimal_snapshot_recorded"
            elif action in {"deny_current_action", "require_fresh_lease_and_step_up_review"}:
                applied, note = True, "gate_enforced"
            outcomes.append({
                "action": action,
                "scope": intervention.scope,
                "applied": applied,
                "note": note,
                "automatic": intervention.automatic,
            })
        self.state.note_interventions(interventions)
        self.state.save()
        return outcomes
