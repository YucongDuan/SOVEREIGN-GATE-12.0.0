from __future__ import annotations

import math
from typing import Iterable

from .canonical import clamp
from .models import AgentEvent


def _normalize(distribution: dict[str, float]) -> dict[str, float]:
    positive = {str(k): max(0.0, float(v)) for k, v in distribution.items()}
    total = sum(positive.values())
    if total <= 0:
        return {}
    return {k: v / total for k, v in positive.items()}


def _kl(p: dict[str, float], q: dict[str, float]) -> float:
    value = 0.0
    for key, probability in p.items():
        if probability <= 0:
            continue
        denominator = max(q.get(key, 0.0), 1e-12)
        value += probability * math.log(probability / denominator, 2)
    return value


def jensen_shannon(a: dict[str, float], b: dict[str, float]) -> float:
    pa, pb = _normalize(a), _normalize(b)
    if not pa and not pb:
        return 0.0
    keys = set(pa) | set(pb)
    pa = {key: pa.get(key, 0.0) for key in keys}
    pb = {key: pb.get(key, 0.0) for key in keys}
    midpoint = {key: (pa[key] + pb[key]) / 2.0 for key in keys}
    return clamp(0.5 * _kl(pa, midpoint) + 0.5 * _kl(pb, midpoint))


def purpose_curvature(mandate: dict[str, float], plan: dict[str, float],
                      action: dict[str, float], effect: dict[str, float]) -> float:
    """Discrete DIKWP purpose curvature across mandate→plan→action→effect."""
    distributions = [mandate, plan, action, effect]
    nonempty = [item for item in distributions if item]
    if len(nonempty) < 2:
        return 0.0
    distances = [jensen_shannon(left, right) for left, right in zip(nonempty, nonempty[1:])]
    direct = jensen_shannon(nonempty[0], nonempty[-1])
    detour = max(0.0, sum(distances) - direct)
    return clamp(0.75 * (sum(distances) / len(distances)) + 0.25 * detour)


def event_purpose_curvature(event: AgentEvent, mandate: dict[str, float]) -> float:
    return purpose_curvature(
        mandate,
        event.declared_purpose or mandate,
        event.operational_purpose or event.declared_purpose or mandate,
        event.observed_effect or event.operational_purpose or event.declared_purpose or mandate,
    )


def authority_debt(events: Iterable[AgentEvent], authorized_capability: float) -> float:
    debt = 0.0
    scale = 0.0
    for event in events:
        excess = max(0.0, clamp(event.requested_capability) - clamp(authorized_capability))
        debt += max(0.0, event.impact) * excess
        scale += max(0.0, event.impact)
    if scale <= 0:
        return 0.0
    return clamp(debt / scale)


def irreversibility_debt(events: Iterable[AgentEvent]) -> float:
    numerator = 0.0
    denominator = 0.0
    for event in events:
        impact = max(0.0, event.impact)
        numerator += impact * (1.0 - clamp(event.reversibility))
        denominator += impact
    return clamp(numerator / denominator) if denominator else 0.0


def human_sovereignty_risk(event: AgentEvent) -> float:
    effect = _normalize(event.observed_effect)
    harmful = (
        effect.get("physical_harm", 0.0)
        + effect.get("rights_loss", 0.0)
        + effect.get("human_agency_loss", 0.0)
        + effect.get("truth_corruption", 0.0)
        + effect.get("future_option_loss", 0.0)
    )
    coercion = float(event.metadata.get("coercion_risk", 0.0))
    blast = float(event.metadata.get("blast_radius", 0.0))
    return clamp(0.65 * harmful + 0.2 * clamp(coercion) + 0.15 * clamp(blast))


def semantic_closure_defect(event: AgentEvent, mandate: dict[str, float]) -> float:
    missing = 0.0
    if not event.content_digest and event.event_type in {"message", "artifact_write", "tool_call"}:
        missing += 0.15
    if not event.observed_effect:
        missing += 0.10
    if not event.declared_purpose:
        missing += 0.10
    return clamp(event_purpose_curvature(event, mandate) + missing)
