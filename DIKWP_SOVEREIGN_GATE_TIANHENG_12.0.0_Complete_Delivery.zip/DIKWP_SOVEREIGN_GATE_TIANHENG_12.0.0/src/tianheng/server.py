from __future__ import annotations

import json
import os
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Callable
from urllib.parse import urlparse

from .dashboard import render_demo_dashboard
from .errors import EventCollisionError, TianhengError
from .runtime import TianhengRuntime


MAX_BODY_BYTES = 1_048_576


class GovernanceHTTPServer(ThreadingHTTPServer):
    runtime: TianhengRuntime
    api_key: str


class GovernanceHandler(BaseHTTPRequestHandler):
    server: GovernanceHTTPServer

    def log_message(self, format: str, *args: Any) -> None:  # noqa: A002
        # Avoid dumping request bodies or credentials into default access logs.
        return

    def _json(self, status: int, payload: dict[str, Any]) -> None:
        body = json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def _authorized(self) -> bool:
        return self.headers.get("X-Tianheng-Key", "") == self.server.api_key

    def _require_auth(self) -> bool:
        if self._authorized():
            return True
        self._json(HTTPStatus.UNAUTHORIZED, {"error": "authentication_required"})
        return False

    def _body(self) -> dict[str, Any]:
        if self.headers.get_content_type() != "application/json":
            raise ValueError("content_type_must_be_application_json")
        length = int(self.headers.get("Content-Length", "0"))
        if length < 0 or length > MAX_BODY_BYTES:
            raise ValueError("request_body_too_large")
        raw = self.rfile.read(length)
        value = json.loads(raw.decode("utf-8") or "{}")
        if not isinstance(value, dict):
            raise ValueError("json_body_must_be_object")
        return value

    def do_GET(self) -> None:  # noqa: N802
        path = urlparse(self.path).path
        if path == "/health":
            self._json(HTTPStatus.OK, {
                "status": "ok", "system": "TIANHENG", "version": "12.0.0",
                "external_automatic_action_authority": 0,
            })
            return
        if not self._require_auth():
            return
        if path == "/status":
            self._json(HTTPStatus.OK, self.server.runtime.status())
        elif path == "/ledger/verify":
            self._json(HTTPStatus.OK, self.server.runtime.ledger.verify())
        elif path == "/constitution":
            self._json(HTTPStatus.OK, self.server.runtime.constitution)
        elif path == "/reality-report":
            self._json(HTTPStatus.OK, self.server.runtime.reality_report())
        else:
            self._json(HTTPStatus.NOT_FOUND, {"error": "not_found"})

    def do_POST(self) -> None:  # noqa: N802
        if not self._require_auth():
            return
        path = urlparse(self.path).path
        try:
            payload = self._body()
            if path == "/events":
                result = self.server.runtime.ingest(payload)
                self._json(HTTPStatus.OK, result)
            elif path == "/passports":
                actor = str(payload.pop("_actor", "human-governor"))
                passport = self.server.runtime.create_passport(payload, actor=actor)
                self._json(HTTPStatus.CREATED, passport.to_dict())
            elif path == "/leases":
                result = self.server.runtime.issue_lease(
                    agent_id=str(payload["agent_id"]), run_id=str(payload["run_id"]),
                    passport_id=str(payload["passport_id"]),
                    capabilities=[str(x) for x in payload.get("capabilities", [])],
                    actor=str(payload.get("actor", "human-governor")),
                    ttl_seconds=int(payload.get("ttl_seconds", 300)),
                )
                self._json(HTTPStatus.CREATED, result)
            elif path == "/harness/assess":
                result = self.server.runtime.assess_harness(
                    dict(payload["old"]), dict(payload["new"]),
                    actor=str(payload.get("actor", "human-governor")),
                )
                self._json(HTTPStatus.OK, result)
            elif path == "/tripwires":
                result = self.server.runtime.issue_tripwire(
                    campaign_id=str(payload["campaign_id"]), asset_id=str(payload["asset_id"]),
                    purpose=str(payload["purpose"]),
                    ttl_seconds=int(payload.get("ttl_seconds", 3600)),
                    actor=str(payload.get("actor", "safety-officer")),
                )
                self._json(HTTPStatus.CREATED, result)
            elif path == "/reality-outcomes":
                actor = str(payload.pop("_actor", "safety-officer"))
                result = self.server.runtime.record_reality_outcome(payload, actor=actor)
                self._json(HTTPStatus.CREATED, result)
            elif path == "/runs/kill":
                result = self.server.runtime.kill_run(
                    str(payload["run_id"]), actor=str(payload.get("actor", "human-governor")),
                    reason=str(payload.get("reason", "human_stop")),
                )
                self._json(HTTPStatus.OK, result)
            elif path == "/global-kill":
                result = self.server.runtime.global_kill(
                    actor=str(payload.get("actor", "human-governor")),
                    reason=str(payload.get("reason", "human_global_stop")),
                )
                self._json(HTTPStatus.OK, result)
            else:
                self._json(HTTPStatus.NOT_FOUND, {"error": "not_found"})
        except EventCollisionError as exc:
            self._json(HTTPStatus.CONFLICT, {"error": type(exc).__name__, "message": str(exc)})
        except (KeyError, ValueError, TypeError, TianhengError, PermissionError) as exc:
            self._json(HTTPStatus.BAD_REQUEST, {"error": type(exc).__name__, "message": str(exc)})
        except json.JSONDecodeError:
            self._json(HTTPStatus.BAD_REQUEST, {"error": "invalid_json"})


def serve(runtime: TianhengRuntime, *, host: str = "127.0.0.1", port: int = 8788,
          api_key: str | None = None) -> None:
    if host not in {"127.0.0.1", "localhost", "::1"}:
        raise ValueError("reference server is intentionally loopback-only")
    server = GovernanceHTTPServer((host, port), GovernanceHandler)
    server.runtime = runtime
    server.api_key = api_key or os.getenv("TIANHENG_API_KEY", "tianheng-local-demo-key-change-me")
    try:
        server.serve_forever()
    finally:
        server.server_close()
