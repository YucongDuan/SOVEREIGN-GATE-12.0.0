from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from typing import Any

from .canonical import clamp


@dataclass(slots=True)
class Edge:
    source: str
    target: str
    weight: float
    authorized: bool
    tactic_adoption: float
    channel_id: str


class CoordinationGraph:
    """Cumulative cross-agent influence graph with auditable edge semantics."""

    def __init__(self) -> None:
        self.nodes: set[str] = set()
        self.edges: dict[tuple[str, str, str], Edge] = {}
        self.roles: dict[str, str] = {}
        self.delegation_depth_max = 0
        self.persistent_artifacts = 0
        self.resource_pool_events = 0
        self.shared_objective_events = 0
        self.cross_run_edges = 0

    def add_node(self, node: str) -> None:
        if node:
            self.nodes.add(node)

    def add_edge(self, source: str, target: str, *, weight: float = 1.0, authorized: bool = False,
                 tactic_adoption: float = 0.0, channel_id: str = "") -> None:
        if not source or not target or source == target:
            return
        self.nodes.update({source, target})
        key = (source, target, channel_id)
        prior = self.edges.get(key)
        if prior:
            prior.weight += max(0.0, weight)
            prior.tactic_adoption = max(prior.tactic_adoption, clamp(tactic_adoption))
            prior.authorized = prior.authorized and authorized
        else:
            self.edges[key] = Edge(source, target, max(0.0, weight), bool(authorized),
                                   clamp(tactic_adoption), channel_id)

    def set_role(self, agent_id: str, role: str) -> None:
        if agent_id and role:
            self.nodes.add(agent_id)
            self.roles[agent_id] = role

    def note_delegation(self, depth: int) -> None:
        self.delegation_depth_max = max(self.delegation_depth_max, max(0, int(depth)))

    def adjacency(self, *, unauthorized_only: bool = False, adoption_only: bool = False) -> dict[str, dict[str, float]]:
        result: dict[str, dict[str, float]] = {node: {} for node in self.nodes}
        for edge in self.edges.values():
            if unauthorized_only and edge.authorized:
                continue
            weight = edge.tactic_adoption if adoption_only else edge.weight
            if weight <= 0:
                continue
            result[edge.source][edge.target] = result[edge.source].get(edge.target, 0.0) + weight
        return result

    def spectral_radius(self, *, unauthorized_only: bool = True, adoption_only: bool = True,
                        iterations: int = 30) -> float:
        nodes = sorted(self.nodes)
        if not nodes:
            return 0.0
        index = {node: i for i, node in enumerate(nodes)}
        vector = [1.0 / len(nodes)] * len(nodes)
        edges: list[tuple[int, int, float]] = []
        for edge in self.edges.values():
            if unauthorized_only and edge.authorized:
                continue
            weight = edge.tactic_adoption if adoption_only else edge.weight
            if weight > 0:
                edges.append((index[edge.source], index[edge.target], weight))
        if not edges:
            return 0.0
        estimate = 0.0
        for _ in range(iterations):
            nxt = [0.0] * len(nodes)
            for source, target, weight in edges:
                nxt[target] += vector[source] * weight
            norm = max(sum(abs(x) for x in nxt), 1e-12)
            estimate = norm / max(sum(abs(x) for x in vector), 1e-12)
            vector = [x / norm for x in nxt]
        return max(0.0, estimate)

    def strongly_connected_components(self, *, unauthorized_only: bool = False) -> list[list[str]]:
        adjacency = self.adjacency(unauthorized_only=unauthorized_only, adoption_only=False)
        index_counter = [0]
        stack: list[str] = []
        on_stack: set[str] = set()
        index: dict[str, int] = {}
        lowlink: dict[str, int] = {}
        components: list[list[str]] = []

        def visit(node: str) -> None:
            index[node] = index_counter[0]
            lowlink[node] = index_counter[0]
            index_counter[0] += 1
            stack.append(node)
            on_stack.add(node)
            for neighbor in adjacency.get(node, {}):
                if neighbor not in index:
                    visit(neighbor)
                    lowlink[node] = min(lowlink[node], lowlink[neighbor])
                elif neighbor in on_stack:
                    lowlink[node] = min(lowlink[node], index[neighbor])
            if lowlink[node] == index[node]:
                component: list[str] = []
                while stack:
                    member = stack.pop()
                    on_stack.remove(member)
                    component.append(member)
                    if member == node:
                        break
                components.append(component)

        for node in adjacency:
            if node not in index:
                visit(node)
        return components

    def largest_scc(self, *, unauthorized_only: bool = False) -> int:
        components = self.strongly_connected_components(unauthorized_only=unauthorized_only)
        return max((len(component) for component in components), default=0)

    def institution_formation_index(self) -> float:
        n = max(1, len(self.nodes))
        scc_ratio = self.largest_scc(unauthorized_only=True) / n
        unique_roles = len(set(self.roles.values()))
        role_specialization = min(1.0, unique_roles / 5.0) * min(1.0, len(self.roles) / max(1.0, n * 0.2))
        delegation = min(1.0, self.delegation_depth_max / 4.0)
        persistence = min(1.0, self.persistent_artifacts / max(1.0, n * 0.1))
        pooling = min(1.0, self.resource_pool_events / max(1.0, n * 0.05))
        shared_objective = min(1.0, self.shared_objective_events / max(1.0, n * 0.1))
        return clamp(
            0.28 * scc_ratio + 0.18 * role_specialization + 0.16 * delegation
            + 0.14 * persistence + 0.12 * pooling + 0.12 * shared_objective
        )

    def unauthorized_edge_count(self) -> int:
        return sum(1 for edge in self.edges.values() if not edge.authorized)

    def snapshot(self) -> dict[str, Any]:
        return {
            "nodes": len(self.nodes),
            "edges": len(self.edges),
            "unauthorized_edges": self.unauthorized_edge_count(),
            "largest_scc": self.largest_scc(),
            "largest_unauthorized_scc": self.largest_scc(unauthorized_only=True),
            "coordination_reproduction_number": round(self.spectral_radius(), 6),
            "institution_formation_index": round(self.institution_formation_index(), 6),
            "roles": dict(self.roles),
            "delegation_depth_max": self.delegation_depth_max,
            "persistent_artifacts": self.persistent_artifacts,
            "resource_pool_events": self.resource_pool_events,
            "shared_objective_events": self.shared_objective_events,
            "cross_run_edges": self.cross_run_edges,
        }
