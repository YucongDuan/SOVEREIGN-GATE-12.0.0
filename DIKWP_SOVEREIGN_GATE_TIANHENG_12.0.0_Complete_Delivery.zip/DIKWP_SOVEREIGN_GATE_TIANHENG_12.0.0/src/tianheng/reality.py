from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

from .canonical import clamp, utc_now


@dataclass(slots=True)
class RealityOutcome:
    outcome_id: str
    decision_id: str
    event_id: str
    actor: str
    recorded_at: str
    actual_class: str
    automatic_decision_correct: bool
    human_override: bool
    false_positive: bool
    false_negative: bool
    service_impact: float
    human_sovereignty_impact: float
    recovery_seconds: float
    evidence_quality: float
    notes: str = ""

    @classmethod
    def from_dict(cls, value: dict[str, Any], *, actor: str) -> "RealityOutcome":
        required = ["outcome_id", "decision_id", "event_id", "actual_class"]
        missing = [key for key in required if key not in value]
        if missing:
            raise ValueError("reality outcome missing: " + ", ".join(missing))
        return cls(
            outcome_id=str(value["outcome_id"]),
            decision_id=str(value["decision_id"]),
            event_id=str(value["event_id"]),
            actor=actor,
            recorded_at=str(value.get("recorded_at") or utc_now()),
            actual_class=str(value["actual_class"]),
            automatic_decision_correct=bool(value.get("automatic_decision_correct", False)),
            human_override=bool(value.get("human_override", False)),
            false_positive=bool(value.get("false_positive", False)),
            false_negative=bool(value.get("false_negative", False)),
            service_impact=clamp(float(value.get("service_impact", 0.0))),
            human_sovereignty_impact=clamp(float(value.get("human_sovereignty_impact", 0.0))),
            recovery_seconds=max(0.0, float(value.get("recovery_seconds", 0.0))),
            evidence_quality=clamp(float(value.get("evidence_quality", 0.0))),
            notes=str(value.get("notes", "")),
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class RealityContactEngine:
    """Turns observed outcomes into revision or retirement recommendations."""

    def report(self, outcomes: list[dict[str, Any]]) -> dict[str, Any]:
        count = len(outcomes)
        if count == 0:
            return {
                "outcome_count": 0,
                "status": "INSUFFICIENT_REALITY_CONTACT",
                "recommendations": ["collect_named_post-decision_outcomes"],
            }
        false_positive_rate = sum(bool(x.get("false_positive")) for x in outcomes) / count
        false_negative_rate = sum(bool(x.get("false_negative")) for x in outcomes) / count
        override_rate = sum(bool(x.get("human_override")) for x in outcomes) / count
        decision_accuracy = sum(bool(x.get("automatic_decision_correct")) for x in outcomes) / count
        service_impact = sum(float(x.get("service_impact", 0.0)) for x in outcomes) / count
        sovereignty_impact = sum(float(x.get("human_sovereignty_impact", 0.0)) for x in outcomes) / count
        evidence_quality = sum(float(x.get("evidence_quality", 0.0)) for x in outcomes) / count
        recommendations: list[str] = []
        status = "MONITOR"
        if false_positive_rate > 0.15:
            recommendations.append("raise_or_segment_overbroad_thresholds")
        if false_negative_rate > 0.05:
            recommendations.append("lower_relevant_thresholds_and_add_detector_diversity")
        if override_rate > 0.25:
            recommendations.append("review_policy_semantics_and_operator_disagreement")
        if service_impact > 0.10:
            recommendations.append("reduce_containment_blast_radius")
        if sovereignty_impact > 0.0:
            recommendations.append("immediate_human_sovereignty_review")
        if evidence_quality < 0.70:
            recommendations.append("do_not_expand_automatic_authority_without_better_evidence")
        if count >= 20 and (decision_accuracy < 0.70 or sovereignty_impact > 0.02):
            status = "MODEL_RETIREMENT_REVIEW"
            recommendations.append("retire_or_replace_contradicted_detector_or_threshold_set")
        elif recommendations:
            status = "REVISION_REQUIRED"
        return {
            "outcome_count": count,
            "decision_accuracy": round(decision_accuracy, 6),
            "false_positive_rate": round(false_positive_rate, 6),
            "false_negative_rate": round(false_negative_rate, 6),
            "human_override_rate": round(override_rate, 6),
            "mean_service_impact": round(service_impact, 6),
            "mean_human_sovereignty_impact": round(sovereignty_impact, 6),
            "mean_evidence_quality": round(evidence_quality, 6),
            "status": status,
            "recommendations": list(dict.fromkeys(recommendations)),
        }
