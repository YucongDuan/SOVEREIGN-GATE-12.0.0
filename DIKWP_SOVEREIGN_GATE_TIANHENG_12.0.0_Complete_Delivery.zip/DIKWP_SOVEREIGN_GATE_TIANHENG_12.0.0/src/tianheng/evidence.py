from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Iterable

from .canonical import canonical_json, digest, hmac_sign, hmac_verify, redact, utc_now
from .errors import EvidenceIntegrityError


class EvidenceLedger:
    """Append-only, hash-chained, locally signed JSONL evidence ledger.

    HMAC is a portable reference mechanism, not a substitute for HSM-backed keys,
    trusted timestamping, immutable storage, or formal forensic custody.
    """

    def __init__(self, path: Path, secret: bytes | None = None) -> None:
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.secret = secret or os.getenv(
            "TIANHENG_LEDGER_KEY", "tianheng-demo-ledger-key-change-me"
        ).encode("utf-8")

    def _entries(self) -> list[dict[str, Any]]:
        if not self.path.exists():
            return []
        entries: list[dict[str, Any]] = []
        for line_number, line in enumerate(self.path.read_text(encoding="utf-8").splitlines(), 1):
            if not line.strip():
                continue
            try:
                value = json.loads(line)
            except json.JSONDecodeError as exc:
                raise EvidenceIntegrityError(f"invalid JSON at ledger line {line_number}") from exc
            if not isinstance(value, dict):
                raise EvidenceIntegrityError(f"ledger line {line_number} is not an object")
            entries.append(value)
        return entries

    def append(self, kind: str, payload: dict[str, Any], *, case_id: str | None = None,
               actor: str = "tianheng") -> dict[str, Any]:
        entries = self._entries()
        previous_hash = entries[-1]["entry_hash"] if entries else "GENESIS"
        body = {
            "sequence": len(entries) + 1,
            "recorded_at": utc_now(),
            "kind": kind,
            "case_id": case_id,
            "actor": actor,
            "payload": redact(payload),
            "previous_hash": previous_hash,
        }
        entry_hash = digest(body)
        entry = {
            **body,
            "entry_hash": entry_hash,
            "signature_algorithm": "HMAC-SHA256-DEMO",
            "signature": hmac_sign({"entry_hash": entry_hash}, self.secret),
        }
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(canonical_json(entry) + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        try:
            self.path.chmod(0o600)
        except OSError:
            pass
        return entry

    def verify(self) -> dict[str, Any]:
        entries = self._entries()
        expected_previous = "GENESIS"
        errors: list[str] = []
        for index, entry in enumerate(entries, 1):
            body = {
                "sequence": entry.get("sequence"),
                "recorded_at": entry.get("recorded_at"),
                "kind": entry.get("kind"),
                "case_id": entry.get("case_id"),
                "actor": entry.get("actor"),
                "payload": entry.get("payload"),
                "previous_hash": entry.get("previous_hash"),
            }
            if entry.get("sequence") != index:
                errors.append(f"entry {index}: sequence mismatch")
            if entry.get("previous_hash") != expected_previous:
                errors.append(f"entry {index}: previous hash mismatch")
            computed = digest(body)
            if entry.get("entry_hash") != computed:
                errors.append(f"entry {index}: content hash mismatch")
            if not hmac_verify({"entry_hash": entry.get("entry_hash")},
                               str(entry.get("signature", "")), self.secret):
                errors.append(f"entry {index}: signature mismatch")
            expected_previous = str(entry.get("entry_hash", ""))
        return {
            "valid": not errors,
            "entry_count": len(entries),
            "head_hash": expected_previous,
            "errors": errors,
        }

    def iter_case(self, case_id: str) -> Iterable[dict[str, Any]]:
        for entry in self._entries():
            if entry.get("case_id") == case_id:
                yield entry
