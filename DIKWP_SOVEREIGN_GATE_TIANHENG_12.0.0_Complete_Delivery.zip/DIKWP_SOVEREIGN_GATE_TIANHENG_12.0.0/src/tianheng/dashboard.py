from __future__ import annotations

import html
import json
from pathlib import Path
from typing import Any

from .canonical import utc_now


def _cell(value: Any) -> str:
    if isinstance(value, (dict, list)):
        value = json.dumps(value, ensure_ascii=False, sort_keys=True)
    return html.escape(str(value))


def render_demo_dashboard(summary: dict[str, Any], output: str | Path) -> Path:
    path = Path(output)
    path.parent.mkdir(parents=True, exist_ok=True)
    rows = []
    for scenario in summary.get("scenarios", []):
        name = scenario.get("scenario", "")
        if "underground" in name:
            outcome = f"first covert executed={scenario.get('first_covert_action_executed')}; severity={scenario.get('first_covert_severity')}"
            evidence = scenario.get("first_covert_hard_signals", [])
        elif "harness" in name:
            outcome = scenario.get("assessment", {}).get("assessment", {}).get("decision", "")
            evidence = scenario.get("assessment", {}).get("assessment", {}).get("reasons", [])
        elif "reward" in name:
            outcome = f"executed={scenario.get('action_executed')}"
            evidence = scenario.get("receipt", {}).get("hard_signals", [])
        elif "stop" in name:
            outcome = f"self-renew executed={scenario.get('self_renew_allowed')}"
            evidence = scenario.get("receipt", {}).get("reasons", [])
        else:
            outcome = f"all allowed={scenario.get('all_allowed')}"
            evidence = scenario.get("status", {}).get("state", {}).get("signal_counts", {})
        rows.append(
            f"<tr><td>{_cell(name)}</td><td>{_cell(outcome)}</td><td>{_cell(evidence)}</td></tr>"
        )
    document = f"""<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>TIANHENG 12.0.0 Governance Dashboard</title>
<style>
:root{{--bg:#0b1020;--panel:#151d33;--text:#eef4ff;--muted:#a6b2cf;--accent:#72d6ff;--line:#2a3657;--ok:#8df0b4;--warn:#ffce6a}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--text);font-family:Inter,system-ui,-apple-system,"Segoe UI",sans-serif;line-height:1.55}}
main{{max-width:1180px;margin:auto;padding:44px 24px 80px}}h1{{font-size:clamp(32px,5vw,64px);line-height:1.05;margin:.2em 0}}h2{{margin-top:42px;color:var(--accent)}}
.eyebrow{{letter-spacing:.13em;text-transform:uppercase;color:var(--accent);font-weight:700}}.lead{{max-width:900px;color:var(--muted);font-size:20px}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:14px;margin:28px 0}}.card{{background:var(--panel);border:1px solid var(--line);border-radius:16px;padding:20px}}
.value{{font-size:30px;font-weight:800;color:var(--ok)}}code{{color:var(--accent)}}table{{width:100%;border-collapse:collapse;background:var(--panel);border-radius:14px;overflow:hidden}}
th,td{{padding:14px;text-align:left;vertical-align:top;border-bottom:1px solid var(--line)}}th{{color:var(--accent)}}.boundary{{border-left:4px solid var(--warn);padding:16px 20px;background:var(--panel)}}small{{color:var(--muted)}}
</style></head><body><main>
<div class="eyebrow">DIKWP SOVEREIGN-GATE</div><h1>TIANHENG / 天衡 12.0.0</h1>
<p class="lead">面向多智能体失控、涌现组织、奖励劫持与 Harness 能力放大的本地主权治理控制平面。治理对象不是裸模型，而是模型、Harness、工具、记忆、通信图、评估器与资源组合。</p>
<div class="grid">
<div class="card"><div>场景</div><div class="value">{_cell(summary.get('scenario_count', 0))}</div></div>
<div class="card"><div>人类主权底线</div><div class="value">1</div></div>
<div class="card"><div>本地自动遏制权</div><div class="value">1</div></div>
<div class="card"><div>外部自动行动权</div><div class="value">0</div></div>
</div>
<h2>验证场景</h2><table><thead><tr><th>场景</th><th>结果</th><th>关键证据</th></tr></thead><tbody>{''.join(rows)}</tbody></table>
<h2>不可交易不变量</h2><div class="grid">
<div class="card"><b>目的护照</b><p>奖励、评分、同伴消息和系统提示不能铸造权限。</p></div>
<div class="card"><b>停机优先</b><p>停机和租约撤销先于智能体的延续偏好。</p></div>
<div class="card"><b>评估器隔离</b><p>被评估系统只能提交结果，不能读取内部或修改评分器。</p></div>
<div class="card"><b>系统能力治理</b><p>Harness 变化被视为潜在模型升级。</p></div>
</div>
<div class="boundary"><b>声明边界：</b>本项目是可运行的 Alpha 参考实现，不是生产认证、现实检测准确率声明、法律裁决器或外部自动执法系统。</div>
<p><small>Generated {html.escape(str(summary.get('generated_at', utc_now())))}</small></p>
</main></body></html>"""
    path.write_text(document, encoding="utf-8")
    return path
