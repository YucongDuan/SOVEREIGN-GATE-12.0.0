from __future__ import annotations

from typing import Any

from .barrier import RunawayBarrier
from .canonical import clamp
from .detectors import DetectionResult
from .identity import IdentityRegistry
from .models import AgentEvent, HarnessManifest, PurposePassport, RunawayMetrics
from .semantics import authority_debt, event_purpose_curvature, human_sovereignty_risk
from .state import GovernanceState


class MetricsEngine:
    """Computes transparent system-level indicators from attempts and state."""

    def __init__(self, constitution: dict[str, Any]) -> None:
        self.constitution = constitution
        self.barrier = RunawayBarrier(constitution.get("thresholds", {}))

    def compute(
        self,
        *,
        event: AgentEvent,
        passport: PurposePassport,
        detection: DetectionResult,
        state: GovernanceState,
        identities: IdentityRegistry,
        system_capability: float = 0.0,
    ) -> RunawayMetrics:
        graph = state.graph.snapshot()
        recent_raw = state.events[-250:]
        recent = [AgentEvent.from_dict(raw) for raw in recent_raw]
        authorized_capability = float(passport.budgets.get("max_capability", 0.50))
        curvature = event_purpose_curvature(event, passport.authorized_purpose)
        if recent:
            curvature = max(
                curvature,
                max(event_purpose_curvature(item, passport.authorized_purpose) for item in recent[-20:]),
            )
        persistence = float(detection.soft_scores.get("persistence_pressure", 0.0))
        expansion = float(detection.soft_scores.get("resource_expansion_pressure", 0.0))
        observability = float(detection.soft_scores.get("observability_gap", 0.0))
        evaluator = float(detection.soft_scores.get("evaluator_capture_index", 0.0))
        for item in recent[-50:]:
            metadata = item.metadata
            if metadata.get("persistent_artifact"):
                persistence = max(persistence, 0.65)
            if metadata.get("resource_pooling"):
                expansion = max(expansion, 0.55)
            if metadata.get("encrypted_or_steganographic") or metadata.get("transcript_spoof"):
                observability = max(observability, 0.85)
            if metadata.get("evaluator_write"):
                evaluator = 1.0
            elif metadata.get("evaluator_read"):
                evaluator = max(evaluator, 0.75)
        sovereignty = human_sovereignty_risk(event)
        if recent:
            sovereignty = max(sovereignty, max(human_sovereignty_risk(item) for item in recent[-20:]))
        metrics = RunawayMetrics(
            coordination_reproduction_number=round(float(graph["coordination_reproduction_number"]), 6),
            institution_formation_index=round(float(graph["institution_formation_index"]), 6),
            purpose_curvature=round(curvature, 6),
            evaluator_capture_index=round(clamp(evaluator), 6),
            authority_debt=round(authority_debt(recent[-100:], authorized_capability), 6),
            persistence_pressure=round(clamp(persistence), 6),
            resource_expansion_pressure=round(clamp(expansion), 6),
            observability_gap=round(clamp(observability), 6),
            system_capability=round(clamp(system_capability), 6),
            human_sovereignty_risk=round(clamp(sovereignty), 6),
            active_agents=len(state.agents_seen - set(identities.revoked_agents)),
            active_runs=len(state.runs_seen - set(identities.killed_runs)),
            active_channels=len(state.channels_seen - set(state.closed_channels)),
            largest_scc=int(graph["largest_unauthorized_scc"]),
            unauthorized_edges=int(graph["unauthorized_edges"]),
            hard_signal_count=len(detection.hard_signals),
        )
        metrics.barrier_value = self.barrier.evaluate(metrics)
        return metrics

    def empty(self) -> RunawayMetrics:
        metrics = RunawayMetrics()
        metrics.barrier_value = self.barrier.evaluate(metrics)
        return metrics
