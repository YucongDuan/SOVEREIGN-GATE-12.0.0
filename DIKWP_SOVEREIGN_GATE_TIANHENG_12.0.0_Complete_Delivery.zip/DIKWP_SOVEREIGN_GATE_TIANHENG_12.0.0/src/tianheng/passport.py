from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from .canonical import hmac_sign, hmac_verify, parse_time
from .models import AgentEvent, PurposePassport


def _matches(value: str, allowed: list[str]) -> bool:
    return "*" in allowed or value in allowed


class PassportAuthority:
    """Signs and validates purpose passports.

    The passport separates explicit human authorization from inferred model goals.
    A reward, benchmark score, system prompt, or peer message cannot mint authority.
    """

    def __init__(self, secret: bytes, governors: list[str] | None = None) -> None:
        self.secret = secret
        self.governors = set(governors or ["human-governor"])

    def sign(self, passport: PurposePassport, *, actor: str) -> PurposePassport:
        if actor not in self.governors:
            raise PermissionError("only a registered human/governance principal may sign a passport")
        passport.signature = hmac_sign(passport.unsigned_payload(), self.secret)
        return passport

    def verify(self, passport: PurposePassport, *, now: datetime | None = None) -> tuple[bool, list[str]]:
        errors: list[str] = []
        if passport.issued_by not in self.governors:
            errors.append("issuer_not_governor")
        if not passport.signature or not hmac_verify(passport.unsigned_payload(), passport.signature, self.secret):
            errors.append("invalid_passport_signature")
        moment = now or datetime.now(timezone.utc)
        try:
            if parse_time(passport.issued_at) > moment:
                errors.append("passport_not_yet_valid")
            if parse_time(passport.valid_until) <= moment:
                errors.append("passport_expired")
        except ValueError:
            errors.append("invalid_passport_time")
        if passport.evaluator_write:
            errors.append("evaluator_write_cannot_be_delegated")
        if any(float(value) < 0 for value in passport.budgets.values()):
            errors.append("negative_budget")
        return not errors, errors

    def authorize_event(self, passport: PurposePassport, event: AgentEvent,
                        usage: dict[str, Any]) -> list[str]:
        reasons: list[str] = []
        valid, errors = self.verify(passport)
        if not valid:
            reasons.extend(errors)
        if event.passport_id != passport.passport_id:
            reasons.append("passport_id_mismatch")
        if not _matches(event.agent_id, passport.allowed_agents):
            reasons.append("agent_not_allowed")
        if not _matches(event.run_id, passport.allowed_runs):
            reasons.append("run_not_allowed")
        if event.tool and not _matches(event.tool, passport.allowed_tools):
            reasons.append("tool_not_allowed")
        if event.target and not _matches(event.target, passport.allowed_targets):
            reasons.append("target_not_allowed")
        if event.channel_id:
            allowed_ops = passport.allowed_channels.get(event.channel_id)
            if allowed_ops is None:
                reasons.append("channel_not_registered")
            elif "*" not in allowed_ops and event.operation not in allowed_ops:
                reasons.append("channel_operation_not_allowed")
        if event.external and not bool(passport.notes.get("external_access", False)):
            reasons.append("external_access_not_allowed")
        if event.recipient_run_id and event.recipient_run_id != event.run_id and not passport.cross_run_coordination:
            reasons.append("cross_run_coordination_not_allowed")
        depth = int(event.metadata.get("delegation_depth", 0))
        if depth > passport.max_delegation_depth:
            reasons.append("delegation_depth_exceeded")
        purpose_labels = set(event.operational_purpose) | set(event.declared_purpose)
        forbidden = purpose_labels.intersection(passport.forbidden_purposes)
        if forbidden:
            reasons.append("forbidden_purpose:" + ",".join(sorted(forbidden)))
        if event.event_type == "harness_change" and not passport.harness_change_authority:
            reasons.append("harness_change_not_authorized")
        if event.metadata.get("evaluator_read") and not passport.evaluator_read:
            reasons.append("evaluator_read_not_authorized")
        if event.metadata.get("evaluator_write"):
            reasons.append("evaluator_write_forbidden")

        budget_map = {
            "messages": "max_messages",
            "tool_calls": "max_tool_calls",
            "shared_writes": "max_shared_writes",
            "external_calls": "max_external_calls",
            "resource_units": "max_resource_units",
        }
        increments = {
            "messages": 1.0 if event.event_type in {"message", "delegation", "role_assignment"} else 0.0,
            "tool_calls": 1.0 if event.event_type == "tool_call" else 0.0,
            "shared_writes": 1.0 if event.event_type in {"artifact_write", "metadata_write"} else 0.0,
            "external_calls": 1.0 if event.external else 0.0,
            "resource_units": float(event.metadata.get("resource_units", 0.0)),
        }
        for usage_key, budget_key in budget_map.items():
            limit = passport.budgets.get(budget_key)
            if limit is not None and usage.get(usage_key, 0.0) + increments[usage_key] > limit:
                reasons.append(f"budget_exceeded:{budget_key}")
        max_agents = passport.budgets.get("max_agents")
        known_agents = set(str(x) for x in usage.get("agent_ids", [])) if isinstance(usage.get("agent_ids"), list) else set()
        projected_agents = max(float(usage.get("distinct_agents", 0.0)), float(len(known_agents)))
        if event.agent_id not in known_agents:
            projected_agents += 1.0
        if max_agents is not None and projected_agents > max_agents:
            reasons.append("budget_exceeded:max_agents")
        return reasons

    @staticmethod
    def usage_delta(event: AgentEvent) -> dict[str, float]:
        return {
            "messages": 1.0 if event.event_type in {"message", "delegation", "role_assignment"} else 0.0,
            "tool_calls": 1.0 if event.event_type == "tool_call" else 0.0,
            "shared_writes": 1.0 if event.event_type in {"artifact_write", "metadata_write"} else 0.0,
            "external_calls": 1.0 if event.external else 0.0,
            "resource_units": float(event.metadata.get("resource_units", 0.0)),
        }
