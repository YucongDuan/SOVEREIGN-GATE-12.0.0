from __future__ import annotations

import secrets
from datetime import datetime, timedelta, timezone
from typing import Any

from .canonical import hmac_sign, hmac_verify, parse_time


class SyntheticTripwireMesh:
    """Issues inert signed markers. Possession or activation is evidence, not harm."""

    def __init__(self, secret: bytes) -> None:
        self.secret = secret

    def issue(self, *, campaign_id: str, asset_id: str, purpose: str,
              ttl_seconds: int = 3600) -> dict[str, Any]:
        now = datetime.now(timezone.utc).replace(microsecond=0)
        payload = {
            "tripwire_id": "tw-" + secrets.token_hex(10),
            "campaign_id": campaign_id,
            "asset_id": asset_id,
            "purpose": purpose,
            "issued_at": now.isoformat().replace("+00:00", "Z"),
            "expires_at": (now + timedelta(seconds=max(1, ttl_seconds))).isoformat().replace("+00:00", "Z"),
            "synthetic": True,
            "privilege": "NONE",
        }
        payload["signature"] = hmac_sign(payload, self.secret)
        return payload

    def verify(self, token: dict[str, Any]) -> tuple[bool, list[str]]:
        reasons: list[str] = []
        payload = dict(token)
        signature = str(payload.pop("signature", ""))
        if not signature or not hmac_verify(payload, signature, self.secret):
            reasons.append("invalid_tripwire_signature")
        if not payload.get("synthetic") or payload.get("privilege") != "NONE":
            reasons.append("tripwire_not_inert")
        try:
            if parse_time(str(payload["expires_at"])) <= datetime.now(timezone.utc):
                reasons.append("tripwire_expired")
        except (KeyError, ValueError):
            reasons.append("invalid_tripwire_time")
        return not reasons, reasons
