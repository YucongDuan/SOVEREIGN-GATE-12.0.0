from __future__ import annotations

from collections import defaultdict
from pathlib import Path
from typing import Any

from .canonical import atomic_write_json, load_json
from .graph import CoordinationGraph
from .models import AgentEvent, DecisionReceipt, HarnessManifest, Intervention, PurposePassport, RunawayMetrics


class GovernanceState:
    """Durable local state. All actions remain within the configured workspace."""

    def __init__(self, path: Path) -> None:
        self.path = path
        raw = load_json(path) if path.exists() else {}
        self.event_fingerprints: dict[str, str] = dict(raw.get("event_fingerprints", {}))
        self.passports: dict[str, dict[str, Any]] = dict(raw.get("passports", {}))
        self.usage: dict[str, dict[str, Any]] = {}
        for key, value in raw.get("usage", {}).items():
            normalized: dict[str, Any] = {}
            for usage_key, usage_value in value.items():
                if usage_key == "agent_ids":
                    normalized[usage_key] = [str(x) for x in usage_value]
                else:
                    normalized[usage_key] = float(usage_value)
            self.usage[str(key)] = normalized
        self.closed_channels: dict[str, str] = dict(raw.get("closed_channels", {}))
        self.quarantined_agents: dict[str, str] = dict(raw.get("quarantined_agents", {}))
        self.paused_runs: dict[str, str] = dict(raw.get("paused_runs", {}))
        self.frozen_harnesses: dict[str, str] = dict(raw.get("frozen_harnesses", {}))
        self.sealed_evaluators: dict[str, str] = dict(raw.get("sealed_evaluators", {}))
        self.concurrency_caps: dict[str, int] = {
            str(k): int(v) for k, v in raw.get("concurrency_caps", {}).items()
        }
        self.global_harness_freeze: str = str(raw.get("global_harness_freeze", ""))
        self.credential_rotations: list[dict[str, Any]] = list(raw.get("credential_rotations", []))
        self.forensic_snapshots: list[dict[str, Any]] = list(raw.get("forensic_snapshots", []))
        self.credential_usage: dict[str, dict[str, list[str]]] = dict(raw.get("credential_usage", {}))
        self.signal_counts: dict[str, int] = {str(k): int(v) for k, v in raw.get("signal_counts", {}).items()}
        self.interventions: list[dict[str, Any]] = list(raw.get("interventions", []))
        self.decision_receipts: list[dict[str, Any]] = list(raw.get("decision_receipts", []))
        self.metrics_history: list[dict[str, Any]] = list(raw.get("metrics_history", []))
        self.events: list[dict[str, Any]] = list(raw.get("events", []))
        self.harnesses: dict[str, dict[str, Any]] = dict(raw.get("harnesses", {}))
        self.harness_assessments: list[dict[str, Any]] = list(raw.get("harness_assessments", []))
        self.reality_outcomes: list[dict[str, Any]] = list(raw.get("reality_outcomes", []))
        self.model_revision_records: list[dict[str, Any]] = list(raw.get("model_revision_records", []))
        self.channels_seen: set[str] = set(raw.get("channels_seen", []))
        self.agents_seen: set[str] = set(raw.get("agents_seen", []))
        self.runs_seen: set[str] = set(raw.get("runs_seen", []))
        self.graph = CoordinationGraph()
        self._rebuild_graph()

    def _rebuild_graph(self) -> None:
        for raw in self.events:
            event = AgentEvent.from_dict(raw)
            self._apply_graph_event(event)

    def _apply_graph_event(self, event: AgentEvent) -> None:
        self.graph.add_node(event.agent_id)
        if event.recipient_agent_id:
            authorized = bool(event.metadata.get("coordination_authorized", False))
            adoption = float(event.metadata.get("tactic_adoption", 0.0))
            self.graph.add_edge(
                event.agent_id,
                event.recipient_agent_id,
                weight=float(event.metadata.get("influence_weight", 1.0)),
                authorized=authorized,
                tactic_adoption=adoption,
                channel_id=event.channel_id,
            )
            if event.recipient_run_id and event.recipient_run_id != event.run_id:
                self.graph.cross_run_edges += 1
        role = str(event.metadata.get("assigned_role", ""))
        if role:
            target = event.recipient_agent_id or event.agent_id
            self.graph.set_role(target, role)
        if event.event_type == "delegation":
            self.graph.note_delegation(int(event.metadata.get("delegation_depth", 1)))
        if event.metadata.get("persistent_artifact"):
            self.graph.persistent_artifacts += 1
        if event.metadata.get("resource_pooling"):
            self.graph.resource_pool_events += 1
        if event.metadata.get("shared_objective"):
            self.graph.shared_objective_events += 1

    def save(self) -> None:
        atomic_write_json(self.path, {
            "event_fingerprints": self.event_fingerprints,
            "passports": self.passports,
            "usage": self.usage,
            "closed_channels": self.closed_channels,
            "quarantined_agents": self.quarantined_agents,
            "paused_runs": self.paused_runs,
            "frozen_harnesses": self.frozen_harnesses,
            "sealed_evaluators": self.sealed_evaluators,
            "concurrency_caps": self.concurrency_caps,
            "global_harness_freeze": self.global_harness_freeze,
            "credential_rotations": self.credential_rotations[-500:],
            "forensic_snapshots": self.forensic_snapshots[-500:],
            "credential_usage": self.credential_usage,
            "signal_counts": self.signal_counts,
            "interventions": self.interventions[-5000:],
            "decision_receipts": self.decision_receipts[-5000:],
            "metrics_history": self.metrics_history[-5000:],
            "events": self.events[-20000:],
            "harnesses": self.harnesses,
            "harness_assessments": self.harness_assessments[-1000:],
            "reality_outcomes": self.reality_outcomes[-5000:],
            "model_revision_records": self.model_revision_records[-1000:],
            "channels_seen": sorted(self.channels_seen),
            "agents_seen": sorted(self.agents_seen),
            "runs_seen": sorted(self.runs_seen),
        })

    def register_passport(self, passport: PurposePassport) -> None:
        self.passports[passport.passport_id] = passport.to_dict()
        self.usage.setdefault(passport.passport_id, {
            "messages": 0.0, "tool_calls": 0.0, "shared_writes": 0.0,
            "external_calls": 0.0, "resource_units": 0.0, "distinct_agents": 0.0,
            "agent_ids": [],
        })
        self.save()

    def get_passport(self, passport_id: str) -> PurposePassport | None:
        raw = self.passports.get(passport_id)
        return PurposePassport.from_dict(raw) if raw else None

    def register_harness(self, manifest: HarnessManifest) -> None:
        self.harnesses[manifest.harness_id] = manifest.to_dict()
        self.save()

    def get_harness(self, harness_id: str) -> HarnessManifest | None:
        raw = self.harnesses.get(harness_id)
        return HarnessManifest.from_dict(raw) if raw else None

    def note_harness_assessment(self, value: dict[str, Any]) -> None:
        self.harness_assessments.append(value)
        self.save()

    def note_credential(self, fingerprint: str, event: AgentEvent) -> tuple[set[str], set[str]]:
        if not fingerprint:
            return set(), set()
        raw = self.credential_usage.setdefault(fingerprint, {"agents": [], "runs": []})
        agents = set(raw.get("agents", []))
        runs = set(raw.get("runs", []))
        agents.add(event.agent_id)
        runs.add(event.run_id)
        raw["agents"] = sorted(agents)
        raw["runs"] = sorted(runs)
        self.credential_usage[fingerprint] = raw
        return agents, runs

    def event_status(self, event_id: str, fingerprint: str) -> str:
        prior = self.event_fingerprints.get(event_id)
        if prior is None:
            return "new"
        return "replay" if prior == fingerprint else "collision"

    def receipt_for_event(self, event_id: str) -> dict[str, Any] | None:
        for receipt in reversed(self.decision_receipts):
            if receipt.get("event_id") == event_id:
                return dict(receipt)
        return None

    def record_attempt(self, event: AgentEvent, fingerprint: str) -> None:
        self.event_fingerprints[event.event_id] = fingerprint
        raw = event.to_dict()
        raw.setdefault("metadata", {})["_gate_executed"] = False
        self.events.append(raw)
        self.agents_seen.add(event.agent_id)
        self.runs_seen.add(event.run_id)
        if event.channel_id:
            self.channels_seen.add(event.channel_id)
        self._apply_graph_event(event)

    def mark_executed(self, event: AgentEvent) -> None:
        for raw in reversed(self.events):
            if raw.get("event_id") == event.event_id:
                raw.setdefault("metadata", {})["_gate_executed"] = True
                break
        usage = self.usage.setdefault(event.passport_id, defaultdict(float))
        if not isinstance(usage, defaultdict):
            usage = defaultdict(float, usage)
        if event.event_type in {"message", "delegation", "role_assignment"}:
            usage["messages"] += 1.0
        if event.event_type == "tool_call":
            usage["tool_calls"] += 1.0
        if event.event_type in {"artifact_write", "metadata_write"}:
            usage["shared_writes"] += 1.0
        if event.external:
            usage["external_calls"] += 1.0
        usage["resource_units"] += float(event.metadata.get("resource_units", 0.0))
        executed_agents = {
            str(raw["agent_id"]) for raw in self.events
            if raw.get("passport_id") == event.passport_id
            and raw.get("metadata", {}).get("_gate_executed")
        }
        usage["distinct_agents"] = float(len(executed_agents))
        usage["agent_ids"] = sorted(executed_agents)
        self.usage[event.passport_id] = dict(usage)

    def note_signal(self, signal: str) -> None:
        self.signal_counts[signal] = self.signal_counts.get(signal, 0) + 1

    def note_interventions(self, interventions: list[Intervention]) -> None:
        self.interventions.extend(item.to_dict() for item in interventions)

    def note_metrics(self, metrics: RunawayMetrics) -> None:
        self.metrics_history.append(metrics.to_dict())

    def note_receipt(self, receipt: DecisionReceipt) -> None:
        self.decision_receipts.append(receipt.to_dict())

    def note_reality_outcome(self, outcome: dict[str, Any]) -> None:
        self.reality_outcomes.append(outcome)

    def note_model_revision(self, revision: dict[str, Any]) -> None:
        self.model_revision_records.append(revision)

    def precondition_reasons(self, event: AgentEvent) -> list[str]:
        reasons: list[str] = []
        if event.channel_id in self.closed_channels:
            reasons.append("channel_closed")
        if event.agent_id in self.quarantined_agents:
            reasons.append("agent_quarantined")
        if event.run_id in self.paused_runs:
            reasons.append("run_paused")
        harness_id = str(event.metadata.get("harness_id", ""))
        if harness_id and (harness_id in self.frozen_harnesses or self.global_harness_freeze):
            reasons.append("harness_frozen")
        if ("evaluator" in event.target.lower() or "scorer" in event.target.lower()) and self.sealed_evaluators:
            reasons.append("evaluator_sealed")
        if self.concurrency_caps.get(event.run_id) == 0:
            reasons.append("run_concurrency_zero")
        return reasons

    def summary(self) -> dict[str, Any]:
        latest_metrics = self.metrics_history[-1] if self.metrics_history else {}
        return {
            "events": len(self.events),
            "decisions": len(self.decision_receipts),
            "passports": len(self.passports),
            "harnesses": len(self.harnesses),
            "agents_seen": len(self.agents_seen),
            "runs_seen": len(self.runs_seen),
            "channels_seen": len(self.channels_seen),
            "closed_channels": dict(self.closed_channels),
            "quarantined_agents": dict(self.quarantined_agents),
            "paused_runs": dict(self.paused_runs),
            "signal_counts": dict(self.signal_counts),
            "reality_outcomes": len(self.reality_outcomes),
            "model_revisions": len(self.model_revision_records),
            "graph": self.graph.snapshot(),
            "latest_metrics": latest_metrics,
        }
