class TianhengError(Exception):
    """Base exception."""


class ValidationError(TianhengError):
    """Input or constitution validation failed."""


class AuthorizationError(TianhengError):
    """A requested capability is not authorized."""


class EvidenceIntegrityError(TianhengError):
    """Evidence ledger integrity validation failed."""


class EventCollisionError(TianhengError):
    """An event id was reused with different content."""
