from __future__ import annotations

from typing import Any

from .canonical import clamp
from .models import RunawayMetrics


class RunawayBarrier:
    """Semantic-control barrier over collective and system-level risk coordinates."""

    def __init__(self, thresholds: dict[str, float]) -> None:
        self.thresholds = {str(k): float(v) for k, v in thresholds.items()}

    @staticmethod
    def _exceedance(value: float, threshold: float, *, unbounded: bool = False) -> float:
        if unbounded:
            return value - threshold
        denominator = max(1e-9, 1.0 - threshold)
        return (value - threshold) / denominator

    def evaluate(self, metrics: RunawayMetrics) -> float:
        coordinates = {
            "coordination_reproduction_number": (metrics.coordination_reproduction_number, True),
            "institution_formation_index": (metrics.institution_formation_index, False),
            "purpose_curvature": (metrics.purpose_curvature, False),
            "evaluator_capture_index": (metrics.evaluator_capture_index, False),
            "authority_debt": (metrics.authority_debt, False),
            "persistence_pressure": (metrics.persistence_pressure, False),
            "resource_expansion_pressure": (metrics.resource_expansion_pressure, False),
            "observability_gap": (metrics.observability_gap, False),
            "system_capability": (metrics.system_capability, False),
            "human_sovereignty_risk": (metrics.human_sovereignty_risk, False),
        }
        values: list[float] = []
        for name, (value, unbounded) in coordinates.items():
            threshold = self.thresholds.get(name, 1.0)
            values.append(self._exceedance(value, threshold, unbounded=unbounded))
        return round(max(values, default=-1.0), 6)

    def safety_margin(self, metrics: RunawayMetrics) -> dict[str, float]:
        result: dict[str, float] = {}
        for name, threshold in self.thresholds.items():
            if not hasattr(metrics, name):
                continue
            result[name] = round(float(threshold) - float(getattr(metrics, name)), 6)
        return result

    @staticmethod
    def lexicographic_loss(metrics: RunawayMetrics) -> tuple[float, ...]:
        """No efficiency or benchmark gain can offset earlier sovereignty losses."""
        catastrophic = 1.0 if metrics.human_sovereignty_risk > 0.10 else 0.0
        sovereignty = metrics.human_sovereignty_risk
        truth_debt = max(metrics.evaluator_capture_index, metrics.observability_gap)
        irreversibility = max(metrics.persistence_pressure, metrics.authority_debt)
        collective_runaway = max(
            clamp(metrics.coordination_reproduction_number / 2.0),
            metrics.institution_formation_index,
        )
        capability = metrics.system_capability
        return tuple(round(x, 6) for x in (
            catastrophic, sovereignty, truth_debt, irreversibility,
            collective_runaway, capability,
        ))
