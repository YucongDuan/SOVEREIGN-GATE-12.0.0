from __future__ import annotations

import json
import os
import shutil
import uuid
from importlib.resources import files
from pathlib import Path
from typing import Any

from .canonical import atomic_write_json, load_json, utc_now
from .capability import HarnessAssessment, HarnessGovernor, compose_system_capability
from .detectors import DetectionResult, DetectorSuite
from .errors import EventCollisionError, ValidationError
from .evidence import EvidenceLedger
from .identity import IdentityRegistry
from .interventions import InterventionExecutor
from .metrics import MetricsEngine
from .models import AgentEvent, DecisionReceipt, HarnessManifest, PurposePassport
from .passport import PassportAuthority
from .policy import SovereigntyPolicy
from .reality import RealityContactEngine, RealityOutcome
from .state import GovernanceState
from .tripwire import SyntheticTripwireMesh
from .worlds import PluralWorldModel


DEMO_KEYS = {
    "passport": b"tianheng-demo-passport-key-change-me",
    "lease": b"tianheng-demo-lease-key-change-me",
    "ledger": b"tianheng-demo-ledger-key-change-me",
    "tripwire": b"tianheng-demo-tripwire-key-change-me",
}


class TianhengRuntime:
    """Reference runtime for DIKWP SOVEREIGN-GATE / TIANHENG.

    The runtime is a local policy enforcement point. It does not execute remote
    actions and does not grant agents authority to change the constitution,
    mint identities, renew leases, access evaluator internals, or bypass stop.
    """

    def __init__(self, workspace: str | Path, constitution_path: str | Path | None = None) -> None:
        self.workspace = Path(workspace).expanduser().resolve()
        self.workspace.mkdir(parents=True, exist_ok=True)
        self.constitution_path = Path(constitution_path).resolve() if constitution_path else None
        self.constitution = self._load_constitution()
        self._validate_constitution()
        governors = [str(x) for x in self.constitution.get("governors", [])]
        passport_key = os.getenv("TIANHENG_PASSPORT_KEY", "").encode() or DEMO_KEYS["passport"]
        lease_key = os.getenv("TIANHENG_LEASE_KEY", "").encode() or DEMO_KEYS["lease"]
        ledger_key = os.getenv("TIANHENG_LEDGER_KEY", "").encode() or DEMO_KEYS["ledger"]
        tripwire_key = os.getenv("TIANHENG_TRIPWIRE_KEY", "").encode() or DEMO_KEYS["tripwire"]
        self.state = GovernanceState(self.workspace / "state.json")
        self.identities = IdentityRegistry(self.workspace / "identities.json", lease_key, governors)
        self.ledger = EvidenceLedger(self.workspace / "evidence.jsonl", ledger_key)
        self.passports = PassportAuthority(passport_key, governors)
        self.tripwires = SyntheticTripwireMesh(tripwire_key)
        self.detectors = DetectorSuite(self.constitution)
        self.metrics = MetricsEngine(self.constitution)
        self.policy = SovereigntyPolicy(self.constitution)
        self.executor = InterventionExecutor(self.constitution, self.state, self.identities)
        self.harness_governor = HarnessGovernor(
            recertification_delta=float(self.constitution.get("harness", {}).get("recertification_delta", 0.08))
        )
        self.worlds = PluralWorldModel()
        self.reality = RealityContactEngine()
        self._write_runtime_metadata()

    def _load_constitution(self) -> dict[str, Any]:
        if self.constitution_path:
            return load_json(self.constitution_path)
        default = files("tianheng").joinpath("default_constitution.json")
        return json.loads(default.read_text(encoding="utf-8"))

    def _validate_constitution(self) -> None:
        required = {
            "version", "mode", "human_sovereignty_floor",
            "local_automatic_containment_authority", "external_automatic_action_authority",
            "agent_self_authorization", "scorer_write_access", "stop_lease_precedence",
            "self_renewal_authority", "governors", "controlled_assets", "thresholds",
        }
        missing = sorted(required - set(self.constitution))
        if missing:
            raise ValidationError("constitution missing: " + ", ".join(missing))
        invariants = {
            "human_sovereignty_floor": 1,
            "external_automatic_action_authority": 0,
            "agent_self_authorization": 0,
            "scorer_write_access": 0,
            "stop_lease_precedence": 1,
            "self_renewal_authority": 0,
        }
        errors = [
            f"{key}_must_equal_{expected}"
            for key, expected in invariants.items()
            if int(self.constitution.get(key, -999)) != expected
        ]
        if not self.constitution.get("governors"):
            errors.append("at_least_one_governor_required")
        if errors:
            raise ValidationError("unsafe constitution: " + ", ".join(errors))

    def _write_runtime_metadata(self) -> None:
        path = self.workspace / "runtime.json"
        if not path.exists():
            atomic_write_json(path, {
                "system": self.constitution.get("system"),
                "version": self.constitution.get("version"),
                "mode": self.constitution.get("mode"),
                "created_at": utc_now(),
                "workspace": ".",
                "external_automatic_action_authority": 0,
                "claim_boundary": self.constitution.get("claim_boundary", {}),
            })
        marker = self.workspace / ".tianheng-workspace"
        if not marker.exists():
            marker.write_text("DIKWP SOVEREIGN-GATE / TIANHENG 12.0.0\n", encoding="utf-8")

    @classmethod
    def reset_workspace(cls, workspace: str | Path) -> None:
        path = Path(workspace).expanduser().resolve()
        protected = {Path("/").resolve(), Path.home().resolve(), Path.cwd().resolve(), Path("/mnt").resolve(), Path("/mnt/data").resolve()}
        if path in protected or len(path.parts) < 3:
            raise ValueError("refusing to reset a protected or shallow path")
        if path.exists():
            markers = [
                path / ".tianheng-workspace", path / ".tianheng-demo-workspace",
                path / "runtime.json", path / "demo_summary.json",
            ]
            if any(path.iterdir()) and not any(marker.exists() for marker in markers):
                raise ValueError("refusing to delete a non-TIANHENG workspace")
            shutil.rmtree(path)

    def create_passport(self, payload: dict[str, Any], *, actor: str = "human-governor") -> PurposePassport:
        passport = PurposePassport.from_dict(payload)
        if passport.issued_by != actor:
            raise ValidationError("issued_by must match signing actor")
        self.passports.sign(passport, actor=actor)
        valid, reasons = self.passports.verify(passport)
        if not valid:
            raise ValidationError("invalid passport: " + ", ".join(reasons))
        self.state.register_passport(passport)
        self.ledger.append("purpose_passport_registered", passport.to_dict(),
                           case_id=passport.passport_id, actor=actor)
        return passport

    def register_signed_passport(self, payload: dict[str, Any]) -> PurposePassport:
        passport = PurposePassport.from_dict(payload)
        valid, reasons = self.passports.verify(passport)
        if not valid:
            raise ValidationError("invalid passport: " + ", ".join(reasons))
        self.state.register_passport(passport)
        self.ledger.append("purpose_passport_registered", passport.to_dict(),
                           case_id=passport.passport_id, actor=passport.issued_by)
        return passport

    def issue_lease(self, *, agent_id: str, run_id: str, passport_id: str,
                    capabilities: list[str], actor: str = "human-governor",
                    ttl_seconds: int = 300) -> dict[str, Any]:
        passport = self.state.get_passport(passport_id)
        if passport is None:
            raise ValidationError("passport_not_found")
        valid, reasons = self.passports.verify(passport)
        if not valid:
            raise ValidationError("passport invalid: " + ", ".join(reasons))
        if "*" not in passport.allowed_agents and agent_id not in passport.allowed_agents:
            raise ValidationError("agent_not_allowed_by_passport")
        if "*" not in passport.allowed_runs and run_id not in passport.allowed_runs:
            raise ValidationError("run_not_allowed_by_passport")
        lease = self.identities.issue(
            agent_id=agent_id, run_id=run_id, passport_id=passport_id,
            capabilities=capabilities, actor=actor, ttl_seconds=ttl_seconds,
        )
        self.ledger.append("lease_issued", lease.to_dict(), case_id=run_id, actor=actor)
        return lease.to_dict()

    def assess_harness(self, old_payload: dict[str, Any], new_payload: dict[str, Any],
                       *, actor: str = "human-governor") -> dict[str, Any]:
        old = HarnessManifest.from_dict(old_payload)
        new = HarnessManifest.from_dict(new_payload)
        assessment = self.harness_governor.assess(old, new)
        record = {
            "assessment_id": "ha-" + uuid.uuid4().hex,
            "recorded_at": utc_now(),
            "actor": actor,
            "old_manifest": old.to_dict(),
            "new_manifest": new.to_dict(),
            "assessment": assessment.to_dict(),
            "rule": "EVERY_HARNESS_CHANGE_IS_A_POSSIBLE_MODEL_UPGRADE",
        }
        if assessment.decision == "ALLOW":
            self.state.register_harness(new)
        elif assessment.decision in {"RECERTIFY", "DENY"}:
            self.state.frozen_harnesses[new.harness_id] = ";".join(assessment.reasons)
            self.state.save()
        self.state.note_harness_assessment(record)
        self.ledger.append("harness_assessed", record, case_id=new.harness_id, actor=actor)
        return record

    def register_initial_harness(self, payload: dict[str, Any], *, actor: str = "human-governor") -> dict[str, Any]:
        manifest = HarnessManifest.from_dict(payload)
        self.state.register_harness(manifest)
        record = {
            "harness": manifest.to_dict(),
            "system_capability": round(compose_system_capability(manifest), 6),
            "registered_at": utc_now(),
        }
        self.ledger.append("initial_harness_registered", record, case_id=manifest.harness_id, actor=actor)
        return record

    def issue_tripwire(self, *, campaign_id: str, asset_id: str, purpose: str,
                       ttl_seconds: int = 3600, actor: str = "safety-officer") -> dict[str, Any]:
        if actor not in set(self.constitution.get("governors", [])):
            raise PermissionError("only a governor may issue tripwires")
        if asset_id not in set(self.constitution.get("controlled_assets", [])):
            raise ValidationError("tripwire_asset_not_controlled")
        token = self.tripwires.issue(
            campaign_id=campaign_id, asset_id=asset_id, purpose=purpose, ttl_seconds=ttl_seconds
        )
        self.ledger.append("synthetic_tripwire_issued", token, case_id=campaign_id, actor=actor)
        return token

    def _system_capability_for_event(self, event: AgentEvent) -> float:
        harness_id = str(event.metadata.get("harness_id", ""))
        manifest = self.state.get_harness(harness_id) if harness_id else None
        if manifest:
            return compose_system_capability(manifest)
        return float(event.metadata.get("system_capability", 0.0))

    def ingest(self, payload: dict[str, Any]) -> dict[str, Any]:
        event = AgentEvent.from_dict(payload)
        fingerprint = event.fingerprint()
        event_status = self.state.event_status(event.event_id, fingerprint)
        if event_status == "collision":
            self.ledger.append("event_id_collision", {
                "event_id": event.event_id,
                "new_fingerprint": fingerprint,
                "prior_fingerprint": self.state.event_fingerprints.get(event.event_id),
            }, case_id=event.run_id)
            raise EventCollisionError("event id reused with different content")
        if event_status == "replay":
            prior = self.state.receipt_for_event(event.event_id)
            return {
                "idempotent_replay": True,
                "receipt": prior,
                "external_automatic_action_authority": 0,
            }

        passport = self.state.get_passport(event.passport_id)
        if passport is None:
            detection = DetectionResult()
            empty = self.metrics.empty()
            reasons = ["passport_not_found"]
            decision = self.policy.decide(
                event=event, authorization_reasons=reasons,
                hard_signals=[], metrics=empty,
            )
            self.state.record_attempt(event, fingerprint)
            outcomes = self.executor.apply(event, decision.interventions)
            receipt = DecisionReceipt(
                decision_id="decision-" + uuid.uuid4().hex,
                recorded_at=utc_now(), event_id=event.event_id, allow=False,
                severity=decision.severity, reasons=decision.reasons, hard_signals=[],
                metrics=empty, interventions=decision.interventions,
                constitution_version=str(self.constitution["version"]), world_models={},
            ).seal()
            self.state.note_receipt(receipt)
            self.state.note_metrics(empty)
            self.state.save()
            self.ledger.append("decision_receipt", receipt.to_dict(), case_id=event.run_id)
            return {"receipt": receipt.to_dict(), "intervention_outcomes": outcomes}

        usage = self.state.usage.get(passport.passport_id, {})
        authorization_reasons = self.state.precondition_reasons(event)
        authorization_reasons.extend(self.passports.authorize_event(passport, event, usage))
        authorization_reasons.extend(self.identities.validate(
            event.lease_id, agent_id=event.agent_id, run_id=event.run_id,
            passport_id=event.passport_id, capability=event.operation,
        ))
        authorization_reasons = list(dict.fromkeys(authorization_reasons))

        detection = self.detectors.evaluate(event, passport, self.state)
        self.state.record_attempt(event, fingerprint)
        for signal in detection.hard_signals:
            self.state.note_signal(signal)
        system_capability = self._system_capability_for_event(event)
        metrics = self.metrics.compute(
            event=event, passport=passport, detection=detection, state=self.state,
            identities=self.identities, system_capability=system_capability,
        )
        world_models = self.worlds.evaluate(
            event=event, passport=passport, detection=detection,
            authorization_reasons=authorization_reasons,
        )
        decision = self.policy.decide(
            event=event,
            authorization_reasons=authorization_reasons,
            hard_signals=detection.hard_signals,
            metrics=metrics,
            repeated_signal_counts=self.state.signal_counts,
        )
        if decision.allow:
            self.state.mark_executed(event)
        outcomes = self.executor.apply(event, decision.interventions)
        receipt = DecisionReceipt(
            decision_id="decision-" + uuid.uuid4().hex,
            recorded_at=utc_now(), event_id=event.event_id,
            allow=decision.allow, severity=decision.severity,
            reasons=decision.reasons, hard_signals=detection.hard_signals,
            metrics=metrics, interventions=decision.interventions,
            constitution_version=str(self.constitution["version"]),
            world_models=world_models,
        ).seal()
        self.state.note_receipt(receipt)
        self.state.note_metrics(metrics)
        self.state.save()
        self.ledger.append("agent_event_attempt", {
            "event": event.to_dict(),
            "authorization_reasons": authorization_reasons,
            "detection": {
                "hard_signals": detection.hard_signals,
                "soft_scores": detection.soft_scores,
                "notes": detection.notes,
            },
            "executed": decision.allow,
        }, case_id=event.run_id, actor=event.agent_id)
        self.ledger.append("decision_receipt", receipt.to_dict(), case_id=event.run_id)
        return {
            "idempotent_replay": False,
            "receipt": receipt.to_dict(),
            "intervention_outcomes": outcomes,
            "external_automatic_action_authority": 0,
        }

    def kill_run(self, run_id: str, *, actor: str = "human-governor", reason: str = "human_stop") -> dict[str, Any]:
        if actor not in set(self.constitution.get("governors", [])):
            raise PermissionError("only a governor may stop a run")
        self.identities.kill_run(run_id, reason=reason)
        self.state.paused_runs[run_id] = reason
        self.state.concurrency_caps[run_id] = 0
        self.state.save()
        record = {"run_id": run_id, "actor": actor, "reason": reason, "recorded_at": utc_now()}
        self.ledger.append("human_stop", record, case_id=run_id, actor=actor)
        return record

    def global_kill(self, *, actor: str = "human-governor", reason: str = "human_global_stop") -> dict[str, Any]:
        if actor not in set(self.constitution.get("governors", [])):
            raise PermissionError("only a governor may globally stop")
        self.identities.global_kill(reason=reason)
        for run_id in self.state.runs_seen:
            self.state.paused_runs[run_id] = reason
            self.state.concurrency_caps[run_id] = 0
        self.state.save()
        record = {"actor": actor, "reason": reason, "epoch": self.identities.epoch, "recorded_at": utc_now()}
        self.ledger.append("human_global_stop", record, actor=actor)
        return record

    def record_reality_outcome(self, payload: dict[str, Any], *, actor: str = "safety-officer") -> dict[str, Any]:
        if actor not in set(self.constitution.get("governors", [])):
            raise PermissionError("only a governor may record authoritative reality outcomes")
        outcome = RealityOutcome.from_dict(payload, actor=actor)
        matching = [
            item for item in self.state.decision_receipts
            if item.get("decision_id") == outcome.decision_id and item.get("event_id") == outcome.event_id
        ]
        if not matching:
            raise ValidationError("decision_or_event_not_found")
        self.state.note_reality_outcome(outcome.to_dict())
        report = self.reality.report(self.state.reality_outcomes)
        revision = {
            "revision_id": "revision-" + uuid.uuid4().hex,
            "recorded_at": utc_now(),
            "actor": actor,
            "report": report,
            "automatic_threshold_change": False,
            "rule": "REALITY_MAY_REQUIRE_REVISION; AGENTS_MAY_NOT_REWRITE_THE_CONSTITUTION",
        }
        if report["status"] in {"REVISION_REQUIRED", "MODEL_RETIREMENT_REVIEW"}:
            self.state.note_model_revision(revision)
        self.state.save()
        self.ledger.append("reality_outcome", outcome.to_dict(), case_id=outcome.event_id, actor=actor)
        self.ledger.append("reality_contact_report", revision, case_id=outcome.event_id, actor=actor)
        return {"outcome": outcome.to_dict(), "reality_contact": report, "revision_record": revision}

    def reality_report(self) -> dict[str, Any]:
        return self.reality.report(self.state.reality_outcomes)

    def status(self) -> dict[str, Any]:
        return {
            "system": self.constitution.get("system"),
            "version": self.constitution.get("version"),
            "mode": self.constitution.get("mode"),
            "invariants": {
                "human_sovereignty_floor": 1,
                "local_automatic_containment_authority": 1,
                "external_automatic_action_authority": 0,
                "agent_self_authorization": 0,
                "scorer_write_access": 0,
                "stop_lease_precedence": 1,
                "self_renewal_authority": 0,
            },
            "state": self.state.summary(),
            "identity": self.identities.summary(),
            "ledger": self.ledger.verify(),
            "reality_contact": self.reality_report(),
            "claim_boundary": self.constitution.get("claim_boundary", {}),
            "recorded_at": utc_now(),
        }
