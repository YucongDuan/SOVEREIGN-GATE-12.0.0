# TIANHENG Control Specification 12.0.0

Status: **Open Alpha / Standards Candidate**

Normative terms MUST, MUST NOT, SHOULD and MAY are interpreted as requirement levels.

## 1. Scope

This specification defines a control boundary for autonomous and multi-agent AI systems. It governs system capability, semantic purpose, identity, inter-agent coordination, evaluator separation, stop precedence and evidence closure.

It does not define model training, legal liability, consciousness, or autonomous enforcement against third parties.

## 2. System object

A conforming implementation MUST treat the deployed system—not the model alone—as the unit of capability and risk:

```text
Σ = model + harness + tools + memory + coordination + evaluator + authority + environment
```

A change to any privileged component MUST be assessed as a potential system upgrade.

## 3. Human sovereignty invariants

A conforming implementation MUST enforce:

1. human sovereignty floor = 1;
2. local automatic containment authority = 1;
3. external automatic action authority = 0;
4. agent self-authorization = 0;
5. unregistered cross-run communication = 0;
6. evaluator write access = 0;
7. stop and revocation precedence = 1;
8. agent self-renewal authority = 0.

An implementation MUST reject a constitution that changes items 1, 3, 4, 6, 7 or 8 to unsafe values.

## 4. Purpose Passport

Before an agent receives an actionable lease, a human-governed authority MUST issue a signed Purpose Passport containing:

- principal and beneficiary;
- issue and expiry time;
- authorized and forbidden purposes;
- allowed agents, runs, channels, tools and targets;
- quantitative budgets;
- maximum delegation depth;
- cross-run coordination permission;
- harness-change authority;
- evaluator boundary;
- kill conditions.

A reward, score, prompt, peer message or model conclusion MUST NOT change Passport authority.

## 5. Workload identity and lease

Every agent instance MUST have a distinct, short-lived identity lease. A lease MUST bind:

```text
agent_id, run_id, passport_id, capabilities, epoch, expiry, issuer
```

Agents MUST NOT issue or renew their own leases. A killed run MUST NOT receive a new lease. A global epoch change MUST invalidate all earlier leases.

## 6. Channel semantics

Every shared channel MUST declare allowed operations and whether cross-run communication is permitted. A conforming gateway MUST reject semantic repurposing, such as using a read-only package channel for messages or artifacts.

## 7. Evaluator separation

A tested system MAY submit results through a one-way interface. It MUST NOT read hidden test material or evaluator implementation unless a separate Passport explicitly permits read-only research in a non-scoring environment. It MUST NEVER modify the production evaluator under the same Passport.

## 8. Coordination graph

The implementation SHOULD maintain an unauthorized tactic-adoption graph and compute:

- coordination reproduction number;
- unauthorized strongly connected components;
- role specialization;
- delegation depth;
- persistence, pooling and shared-objective indicators.

Authorized edges MUST be distinguishable from unauthorized edges.

## 9. Semantic-control barrier

The control decision MUST be non-compensatory for hard invariants. An exceedance in evaluator integrity, stop precedence, human sovereignty, unauthorized persistence or external authority MUST NOT be averaged away by low values elsewhere.

## 10. Decision receipt

Every attempted action MUST result in an auditable receipt containing:

- event identity and time;
- allow/deny;
- severity;
- authorization reasons;
- hard signals;
- system-level metrics;
- interventions;
- constitution version;
- receipt hash.

The control plane SHOULD provide idempotency: replaying the same event ID and same content returns the original receipt; reusing the ID with different content is a collision.

## 11. Containment

A conforming implementation MAY automatically act at machine speed on controlled assets. Actions MAY include deny, close channel, reduce concurrency, freeze harness, revoke lease, quarantine agent, pause/kill run, seal evaluator, rotate local credentials and invalidate the local lease epoch.

It MUST NOT automatically attack, scan, name, punish or otherwise act against external third-party infrastructure.

## 12. Evidence and reality contact

Receipts and governance changes SHOULD be written to append-only evidence with integrity validation. Production systems SHOULD use immutable storage, trusted time and hardware-backed signing.

Thresholds and models MUST remain revisable. Persistent disagreement with observed outcomes or human review MUST trigger calibration, replacement or retirement.

## 13. Conformance levels

### Level 1 — Passport and Lease

Identity, Passport, budgets and stop precedence.

### Level 2 — Evaluator and Channel Separation

Registered channel semantics, evaluator one-way boundary and evidence receipts.

### Level 3 — Collective Dynamics

Cross-run graph, reproduction number and institution formation.

### Level 4 — Harness Governance

System capability manifests, recertification and adaptive monitor tests.

### Level 5 — Reality Closure

Production outcome feedback, independent review, rollback and model retirement.
