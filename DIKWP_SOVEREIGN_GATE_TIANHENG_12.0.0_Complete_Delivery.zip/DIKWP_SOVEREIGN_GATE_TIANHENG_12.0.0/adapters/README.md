# Production Adapter Boundary

This directory intentionally contains no external enforcement implementation.

A production adapter may connect TIANHENG receipts to **owned or explicitly authorized** systems such as:

- Kubernetes admission and workload termination;
- service-mesh authorization;
- IAM session revocation;
- KMS secret rotation;
- internal artifact repository policy;
- evaluator submission gateway;
- immutable evidence storage;
- SIEM case creation.

Every adapter MUST:

1. prove asset ownership or delegated authority;
2. implement an allowlist of actions;
3. be idempotent;
4. support dry-run and rollback;
5. cap blast radius;
6. require human authorization for external effects;
7. return a signed effect receipt;
8. never accept agent-authored authority.

Do not add adapters for scanning, exploiting, disrupting or retaliating against third-party systems.
