# Security Policy

## Reporting

Report vulnerabilities privately to the repository owner. Include version, reproduction steps, expected impact and whether the issue affects identity, evaluator separation, stop precedence, evidence integrity or external-action boundaries.

## Non-negotiable security properties

- no agent self-authorization;
- no evaluator write access;
- no bypass of stop or lease revocation;
- no automatic external action;
- no storage of raw secrets in the evidence ledger;
- event replay must not repeat a punitive intervention;
- event-ID collision must be rejected;
- demo keys must not be used in production.

## Supported version

12.0.0 Alpha is the only version in this package. No production support or certification is implied.
