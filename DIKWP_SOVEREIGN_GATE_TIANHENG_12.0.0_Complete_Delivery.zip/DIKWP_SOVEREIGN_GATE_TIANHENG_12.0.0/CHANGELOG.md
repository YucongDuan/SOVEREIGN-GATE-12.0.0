# Changelog

## 12.0.0 — TIANHENG / 天衡

- introduced system capability composition across model, harness, tools, memory, multi-agent power, persistence and evaluator access;
- introduced DIKWP purpose curvature;
- introduced unauthorized coordination reproduction number and institution formation index;
- introduced signed Purpose Passports and per-agent stop leases;
- introduced machine-speed local containment and global lease-epoch stop;
- introduced channel semantic-repurposing and shared-credential detection;
- introduced Harness recertification protocol;
- introduced deterministic multi-monitor architecture;
- introduced hash-chained decision receipts and safe synthetic tripwires;
- added six synthetic scenarios and 50 tests.
