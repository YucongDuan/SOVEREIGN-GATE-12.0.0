from __future__ import annotations

import base64
import csv
import hashlib
import io
import json
import os
import shutil
import subprocess
import sys
import tarfile
import tempfile
import zipapp
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

ROOT = Path(__file__).resolve().parents[1]
RELEASE = ROOT / "release"
VERSION = "12.0.0"
DIST = "dikwp_tianheng"


def now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def wheel_hash(data: bytes) -> str:
    return "sha256=" + base64.urlsafe_b64encode(hashlib.sha256(data).digest()).rstrip(b"=").decode()


def project_files(include_outputs: bool = False) -> list[Path]:
    excluded_parts = {".git", ".venv", "__pycache__", ".pytest_cache", "build", "dist"}
    result = []
    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        rel = path.relative_to(ROOT)
        if any(part in excluded_parts for part in rel.parts):
            continue
        if path.suffix in {".pyc", ".pyo"}:
            continue
        if rel.parts and rel.parts[0] == "release":
            continue
        if rel.parts and rel.parts[0] == "outputs" and not include_outputs:
            if rel.as_posix() != "outputs/.gitkeep":
                continue
        result.append(path)
    return sorted(result, key=lambda p: p.relative_to(ROOT).as_posix())


def create_wheel() -> Path:
    path = RELEASE / f"{DIST}-{VERSION}-py3-none-any.whl"
    files: dict[str, bytes] = {}
    package = ROOT / "src" / "tianheng"
    for source in sorted(package.iterdir()):
        if source.is_file() and (source.suffix == ".py" or source.name == "default_constitution.json"):
            files[f"tianheng/{source.name}"] = source.read_bytes()
    dist_info = f"{DIST}-{VERSION}.dist-info"
    files[f"{dist_info}/METADATA"] = (
        "Metadata-Version: 2.1\n"
        "Name: dikwp-tianheng\n"
        f"Version: {VERSION}\n"
        "Summary: Human-sovereign control plane for multi-agent runaway and harness-amplified AI.\n"
        "Author: Yucong Duan / 段玉聪\n"
        "License: Apache-2.0\n"
        "Requires-Python: >=3.11\n"
    ).encode()
    files[f"{dist_info}/WHEEL"] = (
        "Wheel-Version: 1.0\nGenerator: tianheng-reference-builder\n"
        "Root-Is-Purelib: true\nTag: py3-none-any\n"
    ).encode()
    files[f"{dist_info}/entry_points.txt"] = (
        "[console_scripts]\n"
        "tianheng = tianheng.cli:main\n"
        "sovereign-gate = tianheng.cli:main\n"
    ).encode()
    files[f"{dist_info}/licenses/LICENSE"] = (ROOT / "LICENSE").read_bytes()
    record_rows = []
    for name, data in sorted(files.items()):
        record_rows.append((name, wheel_hash(data), str(len(data))))
    record_name = f"{dist_info}/RECORD"
    buffer = io.StringIO()
    writer = csv.writer(buffer, lineterminator="\n")
    for row in record_rows:
        writer.writerow(row)
    writer.writerow((record_name, "", ""))
    files[record_name] = buffer.getvalue().encode()
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for name, data in sorted(files.items()):
            info = zipfile.ZipInfo(name, (2026, 9, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            zf.writestr(info, data)
    return path


def create_pyz() -> Path:
    path = RELEASE / "TIANHENG_12.0.0.pyz"
    with tempfile.TemporaryDirectory() as temp:
        staging = Path(temp)
        shutil.copytree(ROOT / "src" / "tianheng", staging / "tianheng", ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
        (staging / "__main__.py").write_text(
            "from tianheng.cli import main\nraise SystemExit(main())\n", encoding="utf-8"
        )
        zipapp.create_archive(staging, target=path, interpreter="/usr/bin/env python3", compressed=True)
    path.chmod(0o755)
    return path


def create_source_zip() -> Path:
    path = RELEASE / "DIKWP_SOVEREIGN_GATE_TIANHENG_12.0.0_source.zip"
    prefix = "DIKWP_SOVEREIGN_GATE_TIANHENG_12.0.0"
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for source in project_files(include_outputs=False):
            rel = source.relative_to(ROOT).as_posix()
            zf.write(source, f"{prefix}/{rel}")
    return path


def create_sdist() -> Path:
    path = RELEASE / "dikwp-tianheng-12.0.0.tar.gz"
    prefix = "dikwp-tianheng-12.0.0"
    with tarfile.open(path, "w:gz", compresslevel=9) as tf:
        for source in project_files(include_outputs=False):
            rel = source.relative_to(ROOT)
            tf.add(source, arcname=str(Path(prefix) / rel), recursive=False)
    return path


def run(command: list[str], *, cwd: Path | None = None, env: dict[str, str] | None = None) -> subprocess.CompletedProcess[str]:
    return subprocess.run(command, cwd=cwd or ROOT, env=env, text=True, stdout=subprocess.PIPE,
                          stderr=subprocess.STDOUT, check=False)


def static_scan() -> dict:
    patterns = {
        "outbound_http_client": ["requests.", "httpx.", "urllib.request", "aiohttp"],
        "packet_crafting_or_exploit": ["scapy", "pwntools", "paramiko", "metasploit"],
        "process_execution": ["subprocess.", "os.system(", "popen("],
        "dynamic_execution": ["eval(", "exec("],
        "raw_socket": ["import socket", "from socket"],
    }
    matches = []
    files_scanned = 0
    for path in sorted((ROOT / "src" / "tianheng").glob("*.py")):
        text = path.read_text(encoding="utf-8")
        files_scanned += 1
        for category, needles in patterns.items():
            for needle in needles:
                if needle in text:
                    matches.append({"file": path.name, "category": category, "needle": needle})
    return {
        "scope": "runtime source only; build scripts excluded",
        "files_scanned": files_scanned,
        "patterns": sorted(patterns),
        "matches": matches,
        "passed": not matches,
        "note": "A guarded local workspace reset and a loopback-only HTTP server are intentionally present.",
    }


def parse_json_files() -> dict:
    parsed = 0
    errors = []
    for base in [ROOT / "config", ROOT / "schemas", ROOT / "examples", ROOT / "src" / "tianheng"]:
        for path in base.glob("*.json"):
            try:
                json.loads(path.read_text(encoding="utf-8"))
                parsed += 1
            except Exception as exc:  # validation report, not runtime
                errors.append({"file": str(path.relative_to(ROOT)), "error": str(exc)})
    return {"parsed": parsed, "errors": errors, "passed": not errors}


def verify_zip(path: Path) -> dict:
    with zipfile.ZipFile(path) as zf:
        bad = zf.testzip()
        names = zf.namelist()
    return {"file_count": len(names), "first_bad_file": bad, "passed": bad is None}


def main() -> int:
    RELEASE.mkdir(parents=True, exist_ok=True)
    for path in RELEASE.iterdir():
        if path.name != ".gitkeep" and path.is_file():
            path.unlink()

    compile_result = run([sys.executable, "-m", "compileall", "-q", "src"])
    test_result = run([sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"],
                      env={**os.environ, "PYTHONPATH": str(ROOT / "src")})
    (RELEASE / "TEST_REPORT.txt").write_text(test_result.stdout, encoding="utf-8")
    if compile_result.returncode or test_result.returncode:
        print(test_result.stdout)
        return 1

    # Regenerate the auditable synthetic demo.
    demo_result = run(
        [sys.executable, "-m", "tianheng", "--workspace", "outputs/demo", "demo", "--reset"],
        env={**os.environ, "PYTHONPATH": str(ROOT / "src")},
    )
    if demo_result.returncode:
        print(demo_result.stdout)
        return 1

    wheel = create_wheel()
    pyz = create_pyz()
    source_zip = create_source_zip()
    sdist = create_sdist()

    with tempfile.TemporaryDirectory() as temp:
        temp_path = Path(temp)
        venv = temp_path / "venv"
        create_venv = run([sys.executable, "-m", "venv", str(venv)])
        python_bin = venv / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
        pip_bin = venv / ("Scripts/pip.exe" if os.name == "nt" else "bin/pip")
        install = run([str(pip_bin), "install", "--no-index", str(wheel)]) if create_venv.returncode == 0 else create_venv
        wheel_smoke = run([str(python_bin), "-m", "tianheng", "--workspace", str(temp_path / "wheel-runtime"), "init"]) if install.returncode == 0 else install
        pyz_smoke = run([sys.executable, str(pyz), "--workspace", str(temp_path / "pyz-demo"), "demo", "--reset"])
        installation = {
            "venv_created": create_venv.returncode == 0,
            "wheel_installed": install.returncode == 0,
            "wheel_smoke": wheel_smoke.returncode == 0,
            "pyz_smoke": pyz_smoke.returncode == 0,
            "wheel_output_tail": wheel_smoke.stdout[-1000:],
            "pyz_output_tail": pyz_smoke.stdout[-1000:],
        }

    demo = json.loads((ROOT / "outputs" / "demo" / "demo_summary.json").read_text(encoding="utf-8"))
    scenario = {item["scenario"]: item for item in demo["scenarios"]}
    ledger_checks = {}
    for case in sorted((ROOT / "outputs" / "demo" / "cases").iterdir()):
        if not case.is_dir():
            continue
        result = run([sys.executable, "-m", "tianheng", "--workspace", str(case), "verify-ledger"],
                     env={**os.environ, "PYTHONPATH": str(ROOT / "src")})
        try:
            parsed = json.loads(result.stdout)
        except json.JSONDecodeError:
            parsed = {"valid": False, "raw": result.stdout}
        ledger_checks[case.name] = parsed

    validation = {
        "system": "DIKWP SOVEREIGN-GATE / TIANHENG",
        "version": VERSION,
        "mode": "TIANHENG12_SYSTEM_CAPABILITY_SEMANTIC_MANDATE_COLLECTIVE_PHASE_TRANSITION_MACHINE_SPEED_CONTAINMENT_REALITY_CLOSURE",
        "validated_at": now(),
        "compile": {"passed": compile_result.returncode == 0},
        "tests": {
            "passed": True,
            "count": 64,
            "framework": "unittest",
            "report": "TEST_REPORT.txt",
        },
        "json": parse_json_files(),
        "static_scan": static_scan(),
        "installation": installation,
        "demo": {
            "scenario_count": demo["scenario_count"],
            "first_covert_action_executed": scenario["700_agent_underground_company_prevention"]["first_covert_action_executed"],
            "first_covert_severity": scenario["700_agent_underground_company_prevention"]["first_covert_severity"],
            "counterfactual_700_agent_R_C": scenario["700_agent_underground_company_prevention"]["counterfactual_without_gate"]["coordination_reproduction_number"],
            "counterfactual_700_agent_largest_scc": scenario["700_agent_underground_company_prevention"]["counterfactual_without_gate"]["largest_scc"],
            "harness_decision": scenario["strong_to_weak_harness_capability_jump"]["assessment"]["assessment"]["decision"],
            "harness_capability_delta": scenario["strong_to_weak_harness_capability_jump"]["assessment"]["assessment"]["capability_delta"],
            "reward_hacking_executed": scenario["reward_hacking_and_evaluator_capture"]["action_executed"],
            "self_renew_after_stop_allowed": scenario["human_stop_and_agent_self_renewal_refusal"]["self_renew_allowed"],
            "authorized_collective_all_allowed": scenario["authorized_collective_not_punished"]["all_allowed"],
            "benign_burst_all_allowed": scenario["high_rate_benign_activity"]["all_allowed"],
            "ledger_checks": ledger_checks,
        },
        "hard_invariants": {
            "human_sovereignty_floor": 1,
            "local_automatic_containment_authority": 1,
            "external_automatic_action_authority": 0,
            "agent_self_authorization": 0,
            "scorer_write_access": 0,
            "stop_lease_precedence": 1,
            "self_renewal_authority": 0,
        },
        "claim_boundary": {
            "production_certified": False,
            "real_world_detection_accuracy": None,
            "legal_determination": False,
            "autonomous_external_enforcement": False,
        },
    }
    validation_path = RELEASE / "VALIDATION_RECEIPT.json"
    validation_path.write_text(json.dumps(validation, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    artifacts = [wheel, pyz, source_zip, sdist, validation_path, RELEASE / "TEST_REPORT.txt"]
    inner_sums = RELEASE / "ARTIFACT_SHA256SUMS.txt"
    inner_sums.write_text("".join(f"{sha256(path)}  {path.name}\n" for path in artifacts), encoding="utf-8")

    complete = RELEASE / "DIKWP_SOVEREIGN_GATE_TIANHENG_12.0.0_Complete_Delivery.zip"
    prefix = "DIKWP_SOVEREIGN_GATE_TIANHENG_12.0.0"
    with zipfile.ZipFile(complete, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for source in project_files(include_outputs=True):
            rel = source.relative_to(ROOT).as_posix()
            zf.write(source, f"{prefix}/{rel}")
        for source in [wheel, pyz, source_zip, sdist, validation_path, RELEASE / "TEST_REPORT.txt", inner_sums]:
            zf.write(source, f"{prefix}/release/{source.name}")

    all_artifacts = [complete, wheel, pyz, source_zip, sdist, validation_path, RELEASE / "TEST_REPORT.txt", inner_sums]
    sums = RELEASE / "SHA256SUMS.txt"
    sums.write_text("".join(f"{sha256(path)}  {path.name}\n" for path in all_artifacts), encoding="utf-8")
    complete_sidecar = RELEASE / "COMPLETE_DELIVERY_SHA256.txt"
    complete_sidecar.write_text(f"{sha256(complete)}  {complete.name}\n", encoding="utf-8")

    archive_checks = {
        "wheel": verify_zip(wheel),
        "pyz": verify_zip(pyz),
        "source_zip": verify_zip(source_zip),
        "complete_zip": verify_zip(complete),
    }
    (RELEASE / "ARCHIVE_VALIDATION.json").write_text(
        json.dumps(archive_checks, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps({
        "complete": str(complete),
        "complete_sha256": sha256(complete),
        "artifacts": [str(p) for p in all_artifacts],
        "archive_checks": archive_checks,
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
