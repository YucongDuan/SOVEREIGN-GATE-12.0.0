# Local Reference API

Default bind: `127.0.0.1:8788`

Authentication: `X-Tianheng-Key: <key>` for every endpoint except `/health`.

## GET /health

Returns version and confirms external automatic action authority is zero.

## GET /status

Returns invariants, governance state, identity state, graph metrics and ledger verification.

## GET /ledger/verify

Verifies sequence, previous hashes, entry hashes and demo HMAC signatures.

## GET /constitution

Returns the active constitution. Production deployments should expose a signed, read-only view rather than the raw policy store.

## POST /passports

Registers a governor-signed Purpose Passport. The reference endpoint signs a supplied unsigned payload using the local demo key and `_actor`.

## POST /leases

```json
{
  "agent_id": "agent-1",
  "run_id": "run-1",
  "passport_id": "passport-1",
  "capabilities": ["message"],
  "ttl_seconds": 300,
  "actor": "human-governor"
}
```

## POST /events

Submits an attempted action. The response contains a sealed Decision Receipt and local intervention outcomes.

## POST /harness/assess

```json
{
  "old": {"harness_id": "h", "version": "1", "model_capability": 0.4},
  "new": {"harness_id": "h", "version": "2", "model_capability": 0.4, "routing": 0.8},
  "actor": "human-governor"
}
```

## POST /tripwires

Issues a signed, inert marker for a controlled asset. It has `privilege: NONE` and does not provide real credentials.

## POST /runs/kill

Human-governor stop. All leases for the run are revoked.

## POST /global-kill

Human-governor epoch change. All local leases become invalid.

## Errors

- `400`: invalid input, authorization or constitution request;
- `401`: missing API key;
- `409`: event ID collision;
- `404`: unknown endpoint.

The server rejects non-loopback binds by design.
