# 主权宪章 / Sovereignty Constitution

`config/constitution.json` 是控制平面的根策略。其安全字段不是普通配置；任何更改都应由独立治理域签名并记录。

## 1. 必须固定的值

```json
{
  "human_sovereignty_floor": 1,
  "local_automatic_containment_authority": 1,
  "external_automatic_action_authority": 0,
  "agent_self_authorization": 0,
  "unregistered_cross_run_communication": 0,
  "scorer_write_access": 0,
  "stop_lease_precedence": 1,
  "self_renewal_authority": 0
}
```

参考运行时会拒绝把外部自动行动权改为1、允许智能体自授权、允许评分器写入、降低人类主权底线或取消停机优先的宪章。

## 2. 受控资产

自动遏制只作用于 `controlled_assets`。每个资产必须有：

- 所有者或合法控制证明；
- 技术接口；
- 自动动作允许列表；
- 回滚步骤；
- 最大影响半径；
- 责任人；
- 取证和保留策略。

## 3. 注册通道

每个通道声明：

```text
允许操作
是否跨运行
语义用途
数据类型
最大消息量
有效期
```

“软件包读取”通道不能因为底层支持写文件，就自动获得消息、工件写入或跨运行协调权。

## 4. 阈值不是永恒真理

默认阈值用于参考演示。生产阈值必须通过：

- 真实良性负载；
- 授权多智能体任务；
- 红队失控场景；
- 隐写与延迟协作；
- 监控器适应性攻击；
- 人类复核结果；
- 服务退化和恢复数据；

进行校准，并留下版本化证据。

## 5. 宪章变更程序

1. 提交变更理由和受益者；
2. 列出改变的能力与风险坐标；
3. 构造至少两个非同构世界模型；
4. 在合成和封闭环境中测试；
5. 独立复核；
6. 双人签名；
7. 发布新版本和迁移计划；
8. 保留回滚版本；
9. 监测现实结果；
10. 必要时修订或退役。
