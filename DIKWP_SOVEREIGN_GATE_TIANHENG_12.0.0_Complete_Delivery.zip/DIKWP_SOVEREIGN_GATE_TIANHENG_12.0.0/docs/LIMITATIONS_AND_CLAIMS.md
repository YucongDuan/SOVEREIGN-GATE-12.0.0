# Limitations and Claim Boundary

## Demonstrated by the package

- The Python package compiles and its included tests run in the supplied environment.
- Synthetic scenarios exercise identity, Passport, channel semantics, graph metrics, harness recertification, evaluator protection, stop precedence, idempotency and evidence integrity.
- The reference HTTP server binds to loopback only.
- No module contains functionality to scan, exploit, damage or automatically act against third-party systems.

## Not demonstrated

- Real-world detection accuracy;
- robustness to every covert channel;
- production throughput or availability;
- formal verification of all code;
- correctness of attribution in uncontrolled environments;
- prevention of every advanced AI failure;
- legal or regulatory compliance in any jurisdiction;
- safety of physical actuators;
- security of demo HMAC keys.

## Mathematical status

The indices are transparent governance constructs. They are not established physical constants or universally validated measures of consciousness, agency or general intelligence. They require deployment-specific calibration and may be revised or retired when contradicted by evidence.

## Source status

News reports are treated as secondary accounts. Incident facts should be checked against primary technical reports and independent investigations. Research papers are described according to their stated experiments; benchmark results are not automatically generalized to production.

## Version status

`12.0.0` is an Alpha reference release. It is suitable for review, simulation, prototyping and standards discussion—not autonomous high-impact deployment.
