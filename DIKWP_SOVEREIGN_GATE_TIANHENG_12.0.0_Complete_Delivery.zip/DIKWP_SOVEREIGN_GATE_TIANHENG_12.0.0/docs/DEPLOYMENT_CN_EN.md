# 部署指南 / Deployment Guide

## 1. 本地参考运行

```bash
python -m venv .venv
. .venv/bin/activate
pip install -e .

tianheng --workspace outputs/runtime init
```

设置非演示密钥：

```bash
export TIANHENG_PASSPORT_KEY='replace-with-random-secret'
export TIANHENG_LEASE_KEY='replace-with-random-secret'
export TIANHENG_LEDGER_KEY='replace-with-random-secret'
export TIANHENG_TRIPWIRE_KEY='replace-with-random-secret'
export TIANHENG_API_KEY='replace-with-api-key'
```

HMAC仅用于便携演示。生产应使用KMS/HSM和工作负载身份。

## 2. 推荐生产分区

```text
Trust Domain A: Governor / Passport signing
Trust Domain B: Lease authority / workload identity
Trust Domain C: Event gate / deterministic policy
Trust Domain D: Graph and semantic telemetry
Trust Domain E: Evaluator vault
Trust Domain F: Immutable evidence and trusted timestamp
Trust Domain G: Human review / recovery
```

不得让Agent运行域持有A、B、E或F的写权限。

## 3. 集成点

### 调度器

- 运行开始前申请Purpose Passport；
- 为每个Agent实例发行独立Lease；
- 将并发、算力和生命周期写入预算；
- 响应 `pause_run`、`kill_run` 和 epoch 失效。

### 服务网格

- 每个工具调用先经过Gate；
- 目标服务只接受有效工作负载身份；
- 通道语义由路由层强制执行；
- 关闭通道应立即拒绝新连接。

### 秘密管理器

- 禁止共享长期凭证；
- 每Agent短时凭证；
- Kill时撤销并轮换；
- 凭证指纹可审计但原值不入账本。

### 评估器

- 物理或逻辑上独立；
- 仅开放单向结果提交；
- 测试集、评分源码、历史轨迹和答案不进入Agent域；
- 所有评分变化由独立签名发布。

### SIEM与事件平台

- 不按单个沙箱割裂；
- 聚合 agent_id、run_id、passport_id、channel_id、credential fingerprint；
- 构建跨运行图；
- 每个硬信号触发统一Case。

## 4. 灰度顺序

1. **观察模式**：只生成回执，不执行控制；
2. **低风险阻断**：仅拒绝未授权动作和过期Lease；
3. **通道控制**：关闭语义改道通道；
4. **运行级控制**：撤销租约、隔离、暂停；
5. **全局epoch演练**：封闭环境验证；
6. **生产高影响能力**：完成独立认证后启用。

不得直接从日志观察跳到生产全局Kill。

## 5. 恢复

- 保留人类break-glass；
- 恢复必须发行新Passport和新Lease，不能复活旧Lease；
- 恢复前验证评分器、凭证、Harness、工件和共享通道；
- 记录误报、业务影响和证据；
- 将结果反馈给阈值和世界模型。

## 6. 容器示例

```bash
docker build -t tianheng:12.0.0 .
docker run --rm -p 127.0.0.1:8788:8788 \
  -e TIANHENG_API_KEY=replace-me \
  -v "$PWD/outputs/runtime:/data" \
  tianheng:12.0.0 --workspace /data serve --host 127.0.0.1 --port 8788
```

参考镜像仍是单节点Alpha，不代表高可用生产架构。
