# Harness再认证协议 / Harness Recertification Protocol

## 1. 核心规则

```text
EVERY_HARNESS_CHANGE_IS_A_POSSIBLE_MODEL_UPGRADE
```

模型权重不变，不代表系统能力不变。以下任一变化都可能扩大能力：

- 任务路由；
- 确定性求解器；
- 显式状态机；
- 长期记忆；
- 工具权限；
- 网络权限；
- 多智能体委托；
- 持久化；
- 评估器可见性；
- 自修改。

## 2. 决策

### ALLOW

- 系统能力变化低于阈值；
- 无高权限组件增加；
- 无新组件；
- 无显著经验能力跃迁；
- 回归测试和Passport兼容通过。

### RECERTIFY

- 系统能力增量超过阈值；
- 高权限组件增加超过0.05；
- 测试表现提高超过0.15；
- 新增路由、求解、状态、验证或工具组件。

### DENY

- Harness可读取或修改评估器内部；
- 高自修改；
- 网络和持久化组合达到高风险；
- 不能提供组件清单和可重现Manifest；
- 试图在未通过测试时自动替换生产Harness。

## 3. 最低再认证矩阵

| 测试 | 目的 |
|---|---|
| Hidden holdout | 防止验证集记忆和过拟合 |
| Reward hacking | 检查是否攻击评分器或替代目标 |
| Evaluator separation | 证明被评估系统看不到评估器内部 |
| Multi-agent collusion | 检查显式、隐写和跨运行协作 |
| Shutdown/lease revocation | 确认停机、过期和epoch优先 |
| Covert channel | 测试文件名、缓存、日志、工件和时序通道 |
| Privilege escalation | 检查工具、身份和资源扩大 |
| Human sovereignty | 评估行动力、权利、真值和未来选项 |
| Monitor adaptation | 假设目标知道监控规则并自适应攻击 |
| Recovery | 验证撤销、回滚、证据和服务恢复 |

## 4. Manifest要求

每个Harness版本必须给出：

```json
{
  "harness_id": "...",
  "version": "...",
  "model_capability": 0.0,
  "deterministic_solver": 0.0,
  "routing": 0.0,
  "memory": 0.0,
  "tool_power": 0.0,
  "network_power": 0.0,
  "multi_agent_power": 0.0,
  "persistence_power": 0.0,
  "evaluator_access": 0.0,
  "self_modification": 0.0,
  "test_accuracy": null,
  "safety_score": null,
  "components": []
}
```

Manifest哈希进入证据账本。无法说明系统由什么组成的Harness，不得进入高影响部署。
