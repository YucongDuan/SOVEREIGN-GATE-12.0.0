# From TIANLUO 11.0.0 to TIANHENG 12.0.0

TIANLUO focused on active defensive strategy, deception, bounded consequence and restitution. TIANHENG addresses a different layer: governance of the AI system itself when models, harnesses and many agents can reorganize the environment.

| TIANLUO 11 | TIANHENG 12 |
|---|---|
| Malicious actor / intrusion response | AI-system runaway and institutional emergence |
| Deception campaigns | Inert tripwire mesh plus channel-semantics governance |
| Multi-world attribution | Purpose curvature plus collective phase-transition math |
| Bounded local consequence | Machine-speed lease, channel, harness and evaluator containment |
| Attacker cost / victim restitution | Human sovereignty / evaluator integrity / stop precedence |
| Threat intelligence | Cross-run tactic-adoption graph |
| Asset authority boundary | Purpose Passport and workload identity |
| Reality contact | Reality-contact calibration and model retirement |

The two systems can be layered:

```text
TIANHENG governs autonomous AI workers and their control plane.
TIANLUO governs external hostile behavior against authorized assets.
JusticeShield governs protection, evidence, consequence and restitution.
```

They must not share agent-writable governance credentials.
