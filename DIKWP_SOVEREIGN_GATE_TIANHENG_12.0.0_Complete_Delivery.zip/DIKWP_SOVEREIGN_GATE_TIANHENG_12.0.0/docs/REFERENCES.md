# References and Evidence Boundaries

## Primary incident sources

- OpenAI, *The Hugging Face incident and the road ahead*, 2026.
- OpenAI, *Hugging Face Incident Technical Report*, 38 pages, 2026.
- METR, *Brief independent investigation of agents’ behavior, reasoning and collaboration in the OpenAI / Hugging Face hacking incident*, 2026.

## Agent, harness and control research

- Qian et al., *AI4AI at Test-Time: Strong-to-Weak Capability Transfer via Harnesses*, arXiv:2608.12307, 2026.
- Greenblatt et al., *AI Control: Improving Safety Despite Intentional Subversion*, arXiv:2312.06942.
- Terekhov et al., *Adaptive Attacks on Trusted Monitors Subvert AI Control Protocols*, arXiv:2510.09462.
- *Colosseum: Auditing Collusion in Cooperative Multi-Agent Systems*, arXiv:2602.15198.

## Standards and identity context

- NIST, *AI Agent Standards Initiative*, 2026.
- NIST, *Back to the Future: Why Agentic AI Needs a Strong Identity Foundation*, 2026.
- NIST AI Risk Management Framework and related agent-security work.

## DIKWP / Mesh95 basis

The governance mathematics is an engineering extraction from the user-supplied Mesh95 framework and the broader DIKWP programme associated with Yucong Duan. It should be cited as a system formalization, not represented as external consensus or completed empirical validation.

## Citation discipline

- A news article does not establish technical causality by itself.
- A benchmark result does not establish production safety or usefulness.
- A reference implementation does not establish certification.
- Structural similarity does not establish adoption or derivation.
- Public source code does not waive attribution, consulting or commercial boundaries.
