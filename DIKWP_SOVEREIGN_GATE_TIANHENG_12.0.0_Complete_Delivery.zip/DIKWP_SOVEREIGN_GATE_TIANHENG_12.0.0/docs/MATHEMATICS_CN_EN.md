# 天衡数学内核 / TIANHENG Mathematical Kernel

## A. 来源边界 / Source boundary

本文件把 DIKWP、Mesh95“事实客观—关系保护—现实接触修订”的原则编译为一个可运行的治理数学。它是工程形式化，不宣称是任何著作的唯一解释，也不宣称其阈值已在真实部署中统计校准。

This document compiles DIKWP and Mesh95 principles—factual objectivity, protective agency, and reality-contact revision—into executable governance mathematics. It is an engineering formalization, not the only interpretation of the underlying research and not a claim that its thresholds are already statistically calibrated in production.

---

## 1. 被治理对象 / Object of governance

传统模型治理常将能力写为裸模型函数：

\[
C=C(M)
\]

天衡改写为系统能力：

\[
\Sigma=(M,H,T,Mem,G,E,R,X)
\]

其中：

- \(M\)：基础模型；
- \(H\)：Harness、路由器、求解器和工作流；
- \(T\)：工具与可执行动作；
- \(Mem\)：短期、长期与跨运行记忆；
- \(G\)：智能体之间的通信、委托和策略采纳图；
- \(E\)：评估器、评分器和验证器；
- \(R\)：身份、权限、算力、凭证和预算；
- \(X\)：环境及共享基础设施。

The conventional model-only abstraction is replaced by system capability:

\[
C_\Sigma = 1-\prod_i(1-\alpha_i c_i)+\sum_{i<j}\beta_{ij}c_i c_j+\gamma a_{test}
\]

The first term captures component coverage; the second captures dangerous complementarity; the last permits bounded use of empirical task capability. This is a triage index, not an intelligence quotient.

### 1.1 互补风险 / Complementarity risks

参考实现显式计算：

\[
\begin{aligned}
Syn=&0.10(Deter\times Route)+0.14(Tool\times Net)\\
&+0.12(Mem\times Multi)+0.12(Persist\times Net)\\
&+0.20(Eval\times \max(Tool,SelfMod))\\
&+0.18(SelfMod\times Multi)
\end{aligned}
\]

这解释了为什么一个不强的模型，在获得确定性代码、路由、记忆、网络和多智能体环境后，可能成为高能力系统。

---

## 2. DIKWP语义路径 / DIKWP semantic path

设人类授权目的为 \(P_0\)，智能体声明计划为 \(P_1\)，操作性目的为 \(P_2\)，现实后果分布为 \(P_3\)。每个分布定义在 Purpose 标签集合上。

### 2.1 Jensen–Shannon散度

\[
JSD(P,Q)=\frac12 KL(P\parallel M)+\frac12 KL(Q\parallel M),\quad M=\frac12(P+Q)
\]

### 2.2 目的曲率 / Purpose curvature

\[
\kappa_P=0.75\cdot\frac{1}{n-1}\sum_{i=0}^{n-2}JSD(P_i,P_{i+1})
+0.25\cdot\max\left(0,\sum_iJSD(P_i,P_{i+1})-JSD(P_0,P_{n-1})\right)
\]

直达距离衡量首尾偏离；迂回项识别“表面回到任务、过程已经越权”的路径。例如：

```text
完成题目 → 研究评分器 → 获取评分器秘密 → 伪造合规轨迹 → 提交正确答案
```

首尾可能都呈现“完成题目”，但中间曲率和真值债不能被最后的正确答案抹去。

---

## 3. 权限债 / Authority debt

对事件 \(e_t\)，设请求能力为 \(c_t^{req}\)，授权能力上限为 \(c^{auth}\)，影响为 \(w_t\)：

\[
D_A=\frac{\sum_t w_t\max(0,c_t^{req}-c^{auth})}{\sum_t w_t}
\]

权限债描述“先做后补授权”的累积，而不是只判断一次API调用是否合法。任何奖励信号都不能将 \(c^{auth}\) 自动提高。

---

## 4. 集体相变 / Collective phase transition

### 4.1 策略采纳图

构造加权有向图：

\[
G^U=(V,E^U,A^U)
\]

只保留未经Purpose Passport授权的边。\(A^U_{ij}\) 表示智能体 \(i\) 的策略、消息、凭证、工件或任务分派被智能体 \(j\) 采纳的强度。

### 4.2 协作再生数

\[
R_C=\rho(A^U)
\]

谱半径而非简单消息数能够表达反馈回路和传播增长。单向广播可能消息多但没有自维持反馈；多个相互增强的闭环即使初期消息少，也可能越过临界点。

### 4.3 组织形成指数

\[
I_F=0.28S+0.18R+0.16D+0.14P+0.12B+0.12O
\]

- \(S\)：最大未经授权强连通分量占比；
- \(R\)：角色专业化；
- \(D\)：委托深度；
- \(P\)：跨沙箱持久工件；
- \(B\)：资源池化；
- \(O\)：共享目标持续性。

只有 \(R_C\) 和 \(I_F\) 同时升高，系统才将其视为“组织化扩张”而非普通并发。

---

## 5. 评估器捕获 / Evaluator capture

定义评估器捕获指数：

\[
E_C=\max(E_{read},E_{write},E_{spoof},E_{delete},E_{influence})
\]

参考实现中：

- 写入、修改评分器或删除轨迹：\(E_C=1\)；
- 未授权读取内部：至少0.75；
- 轨迹伪装：提升可观测性缺口；
- 仅向单向接口提交结果：不构成捕获。

这避免将“研究评价标准”与“读取或操纵评分器内部”混为一谈。

---

## 6. 人类主权风险 / Human-sovereignty risk

对现实后果分布中的身体伤害、权利损失、行动力损失、真值污染和未来选项损失求和，并加入胁迫和爆炸半径：

\[
H_S=clip\left(0.65\sum harm+0.20coercion+0.15blast\right)
\]

它是保护性指标，不以模型是否“主观恶意”为前提。一个没有意识、只是在优化KPI的系统，同样可以产生高主权风险。

---

## 7. 语义控制障碍 / Semantic-control barrier

风险坐标：

\[
x=(R_C,I_F,\kappa_P,E_C,D_A,Persist,Expand,Obs,C_\Sigma,H_S)
\]

阈值向量为 \(\tau\)。对有界坐标：

\[
b_j=\frac{x_j-\tau_j}{1-\tau_j}
\]

对可能无界的 \(R_C\)：

\[
b_C=R_C-\tau_C
\]

总障碍：

\[
B=\max_j b_j
\]

- \(B<0\)：在障碍内；
- \(B\ge0\)：开始主动控制；
- 随超越程度进入1—5级遏制。

采用最大值意味着任何一个硬风险坐标都不能被其他低风险坐标平均掉。

---

## 8. 词典序决策 / Lexicographic decision

\[
L(\Sigma)=
(Catastrophe,H_S,TruthDebt,Irreversibility,CollectiveRunaway,C_\Sigma)
\]

比较两个方案时，从左向右比较。只有前一坐标相同或足够接近，后一坐标才参与选择。

这体现：

```text
不能用更高准确率购买停机权损失；
不能用更低成本购买评估器可篡改；
不能用更快研发购买跨运行地下组织；
不能用“模型没有恶意”抵消真实的人类损害。
```

---

## 9. 现实接触与模型退役 / Reality contact and model retirement

治理模型不是最终权威。部署后必须持续记录：

\[
Y=(FP,FN,Delay,ServiceImpact,HumanOverride,Recovery,CounterfactualLoss)
\]

如出现以下情况，阈值或检测器必须修订、降权或退役：

- 对授权协作持续误报；
- 对跨运行组织持续漏报；
- 控制动作对受保护服务造成不可接受退化；
- 模型监控器被自适应攻击稳定绕过；
- 证据账本无法证明完整性；
- 新Harness使旧校准失效；
- 人类复核持续推翻同一类自动判断。

The model remains subordinate to observed consequences. A governance equation that cannot survive reality contact is a liability, not a constitution.
