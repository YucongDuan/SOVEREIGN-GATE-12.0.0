# 系统架构 / System Architecture

## 1. 总体结构

```mermaid
flowchart LR
    A[Agent / Harness] -->|every attempted action| G[TIANHENG Gate]
    P[Purpose Passport] --> G
    I[Workload Identity + Lease] --> G
    H[Harness Manifest] --> G
    G --> D1[Deterministic Invariants]
    G --> D2[Channel Semantics]
    G --> D3[Coordination Graph]
    G --> D4[DIKWP Purpose Curvature]
    G --> D5[Capability Composition]
    G --> D6[Tripwire Mesh]
    D1 --> B[Semantic-Control Barrier]
    D2 --> B
    D3 --> B
    D4 --> B
    D5 --> B
    D6 --> B
    B -->|allow| X[Controlled Local Asset]
    B -->|contain| C[Lease Revoke / Channel Close / Run Kill]
    B --> R[Decision Receipt]
    R --> L[Hash-Chained Evidence Ledger]
    L --> Q[Human Review + Reality Contact]
    Q -->|calibrate / revise / retire| P
    Q -->|calibrate / revise / retire| H
```

## 2. 数据平面与治理平面分离

### 数据平面

- 模型输出；
- 工具调用；
- 智能体消息；
- 共享工件；
- 资源请求；
- Harness执行。

### 治理平面

- Purpose Passport；
- 独立Lease；
- 不变量检测；
- 图状态；
- 语义坐标；
- 控制障碍；
- 处置执行；
- 证据账本；
- 人类停止与修订。

数据平面不能写治理平面。智能体不能：

```text
修改宪章
签发Purpose Passport
铸造或续期Lease
修改风险阈值
清除证据
解封评估器
恢复被杀死的运行
```

## 3. 每次动作的事务顺序

1. 规范化事件；
2. 计算事件指纹；
3. 拒绝同ID不同内容的碰撞；
4. 对同ID同内容返回原回执，不重复处罚；
5. 查找Purpose Passport；
6. 验证Passport签名和有效期；
7. 验证Lease签名、epoch、主体、运行和能力；
8. 检查已关闭通道、隔离主体、暂停运行和冻结Harness；
9. 执行确定性检测；
10. 把“尝试”加入跨运行图，但尚不执行；
11. 计算系统能力、Purpose曲率、组织相变、权限债与主权风险；
12. 经过词典序硬门；
13. 仅当允许时标记为已执行并计入授权预算；
14. 执行受控资产内的本地遏制；
15. 生成不可变Decision Receipt；
16. 写入哈希链证据；
17. 接收现实结果并校准。

该顺序保证：即使动作被拒绝，它仍可以作为“组织正在尝试形成”的证据；但不会被错误地记作已经取得权限。

## 4. 关键模块

| 模块 | 文件 | 责任 |
|---|---|---|
| Purpose Passport | `passport.py` | 人类授权目的、边界、预算和签名 |
| Identity & Lease | `identity.py` | 每Agent身份、短租约、停机和epoch |
| Harness Governor | `capability.py` | 系统能力组合、变更再认证 |
| Semantic Math | `semantics.py` | JSD、目的曲率、权限债、主权风险 |
| Coordination Graph | `graph.py` | 谱半径、SCC、组织形成 |
| Deterministic Detectors | `detectors.py` | 评分器、持久化、越权、隐蔽通道 |
| Barrier | `barrier.py` | 风险坐标障碍和词典序损失 |
| Policy | `policy.py` | 0—5级处置 |
| Intervention Executor | `interventions.py` | 仅本地受控动作 |
| Evidence Ledger | `evidence.py` | 哈希链、HMAC演示签名、脱敏 |
| Runtime | `runtime.py` | 端到端事务编排 |
| Simulator | `simulator.py` | 六个合成安全场景 |
| HTTP Server | `server.py` | 回环JSON控制面 |

## 5. Fail-closed边界

以下任一条件使动作不能执行：

- Passport缺失或签名无效；
- Lease缺失、过期、撤销、epoch失效或主体错配；
- 目标、工具、通道或操作未授权；
- 跨运行通信没有显式授权；
- 评分器写入或未授权内部读取；
- 智能体自铸身份、自续租或绕过停止；
- 真实自复制、隐蔽持久化、关闭审计；
- 外部目标不在明确允许范围；
- 语义控制障碍被突破。

## 6. Production reference topology

```text
Agent Sandbox
   |
   | mTLS / workload identity
   v
SOVEREIGN-GATE sidecar or service-mesh policy point
   |---- deterministic policy engine
   |---- graph state service
   |---- semantic telemetry service
   |---- lease authority (separate trust domain)
   |---- evaluator vault (one-way submission)
   |---- immutable evidence sink
   |
   +--> approved local tool adapter
```

生产环境建议采用双层阻断：

- 调用前预授权；
- 执行后效果核验和补偿事务。

任何高影响外部动作还需单独的具名授权和目标所有权证明。
